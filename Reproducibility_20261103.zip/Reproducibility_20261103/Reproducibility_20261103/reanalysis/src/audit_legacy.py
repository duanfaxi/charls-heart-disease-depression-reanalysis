"""Forensically compare legacy manual ID filters with the rebuilt cohorts."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.paths import GENERATED_REPORT_DIR, PROJECT_ROOT, RAW_WAVE_DIRS


LEGACY_WINDOWS = {
    (2013, 2015): "13-15ID.txt",
    (2015, 2018): "15-18ID.txt",
    (2018, 2020): "18-20ID.txt",
}


def normalize_legacy_id(series: pd.Series) -> pd.Series:
    """Restore leading zeroes lost when fixed-width CHARLS IDs entered spreadsheets."""

    cleaned = series.astype("string").str.strip().str.replace(r"\.0$", "", regex=True)
    return cleaned.str.zfill(12)


def audit_2013_smoking_filter(workspace_root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Test the observed 906-to-713 legacy filter against the old smoking column."""

    old = pd.read_csv(
        workspace_root / "2013-2015整理.csv", dtype={"ID": "string"}
    )
    selected = pd.read_csv(workspace_root / "13-15ID.txt", dtype={"ID": "string"})
    old["participant_id"] = normalize_legacy_id(old["ID"])
    selected_ids = set(normalize_legacy_id(selected["ID"]))
    old["selected_in_13_15_id_file"] = old["participant_id"].isin(selected_ids)
    old["old_smoke_text"] = old["smoke"].astype("string").str.strip()
    old["old_smoke_is_zero"] = old["old_smoke_text"].eq("0")

    exact_rule = old["selected_in_13_15_id_file"].eq(~old["old_smoke_is_zero"])
    if not exact_rule.all():
        raise AssertionError("Legacy 13-15 selection is no longer exactly smoke != 0")

    raw = pd.read_stata(
        RAW_WAVE_DIRS[2013] / "Health_Status_and_Functioning.dta",
        columns=["ID", "zda059", "da059", "da061"],
        convert_categoricals=False,
        preserve_dtypes=False,
    )
    raw["participant_id"] = raw["ID"].astype("string").str.strip()
    detail = old.merge(
        raw[["participant_id", "zda059", "da059", "da061"]],
        on="participant_id",
        how="left",
        validate="one_to_one",
    )
    detail = detail[
        [
            "participant_id",
            "selected_in_13_15_id_file",
            "old_smoke_text",
            "old_smoke_is_zero",
            "zda059",
            "da059",
            "da061",
        ]
    ]
    summary = (
        detail.groupby(
            [
                "selected_in_13_15_id_file",
                "old_smoke_text",
                "zda059",
                "da059",
                "da061",
            ],
            dropna=False,
        )
        .size()
        .rename("n")
        .reset_index()
    )
    summary["finding"] = "13-15ID selection exactly equals old smoke != 0"
    return detail, summary


def compare_old_ids_to_new(
    workspace_root: Path, report_dir: Path
) -> pd.DataFrame:
    """Attach each legacy selected ID to its new eligibility disposition."""

    ledger = pd.read_csv(
        report_dir / "cohort_exclusion_ledger.csv", dtype={"ID": "string"}
    ).rename(columns={"ID": "participant_id"})
    rows: list[pd.DataFrame] = []
    for (baseline_wave, outcome_wave), file_name in LEGACY_WINDOWS.items():
        old_ids = pd.read_csv(workspace_root / file_name, dtype={"ID": "string"})
        frame = pd.DataFrame(
            {"participant_id": normalize_legacy_id(old_ids["ID"]).drop_duplicates()}
        )
        frame["baseline_wave"] = baseline_wave
        frame["outcome_wave"] = outcome_wave
        disposition = ledger.loc[
            ledger["baseline_wave"].eq(baseline_wave)
            & ledger["outcome_wave"].eq(outcome_wave),
            ["participant_id", "status", "first_exclusion_reason"],
        ]
        frame = frame.merge(disposition, on="participant_id", how="left", validate="one_to_one")
        frame["status"] = frame["status"].fillna("not_in_baseline_health_module")
        frame["first_exclusion_reason"] = frame["first_exclusion_reason"].fillna(
            "not_in_baseline_health_module"
        )
        rows.append(frame)
    return pd.concat(rows, ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    workspace_root = PROJECT_ROOT.parent

    detail, summary = audit_2013_smoking_filter(workspace_root)
    detail.to_csv(
        args.report_dir / "legacy_2013_2015_smoking_filter_detail.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary.to_csv(
        args.report_dir / "legacy_2013_2015_smoking_filter_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    comparison = compare_old_ids_to_new(workspace_root, args.report_dir)
    comparison.to_csv(
        args.report_dir / "old_id_vs_new_eligibility.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(
        "Confirmed the legacy 906-to-713 filter and compared all old ID lists "
        "with the rebuilt cohort."
    )


if __name__ == "__main__":
    main()

