"""Run the complete auditable data-construction pipeline in order."""

from __future__ import annotations

import subprocess
import sys


MODULES = [
    "src.inventory",
    "src.extract_core",
    "src.extract_demographics",
    "src.extract_predictors",
    "src.build_windows",
    "src.audit_legacy",
    "src.assemble_analysis",
    "src.build_dictionary",
    "src.audit_candidate_fields",
]


def main() -> None:
    for module in MODULES:
        print(f"\n=== Running {module} ===", flush=True)
        subprocess.run([sys.executable, "-m", module], check=True)
    print("\nData construction and audit pipeline completed successfully.")


if __name__ == "__main__":
    main()
