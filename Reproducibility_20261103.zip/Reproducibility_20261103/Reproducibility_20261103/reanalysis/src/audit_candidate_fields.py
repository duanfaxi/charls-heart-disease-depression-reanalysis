"""Create a searchable cross-wave shortlist of candidate predictor fields."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import pandas as pd

from src.paths import GENERATED_REPORT_DIR


CONCEPT_PATTERNS = {
    "self_rated_health": r"self.{0,20}health|health.{0,20}(?:status|condition)|rate.{0,20}health",
    "life_satisfaction": r"life.{0,20}satisf|satisf.{0,20}life",
    "sleep_and_nap": r"sleep|nap",
    "pain": r"pain",
    "social_activity": r"social activ|social interact|mahjong|club|community organization|voluntar|help.{0,20}(?:friend|neighbor|family)",
    "smoking": r"smok|cigarette|tobacco",
    "alcohol": r"alcohol|drink",
    "physical_activity": r"physical activ|vigorous activ|moderate activ|walk.{0,20}minute|exercise",
    "adl_iadl": r"dress|bath|eat|bed|toilet|continence|household chore|prepare.{0,10}meal|shop|manage.{0,10}money|take.{0,10}medic|phone call|functional limitation",
    "disability": r"disabil|handicap|blind|deaf|mute|limb",
    "medication": r"medic|drug|take.{0,15}(?:pill|medicine)|treat",
    "disease": r"doctor.{0,15}diagnos|diagnos.{0,15}(?:disease|hypertension|dyslipidemia|diabetes|cancer|lung|liver|heart|stroke|kidney|digest|psychi|memory|arthritis|asthma)",
}

SOURCE_FILES = {
    "Health_Status_and_Functioning.dta",
    "Demographic_Background.dta",
    "Cognition.dta",
}


def shortlist(metadata: pd.DataFrame) -> pd.DataFrame:
    """Tag variable metadata rows whose names or labels match a study concept."""

    metadata = metadata.loc[
        metadata["wave"].isin([2013, 2015, 2018])
        & metadata["file_name"].isin(SOURCE_FILES)
    ].copy()
    searchable = (
        metadata["variable"].fillna("").astype(str)
        + " "
        + metadata["variable_label"].fillna("").astype(str)
    )
    rows: list[pd.DataFrame] = []
    for concept, pattern in CONCEPT_PATTERNS.items():
        matched = metadata.loc[
            searchable.str.contains(re.compile(pattern, re.IGNORECASE), na=False)
        ].copy()
        matched.insert(0, "concept", concept)
        rows.append(matched)
    result = pd.concat(rows, ignore_index=True)
    return result.sort_values(["concept", "wave", "file_name", "position"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    args = parser.parse_args()
    metadata_path = args.report_dir / "raw_variable_metadata.csv"
    if not metadata_path.exists():
        raise FileNotFoundError("Run python -m src.inventory before candidate-field audit")
    metadata = pd.read_csv(metadata_path)
    result = shortlist(metadata)
    result.to_csv(
        args.report_dir / "candidate_field_shortlist.csv",
        index=False,
        encoding="utf-8-sig",
    )
    counts = result.groupby(["concept", "wave"]).size().unstack(fill_value=0)
    print(counts.to_string())


if __name__ == "__main__":
    main()
