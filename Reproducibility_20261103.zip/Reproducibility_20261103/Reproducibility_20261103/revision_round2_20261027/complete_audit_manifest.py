"""Complete variable-level skip assumptions and distribution ledgers."""
from pathlib import Path
import sys,json
import pandas as pd
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'reanalysis';sys.path.insert(0,str(OLD))
from src.model_config import FULL_MODEL_FEATURES
from src.wave_config import DISEASE_NAMES

def main():
    bounds=pd.read_csv(ROOT/'results/missing_outcome_scenarios.csv')
    bounds=bounds[bounds.population.eq('documented_alive')].copy()
    bounds['note']='Hypothetical scenarios among documented survivors only; no depressive outcomes are assigned to deaths or unknown vital status.'
    bounds.to_csv(ROOT/'results/missing_outcome_scenarios.csv',index=False,encoding='utf-8-sig')
    f=pd.read_csv(ROOT/'results/complete_field_mapping.csv')
    f.loc[f.variable.eq('partner_cohabiting'),'transformation']='valid marital codes 1-7; codes 1 or 7 -> 1, other valid codes -> 0; unknown remains missing'
    f.to_csv(ROOT/'results/complete_field_mapping.csv',index=False,encoding='utf-8-sig')
    rules={
     'baseline_age':('Attained years from interview year/month and birth year/month; invalid ages outside 0-120 missing; actual date preferred over ID-card date; direct age fallback in 2013.','No future data; 2013 birth history used where questionnaire supplies it.'),
     'sex':('Valid raw codes 1=male,2=female; other/missing responses remain missing.','No cross-wave inference beyond designated source field.'),
     'education':('Codes 1-11 mapped to six categories; 2013 update/prior/new-report cascade; 2015 updates 1-11 otherwise use saved 2013 education; 2018 current valid update only.','2015 explicitly carries available 2013 education; not a future carry-back.'),
     'partner_cohabiting':('Valid 1-7; codes 1 or 7 denote partner cohabitation; unknown remains missing.','None.'),
     'baseline_cesd10':('Ten raw responses 1-4; negative items x-1, positive items 4-x; >=8 answered -> mean*10, otherwise missing. Baseline must be <10.','No imputation across visits.'),
     'comorbidity_count':('Sum of 13 non-heart disease indicators only if all 13 are known; otherwise missing. Submitted 2015 derivation sets unresolved diseases to 0; sensitivity retains unknown.','Uses baseline prior-diagnosis fields; no follow-up disease responses.'),
     'disability':('Across prior/current disability items, any valid yes=1; otherwise any explicit no=0; completely unresolved remains missing.','Questionnaire-supplied prior disability only.'),
     'pain':('2013 any positive pain-site entry ->1, else0, including an entirely blank site list; 2015 da041 code1 ->1,code2 ->0; 2018 da041_w4 severity2-5 ->1,1 ->0.','No carry-forward. Constructs not identical: often-troubled vs any severity.'),
     'pain_site_count':('Count strictly positive site entries; 15 site slots in 2013,16 in 2015/2018; an entirely empty site list becomes0. Extra other-site option exists in later waves.','No carry-forward. Blank-as-zero is a skip assumption.'),
     'adl_score':('Six valid 1-4 items scored0-3 and summed; requires all items, otherwise missing.','No carry-forward; skipped functional questions can create structural missingness.'),
     'iadl_score':('Five valid 1-4 items scored0-3 and summed; requires all items, otherwise missing.','No carry-forward; item nonresponse and structural skips remain missing.'),
     'sleep_hours':('Numeric values restricted to0-24 hours; no logarithm; invalid responses missing.','None.'),
     'nap_minutes':('Numeric values restricted to0-1440 minutes; no logarithm; invalid responses missing.','None.'),
     'smoking_status':('2013 current/former from da061, never from explicit no-ever response; 2015 da061 then da061_w3 with codes1current,2former,3never and no-ever fallback; 2018 da061_w4 then da061 with no-ever fallback.','Prior-ever information supplied in baseline questionnaire; no future inference.'),
     'alcohol_frequency':('da067 codes1more-than-monthly,2monthly-or-less,3none; other values missing.','None.'),
     'self_rated_health':('Use valid formB da002,1verygood to5verypoor; if missing, align available formA da001 with1->1,2->1,3->2,4->3,5->4.','No longitudinal carry-forward; collapsed categories approximate randomized forms.'),
     'life_satisfaction':('Valid dc028 codes1-5; lower is more favorable; cognition module used in2018.','None.'),
     'social_activity_count':('Count selected activity entries in1-11; explicit none12 or0 gives0; wholly unresolved remains missing.','No carry-forward.'),
     'social_activity_frequency':('Valid frequency1-3 reversed to3-1; use maximum frequency across activities; force0 for no activity; missing if activity count unknown.','No carry-forward.')}
    for disease in DISEASE_NAMES.values():
        rules[disease]=('Prior/current codes1=yes,2=no; any yes ->1; otherwise any observed no ->0; unresolved missing, except submitted2015 unresolved ->0.','Prior diagnosis supplied by baseline questionnaire; no future information.')
    for variable,disease in [('hypertension_medication','hypertension'),('dyslipidemia_medication','dyslipidemia'),('heart_medication','heart_disease')]:
        rules[variable]=('Multi-select treatment codes1or2 ->use; known absence of disease ->0; diagnosed plus explicit none (3 for early hypertension,4/99 otherwise) ->0; remaining unresolved ->missing.','Disease-dependent skip assumption; follows same baseline disease derivation.')
    rows=[]
    for wave in [2013,2015,2018]:
        raw=pd.read_csv(OLD/f'data_interim/predictors_wave_{wave}.csv')
        demo=pd.read_csv(OLD/f'data_interim/demographics_wave_{wave}.csv')
        a=pd.read_csv(OLD/'data_processed/analysis_longitudinal.csv');a=a[a.baseline_wave.eq(wave)]
        for var in FULL_MODEL_FEATURES:
            mapping=f[(f.wave.eq(wave))&f.variable.eq(var)]
            rule,carry=rules[var]
            rows.append({'variable':var,'baseline_wave':wave,'raw_files':'|'.join(mapping.file.dropna().unique()),'raw_fields':'|'.join(mapping.field.dropna().unique()),'valid_and_special_codes':'See complete_field_mapping.csv value_labels and raw_field_value_counts.csv, including Stata special missing codes.','transformation_and_skip_assumption':rule,'carry_forward':carry,'eligible_n':len(a),'eligible_missing_n':int(a[var].isna().sum()),'eligible_mean_if_numeric':pd.to_numeric(a[var],errors='coerce').mean(),'code':'reanalysis/src/extract_predictors.py; extract_demographics.py; score_cesd.py; wave_config.py'})
    pd.DataFrame(rows).to_csv(ROOT/'results/variable_level_harmonization_audit.csv',index=False,encoding='utf-8-sig')
    profiles=[]
    from audit_data import profiles as makeprofiles
    for folder in (ROOT/'analyses').glob('*'):
        if not (folder/'COMPLETE.json').exists():continue
        d=pd.read_csv(ROOT/f'private_data/{folder.name}_development.csv');t=pd.read_csv(ROOT/f'private_data/{folder.name}_test.csv')
        frame=pd.concat([d.assign(dataset='development'),t.assign(dataset='test')])
        profiles.append(makeprofiles(frame,'dataset',folder.name))
    pd.concat(profiles,ignore_index=True).to_csv(ROOT/'results/alternative_design_predictor_profiles.csv',index=False,encoding='utf-8-sig')
    print('COMPLETE VARIABLE AUDIT',len(rows))

if __name__=='__main__':main()
