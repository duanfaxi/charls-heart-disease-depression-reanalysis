"""robustness analyses"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import warnings

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'reanalysis'
sys.path.insert(0, str(OLD))
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import roc_auc_score, average_precision_score, roc_curve
from sklearn.model_selection import GroupKFold, GridSearchCV, cross_val_predict
from src.model_config import BASIC_MODEL_FEATURES, FULL_MODEL_FEATURES
from src.train_logistic_models import build_pipeline, C_GRID
from src.tpot_fold_safe import encode_tpot_features
from src.train_tpot import run_searches, select_seed

def read(path):
    return pd.read_csv(path, dtype={'participant_id':str, 'ID':str})

def save(df, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding='utf-8-sig')

def hashed_development(participant_id):
    n = int(hashlib.sha256(('round2-99|' + str(participant_id)).encode()).hexdigest(), 16)
    return n / 2**256 < .7

def scenarios():
    a=read(OLD/'data_processed/analysis_longitudinal.csv')
    d=read(OLD/'data_processed/development.csv')
    t=read(OLD/'data_processed/temporal_test.csv')
    early=a[a.baseline_wave.isin([2013,2015])].copy()
    earliest=d.sort_values(['baseline_wave','participant_id']).drop_duplicates('participant_id')
    allocated=early[early.participant_id.map(hashed_development)].sort_values(['baseline_wave','participant_id']).drop_duplicates('participant_id')
    t_alloc=t[~t.participant_id.map(hashed_development)].copy()
    ds={
      'unweighted_original':(d,t,False,False),
      'two_year_2013':(d[d.baseline_wave.eq(2013)].copy(),t,True,True),
      'outcome_independent_id_allocation':(allocated,t_alloc,True,True),
      'earliest_original_development':(earliest,t,True,False),
    }
    for label,frame,testing in [('two_year_2013',d[d.baseline_wave.eq(2013)].copy(),t),('outcome_independent_id_allocation',allocated,t_alloc)]:
        if (ROOT/'analyses'/label/'COMPLETE.json').exists():
            ds[label+'_unweighted']=(frame,testing,False,False)
    corrected=ROOT/'private_data/analysis_2015_unknown_missing.csv'
    if corrected.exists():
        c=read(corrected)
        dc=d[['participant_id','baseline_wave']].merge(c,on=['participant_id','baseline_wave'],validate='one_to_one')
        ds['2015_unknown_missing']=(dc,t,True,False)
    return ds

def fit_logistic(d, features, tune, weighted):
    x=d[features]; y=d.target.astype(int); groups=d.participant_id
    est=build_pipeline(features)
    est.set_params(model__class_weight='balanced' if weighted else None)
    oof=np.full(len(d),np.nan); tuned=[]
    for fold,(tr,va) in enumerate(GroupKFold(5).split(x,y,groups)):
        e=clone(est)
        assert not set(groups.iloc[tr])&set(groups.iloc[va])
        if tune:
            s=GridSearchCV(e,{'model__C':C_GRID},scoring='roc_auc',cv=GroupKFold(5),n_jobs=2)
            s.fit(x.iloc[tr],y.iloc[tr],groups=groups.iloc[tr]); e=s.best_estimator_
        else: e.fit(x.iloc[tr],y.iloc[tr])
        oof[va]=e.predict_proba(x.iloc[va])[:,1]
        tuned.append({'fold':fold,'C':e.named_steps['model'].C})
    if tune:
        s=GridSearchCV(est,{'model__C':C_GRID},scoring='roc_auc',cv=GroupKFold(5),n_jobs=2)
        s.fit(x,y,groups=groups); est=s.best_estimator_
    else: est.fit(x,y)
    return est,oof,tuned

def fit_fixed_tpot(d, weighted, model_path=None):
    e=clone(joblib.load(model_path or OLD/'models/tpot_final_pipeline.joblib'))
    changes={k:('balanced' if weighted else None) for k in e.get_params() if k.endswith('class_weight')}
    if not weighted:
        changes.update({k:1.0 for k in e.get_params() if k.endswith('scale_pos_weight')})
    e.set_params(**changes)
    x=encode_tpot_features(d).to_numpy(); y=d.target.astype(int).to_numpy()
    oof=cross_val_predict(e,x,y,groups=d.participant_id,cv=GroupKFold(5),method='predict_proba',n_jobs=2)[:,1]
    e.fit(x,y)
    return e,oof

def fit_search_tpot(d, dest):
    # Retain the original search budget; changing cohort is the intervention.
    s, fitted, oof=run_searches(d,[11,29,47,71,99],5,50,120,10,dest/'models',dest/'logs')
    summary=pd.DataFrame(s); seed=select_seed(summary)
    summary['selected']=summary.seed.eq(seed)
    save(summary,dest/'tpot_search_summary.csv')
    save(oof,dest/'private_tpot_oof_all_seeds.csv')
    return fitted[seed].fitted_pipeline_,oof.loc[oof.seed.eq(seed),'oof_probability'].to_numpy(),seed

def run(name, d, t, weighted, search):
    dest=ROOT/'analyses'/name; dest.mkdir(parents=True,exist_ok=True)
    if (dest/'COMPLETE.json').exists():
        print('REUSE',name,flush=True); return
    d=d.reset_index(drop=True);t=t.reset_index(drop=True)
    assert not set(d.participant_id)&set(t.participant_id)
    assert not t.participant_id.duplicated().any()
    save(d,ROOT/'private_data'/f'{name}_development.csv')
    save(t,ROOT/'private_data'/f'{name}_test.csv')
    folds=[]
    for f,(tr,va) in enumerate(GroupKFold(5).split(d,d.target,d.participant_id)):
        for idx in va: folds.append({'participant_id':d.iloc[idx].participant_id,'baseline_wave':int(d.iloc[idx].baseline_wave),'fold':f})
    save(pd.DataFrame(folds),dest/'private_grouped_folds.csv')
    counts={'scenario':name,'development_records':len(d),'development_participants':d.participant_id.nunique(),'development_events':int(d.target.sum()),'development_event_rate':float(d.target.mean()),'test_n':len(t),'test_events':int(t.target.sum()),'test_event_rate':float(t.target.mean()),'id_overlap':0,'weighted':weighted,'new_tpot_search':search}
    (dest/'design.json').write_text(json.dumps(counts,indent=2),encoding='utf8')
    preds=[]; cv=[]
    for model,features,tune in [('basic_logistic',BASIC_MODEL_FEATURES,False),('full_penalized_logistic',FULL_MODEL_FEATURES,True)]:
        print('FIT',name,model,flush=True)
        e,oof,tuning=fit_logistic(d,features,tune,weighted)
        (dest/'models').mkdir(exist_ok=True)
        joblib.dump(e,dest/'models'/f'{model}.joblib')
        p=e.predict_proba(t[features])[:,1]
        fpr,tpr,th=roc_curve(d.target,oof);valid=np.isfinite(th);threshold=float(th[valid][np.argmax((tpr-fpr)[valid])])
        cv.append({'model':model,'oof_auc':roc_auc_score(d.target,oof),'oof_ap':average_precision_score(d.target,oof),'threshold':threshold,'C':e.named_steps['model'].C,'method':'nested_grouped' if tune else 'grouped_fixed'})
        preds.append(t[['participant_id','baseline_wave','target','sex']].assign(model=model,probability=p))
        save(d[['participant_id','baseline_wave','target']].assign(probability=oof),dest/f'private_{model}_oof.csv')
        save(pd.DataFrame(tuning),dest/f'{model}_fold_tuning.csv')
    print('FIT',name,'TPOT search' if search else 'fixed TPOT architecture',flush=True)
    if search: e,oof,seed=fit_search_tpot(d,dest)
    else:
        parent=name.removesuffix('_unweighted') if name.endswith('_unweighted') else None
        parentpath=ROOT/'analyses'/parent/'models/tpot.joblib' if parent else None
        e,oof=fit_fixed_tpot(d,weighted,parentpath if parentpath and parentpath.exists() else None);seed=29
        if parentpath and parentpath.exists():
            selected=pd.read_csv(parentpath.parents[1]/'tpot_search_summary.csv')
            seed=int(selected.loc[selected.selected,'seed'].iloc[0])
    joblib.dump(e,dest/'models/tpot.joblib')
    p=e.predict_proba(encode_tpot_features(t).to_numpy())[:,1]
    fpr,tpr,th=roc_curve(d.target,oof);valid=np.isfinite(th);threshold=float(th[valid][np.argmax((tpr-fpr)[valid])])
    cv.append({'model':'tpot','oof_auc':roc_auc_score(d.target,oof),'oof_ap':average_precision_score(d.target,oof),'threshold':threshold,'selected_seed':seed,'method':'post_search_same_folds' if search else 'fixed_architecture_grouped'})
    preds.append(t[['participant_id','baseline_wave','target','sex']].assign(model='tpot',probability=p))
    save(d[['participant_id','baseline_wave','target']].assign(probability=oof),dest/'private_tpot_oof.csv')
    save(pd.concat(preds),dest/'private_test_predictions.csv')
    save(pd.DataFrame(cv),dest/'development_performance.csv')
    (dest/'COMPLETE.json').write_text(json.dumps({'completed_at':time.strftime('%Y-%m-%dT%H:%M:%S'),'design':counts},indent=2),encoding='utf8')
    print('COMPLETE',name,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--scenarios',nargs='*');args=parser.parse_args()
    for name,values in scenarios().items():
        if args.scenarios and name not in args.scenarios: continue
        run(name,*values)
