"""Reproduce the submitted and second-round analyses from authorized inputs."""
from pathlib import Path
import argparse,subprocess,sys
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'reanalysis'
def run(args,cwd=ROOT):subprocess.run([sys.executable,*map(str,args)],cwd=cwd,check=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['data','submitted','round2','smoke','verify','all']);a=p.parse_args()
    if a.stage in ['data','all']:
        for module in ['src.inventory','src.extract_core','src.extract_demographics','src.extract_predictors','src.build_windows','src.assemble_analysis','src.build_dictionary']:
            run(['-m',module],OLD)
    if a.stage in ['submitted','all']:
        for module in ['src.train_logistic_models','src.train_tpot','src.run_sensitivity_analyses','src.analyze_sex_performance','src.generate_publication_outputs','publication.final_figures']:
            run(['-m',module],OLD)
    if a.stage in ['round2','all']:
        run([ROOT/'audit_data.py'])
        run([ROOT/'verify_raw_sources.py'])
        run([ROOT/'run_models.py'])
        # Search-dependent unweighted scenarios are discovered on a second pass.
        run([ROOT/'run_models.py','--scenarios','two_year_2013_unweighted','outcome_independent_id_allocation_unweighted'])
        run([ROOT/'evaluate_results.py']);run([ROOT/'complete_audit_manifest.py']);run([ROOT/'make_figures.py'])
    if a.stage in ['smoke','all']:run([ROOT/'synthetic_smoke.py'])
    if a.stage in ['verify','all']:run([ROOT/'verify_analysis.py'])
