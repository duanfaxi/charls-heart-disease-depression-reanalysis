"""Exercise raw-wave linkage, CESD scoring, harmonization and fitted prediction on artificial records."""
from pathlib import Path
import sys,tempfile,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'reanalysis';sys.path.insert(0,str(OLD))
from src import paths
from src.wave_config import CESD_CONFIG, HEART_CONFIG
from src.extract_predictors import _all_required_fields,extract_wave_predictors
from src.extract_core import extract_wave_core
from src.extract_demographics import extract_demographics_by_wave
from src.build_windows import build_one_window
from src.assemble_analysis import assemble,split_temporally
from src.model_config import BASIC_MODEL_FEATURES,FULL_MODEL_FEATURES
from src.train_logistic_models import build_pipeline
from src.tpot_fold_safe import encode_tpot_features,FoldSafeTPOTClassifier
from sklearn.base import clone
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score,brier_score_loss
import joblib

def main():
    n=360;ix=np.arange(n);ids=[f'{i:012d}' for i in ix]
    original_paths=paths.RAW_WAVE_DIRS.copy()
    with tempfile.TemporaryDirectory(prefix='charls_synthetic_') as tmp:
        for wave in [2013,2015,2018,2020]:
            folder=Path(tmp)/str(wave);folder.mkdir();paths.RAW_WAVE_DIRS[wave]=folder
            fields=set(_all_required_fields(wave) if wave<2020 else ['ID'])
            fields.update(CESD_CONFIG[wave]['items']);fields.add('dc028');fields.update([HEART_CONFIG[wave]['prior'],HEART_CONFIG[wave]['current']])
            if 'status' in HEART_CONFIG[wave]:fields.add(HEART_CONFIG[wave]['status'])
            health=pd.DataFrame({f:np.ones(n,dtype=float) for f in fields if f!='ID'});health.insert(0,'ID',ids)
            for f in health.columns:
                if f.startswith('da042'):health[f]=np.where(ix%3==0,1.,np.nan)
            for f in ['da049','da050']:
                if f in health:health[f]=6. if f=='da049' else 30.
            high=(ix+{2013:0,2015:1,2018:2,2020:3}[wave])%5==0
            for f in CESD_CONFIG[wave]['items']:
                health[f]=np.where(high,3.,1.)
                if f in CESD_CONFIG[wave]['reverse']:health[f]=np.where(high,2.,4.)
            health.to_stata(folder/'Health_Status_and_Functioning.dta',write_index=False,version=118)
            if wave==2018:health[['ID',*CESD_CONFIG[wave]['items'],'dc028']].to_stata(folder/'Cognition.dta',write_index=False,version=118)
            demo=pd.DataFrame({'ID':ids})
            for f in ['zba002_1','ba002_1','ba004_w3_1']:demo[f]=1950+(ix%20)
            for f in ['zba002_2','ba002_2','ba004_w3_2']:demo[f]=1.
            for f in ['ba004','ba000_w2_3','xrgender','zbd001','bd001','bd001_w2_4','be001']:
                demo[f]=np.where(ix%2==0,1.,2.) if f in ['ba000_w2_3','xrgender'] else (65. if f=='ba004' else 4. if 'bd001' in f else 1.)
            demo.to_stata(folder/'Demographic_Background.dta',write_index=False,version=118)
            dates=pd.DataFrame({'ID':ids,'iyear':float(wave),'imonth':6.})
            dates.to_stata(folder/('Weights.dta' if wave==2013 else 'Sample_Infor.dta'),write_index=False,version=118)
        core={w:extract_wave_core(w)[0] for w in [2013,2015,2018,2020]}
        demo=extract_demographics_by_wave()
        windows=[build_one_window(core[w],demo[w],core[v],w,v)[0] for w,v in [(2013,2015),(2015,2018),(2018,2020)]]
        predictors={w:extract_wave_predictors(w) for w in [2013,2015,2018]}
        a=assemble(pd.concat(windows,ignore_index=True),predictors);d,t,report=split_temporally(a)
        assert set(FULL_MODEL_FEATURES).issubset(a.columns)
        assert len(d)>0 and len(t)>0 and report.final_id_overlap.iloc[0]==0
        checks=[]
        for model,features in [('basic_logistic',BASIC_MODEL_FEATURES),('full_penalized_logistic',FULL_MODEL_FEATURES)]:
            e=build_pipeline(features);e.fit(d[features],d.target);p=e.predict_proba(t[features])[:,1]
            checks.append({'model':model,'n':len(t),'finite_probabilities':bool(np.isfinite(p).all()),'auc':roc_auc_score(t.target,p),'brier':brier_score_loss(t.target,p)})
        original=clone(joblib.load(OLD/'models/tpot_final_pipeline.joblib'))
        original.fit(encode_tpot_features(d).to_numpy(),d.target);p=original.predict_proba(encode_tpot_features(t).to_numpy())[:,1]
        checks.append({'model':'selected_tpot_architecture','n':len(t),'finite_probabilities':bool(np.isfinite(p).all()),'auc':roc_auc_score(t.target,p),'brier':brier_score_loss(t.target,p)})
        tiny=FoldSafeTPOTClassifier(generations=1,population_size=4,scoring='roc_auc',cv=GroupKFold(3),n_jobs=1,max_time_mins=2,max_eval_time_mins=1,random_state=99,verbosity=0,disable_update_check=True,config_dict={'sklearn.ensemble.RandomForestClassifier':{'n_estimators':[10],'max_depth':[2,3],'class_weight':[None]}})
        tiny.fit(encode_tpot_features(d).to_numpy(),d.target.to_numpy(),groups=d.participant_id.to_numpy())
        p=tiny.fitted_pipeline_.predict_proba(encode_tpot_features(t).to_numpy())[:,1]
        checks.append({'model':'tiny_tpot_search_execution_only','n':len(t),'finite_probabilities':bool(np.isfinite(p).all()),'auc':roc_auc_score(t.target,p),'brier':brier_score_loss(t.target,p)})
        out={'synthetic_only':True,'raw_wave_modules':4,'eligible_records':len(a),'development_records':len(d),'test_records':len(t),'zero_id_overlap':True,'checks':checks,'note':'This smoke test checks execution and output schema, including a tiny bounded evolutionary search. Artificial performance is not scientific evidence and is unrelated to the full empirical search results.'}
        (ROOT/'results').mkdir(exist_ok=True);(ROOT/'results/synthetic_smoke_result.json').write_text(json.dumps(out,indent=2),encoding='utf8')
        print(json.dumps(out,indent=2))
    paths.RAW_WAVE_DIRS.clear();paths.RAW_WAVE_DIRS.update(original_paths)

if __name__=='__main__':main()
