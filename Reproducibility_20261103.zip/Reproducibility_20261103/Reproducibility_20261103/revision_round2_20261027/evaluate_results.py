"""Paired participant bootstrap, probability uncertainty, and response weighting."""
from pathlib import Path
import sys,json,warnings
import numpy as np
import pandas as pd
from scipy.special import expit,logit
from sklearn.base import clone
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score,average_precision_score

ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'reanalysis';sys.path.insert(0,str(OLD))
from src.train_logistic_models import build_pipeline
from src.model_config import FULL_MODEL_FEATURES

def read(p):return pd.read_csv(p,dtype={'participant_id':str})
def save(d,n):
    p=ROOT/'results'/n;p.parent.mkdir(parents=True,exist_ok=True);d.to_csv(p,index=False,encoding='utf-8-sig')

def calibration(y,p,w):
    x=logit(np.clip(p,1e-6,1-1e-6));X=np.column_stack([np.ones(len(y)),x]);b=np.array([0.,1.])
    for _ in range(45):
        mu=expit(X@b);v=np.maximum(mu*(1-mu),1e-10)*w
        h=X.T@(v[:,None]*X);g=X.T@(w*(y-mu))
        try:step=np.linalg.solve(h,g)
        except np.linalg.LinAlgError:return np.array([np.nan,np.nan])
        if not np.all(np.isfinite(step)):return np.array([np.nan,np.nan])
        step=np.clip(step,-5,5);b+=step
        if max(abs(step))<1e-7:break
    else:return np.array([np.nan,np.nan])
    return b

NAMES=['roc_auc','average_precision','brier_score','calibration_intercept','calibration_slope','scaled_brier','mean_prediction']
def stats(y,p,w=None):
    if w is None:w=np.ones(len(y))
    rate=np.average(y,weights=w);brier=np.average((p-y)**2,weights=w);inter,slope=calibration(y,p,w)
    return np.array([roc_auc_score(y,p,sample_weight=w),average_precision_score(y,p,sample_weight=w),brier,inter,slope,1-brier/(rate*(1-rate)),np.average(p,weights=w)])

def evaluate(scenario,frame,iterations=2000):
    wide=frame.pivot(index='participant_id',columns='model',values='probability').sort_index()
    meta=frame.drop_duplicates('participant_id').set_index('participant_id').loc[wide.index]
    assert not wide.isna().any().any()
    y=meta.target.to_numpy(int);w=meta.weight.to_numpy(float) if 'weight' in meta else np.ones(len(y));models=list(wide.columns)
    points=np.stack([stats(y,wide[m].to_numpy(),w) for m in models]);boot=np.empty((iterations,len(models),len(NAMES)))
    rng=np.random.default_rng(20261027)
    for b in range(iterations):
        ix=rng.integers(0,len(y),len(y))
        for j,m in enumerate(models):boot[b,j]=stats(y[ix],wide[m].to_numpy()[ix],w[ix])
    rows=[]
    for j,m in enumerate(models):
        row={'scenario':scenario,'model':m,'n':len(y),'events':int(y.sum()),'observed_event_rate':y.mean(),'weighted_event_rate':np.average(y,weights=w)}
        for k,name in enumerate(NAMES):
            ok=np.isfinite(boot[:,j,k]);row[name]=points[j,k];row[name+'_low']=np.quantile(boot[ok,j,k],.025);row[name+'_high']=np.quantile(boot[ok,j,k],.975);row[name+'_valid_bootstrap']=int(ok.sum())
        rows.append(row)
    diffs=[]
    comparisons=[('tpot','basic_logistic'),('tpot','full_penalized_logistic'),('full_penalized_logistic','basic_logistic')]
    # Alternative-vs-submitted differences use exactly the same sampled people.
    comparisons += [(m,'submitted_'+m) for m in ['basic_logistic','full_penalized_logistic','tpot'] if 'submitted_'+m in models]
    for a,b in comparisons:
        if a not in models or b not in models:continue
        ai=models.index(a);bi=models.index(b)
        for k,name in enumerate(NAMES[:3]):
            vals=boot[:,ai,k]-boot[:,bi,k]
            diffs.append({'scenario':scenario,'model_a':a,'model_b':b,'difference':'a minus b','metric':name,'estimate':points[ai,k]-points[bi,k],'low':np.quantile(vals,.025),'high':np.quantile(vals,.975),'n':len(y),'bootstrap_iterations':iterations})
    return pd.DataFrame(rows),pd.DataFrame(diffs)

def primary():
    l=read(OLD/'reports/generated/logistic_temporal_test_predictions.csv')
    t=read(OLD/'reports/generated/tpot_temporal_test_predictions.csv');t['model']='tpot'
    return pd.concat([l,t],ignore_index=True)[['participant_id','baseline_wave','target','sex','model','probability']]

def observation_weights():
    p=ROOT/'private_data/baseline_eligible_response_risksets.csv'
    if not p.exists():return None
    risk=read(p);info=[];weightframes=[]
    for wave,allrows in risk.groupby('baseline_wave'):
        # Restrict to documented survivors; unknown mortality is reported separately.
        f=allrows[allrows.vital_status.eq('documented_alive')].copy().reset_index(drop=True)
        x=f[FULL_MODEL_FEATURES];y=f.observed.astype(int);g=f.participant_id
        oof=np.full(len(f),np.nan)
        for tr,va in GroupKFold(5).split(x,y,g):
            est=build_pipeline(FULL_MODEL_FEATURES);est.set_params(model__class_weight=None,model__C=1.)
            est.fit(x.iloc[tr],y.iloc[tr]);oof[va]=est.predict_proba(x.iloc[va])[:,1]
        f['observation_probability_raw']=oof;f['observation_probability_used']=np.clip(oof,.05,.95)
        f['weight']=y.mean()/f.observation_probability_used
        observed=f[f.observed.eq(1)].copy()
        info.append({'baseline_wave':wave,'documented_alive_n':len(f),'responders':int(y.sum()),'response_rate':y.mean(),'observation_oof_auc':roc_auc_score(y,oof),'probability_clipped_n':int((f.observation_probability_raw!=f.observation_probability_used).sum()),'weight_min':observed.weight.min(),'weight_max':observed.weight.max(),'effective_sample_size':observed.weight.sum()**2/(observed.weight**2).sum(),'method':'grouped five-fold cross-fitted response model; C=1; no outcome class weights; stabilized weights; response probabilities clipped to [0.05,0.95]'})
        weightframes.append(f[['participant_id','baseline_wave','observed','weight','observation_probability_raw','observation_probability_used']])
    out=pd.concat(weightframes,ignore_index=True);out.to_csv(ROOT/'private_data/response_weights.csv',index=False)
    save(pd.DataFrame(info),'response_weight_diagnostics.csv')
    return out

def main():
    original=primary();out=[];pairs=[]
    print('EVALUATE submitted_primary',flush=True)
    a,b=evaluate('submitted_primary',original);out.append(a);pairs.append(b)
    for dest in (ROOT/'analyses').glob('*'):
        if not (dest/'COMPLETE.json').exists():continue
        frame=read(dest/'private_test_predictions.csv')
        ids=set(frame.participant_id)
        reference=original[original.participant_id.isin(ids)].copy();reference['model']='submitted_'+reference.model
        assert set(reference.participant_id)==ids
        print('EVALUATE',dest.name,flush=True)
        a,b=evaluate(dest.name,pd.concat([frame,reference],ignore_index=True));out.append(a);pairs.append(b)
    weights=observation_weights()
    if weights is not None:
        w=weights[weights.baseline_wave.eq(2018)&weights.observed.eq(1)][['participant_id','weight']]
        for scenario,frame in [('submitted_primary',original),('unweighted_original',read(ROOT/'analyses/unweighted_original/private_test_predictions.csv'))]:
            frame=frame.merge(w,on='participant_id',validate='many_to_one')
            print('EVALUATE observation_weighted',scenario,flush=True)
            a,b=evaluate('observation_weighted_'+scenario,frame);out.append(a);pairs.append(b)
    save(pd.concat(out,ignore_index=True),'model_metrics_with_intervals.csv')
    save(pd.concat(pairs,ignore_index=True),'paired_model_differences.csv')
    print('EVALUATION COMPLETE',flush=True)

if __name__=='__main__':main()
