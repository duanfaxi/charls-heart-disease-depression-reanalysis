"""Verify demographic harmonization and core CESD/heart scoring against authorized raw modules."""
from pathlib import Path
import sys
import pandas as pd
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'reanalysis';sys.path.insert(0,str(OLD))
from src.extract_core import extract_wave_core
from src.extract_demographics import extract_demographics_by_wave
def compare(old,new,fields,wave):
    old.ID=old.ID.astype(str);new.ID=new.ID.astype(str)
    assert set(old.ID)==set(new.ID),(wave,'source ID inventory differs')
    p=old.merge(new,on='ID',suffixes=('_old','_new'),validate='one_to_one');rows=[]
    for f in fields:
        a=p[f+'_old'].astype('string').fillna('<NA>');b=p[f+'_new'].astype('string').fillna('<NA>')
        x=pd.to_numeric(a,errors='coerce');y=pd.to_numeric(b,errors='coerce')
        same=a.eq(b)|((x-y).abs()<1e-9)
        count=int((~same.fillna(False)).sum());assert count==0,(wave,f,count)
        rows.append({'wave':wave,'variable':f,'matched_ids':len(p),'disagreements':count})
    return rows
def main():
    rows=[];demo=extract_demographics_by_wave()
    for wave,new in demo.items():
        old=pd.read_csv(OLD/f'data_interim/demographics_wave_{wave}.csv',dtype={'ID':str})
        rows+=compare(old,new,['age','sex','education','partner_cohabiting'],wave)
    for wave in [2013,2015,2018,2020]:
        new=extract_wave_core(wave)[0];old=pd.read_csv(OLD/f'data_interim/core_wave_{wave}.csv',dtype={'ID':str})
        rows+=compare(old,new,['cesd_adjusted_score','heart_disease'],wave)
    p=ROOT/'results/raw_rebuild_verification.csv';existing=pd.read_csv(p)
    pd.concat([existing,pd.DataFrame(rows)],ignore_index=True).drop_duplicates(['wave','variable'],keep='last').to_csv(p,index=False,encoding='utf-8-sig')
    print('VERIFIED demographics, CESD scoring and heart-disease fields:',len(rows),'checks')
if __name__=='__main__':main()
