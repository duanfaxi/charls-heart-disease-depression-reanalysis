"""Rebuild source audits and response-risk sets without overwriting prior outputs."""
from pathlib import Path
import sys
import json
import hashlib
import numpy as np
import pandas as pd
from pandas.io.stata import StataReader

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'reanalysis'
sys.path.insert(0,str(OLD))
from src.extract_predictors import extract_wave_predictors, derive_medication, valid_numeric
from src.derive_disease import derive_heart_disease
from src.model_config import FULL_MODEL_FEATURES
from src.wave_config import PREDICTOR_CONFIG, DISEASE_NAMES, CESD_CONFIG
from src.paths import RAW_WAVE_DIRS

def read(p): return pd.read_csv(p,dtype={'ID':str,'participant_id':str})
def save(df,name,private=False):
    p=ROOT/('private_data' if private else 'results')/name
    p.parent.mkdir(parents=True,exist_ok=True);df.to_csv(p,index=False,encoding='utf-8-sig')

def profiles(frame,group,scope):
    rows=[]
    for g,sub in frame.groupby(group,dropna=False):
        for f in FULL_MODEL_FEATURES:
            if f not in sub: continue
            n=sub[f].notna().sum(); num=pd.to_numeric(sub[f],errors='coerce')
            if num.notna().sum()==n:
                rows.append({'scope':scope,'group':g,'variable':f,'level':'numeric','n':len(sub),'nonmissing':n,'mean':num.mean(),'sd':num.std(),'value_n':np.nan,'percent':np.nan})
            else:
                for level,count in sub[f].value_counts(dropna=False).items():
                    rows.append({'scope':scope,'group':g,'variable':f,'level':str(level),'n':len(sub),'nonmissing':n,'mean':np.nan,'sd':np.nan,'value_n':count,'percent':100*count/len(sub)})
    return pd.DataFrame(rows)

def run():
    original=read(OLD/'data_processed/analysis_longitudinal.csv')
    allpred={}; verification=[]; distribution=[]; rawframes={}; missingrows=[]
    for wave in [2013,2015,2018]:
        print('RAW REBUILD',wave,flush=True)
        fresh=extract_wave_predictors(wave);fresh.ID=fresh.ID.astype(str)
        prior=read(OLD/f'data_interim/predictors_wave_{wave}.csv')
        paired=prior.merge(fresh,on='ID',suffixes=('_old','_new'),validate='one_to_one')
        for f in fresh.columns.difference(['ID','wave']):
            a=paired[f+'_old'].astype('string').fillna('<NA>');b=paired[f+'_new'].astype('string').fillna('<NA>')
            # CSV round trips change nullable-integer presentation only.
            an=pd.to_numeric(a,errors='coerce');bn=pd.to_numeric(b,errors='coerce')
            same=a.eq(b)|((an-bn).abs()<1e-9)|(an.isna()&bn.isna()&a.eq(b))
            verification.append({'wave':wave,'variable':f,'matched_ids':len(paired),'disagreements':int((~same).sum())})
        allpred[wave]=fresh
        path=RAW_WAVE_DIRS[wave]/'Health_Status_and_Functioning.dta'
        raw=pd.read_stata(path,convert_categoricals=False,preserve_dtypes=False);raw.ID=raw.ID.astype(str).str.strip()
        rawframes[wave]=raw
        for f in fresh.columns.difference(['ID','wave']):
            num=pd.to_numeric(fresh[f],errors='coerce')
            distribution.append({'wave':wave,'variable':f,'n':len(fresh),'missing':int(fresh[f].isna().sum()),'mean':num.mean(),'sd':num.std(),'positive':int(num.eq(1).sum())})
        if wave==2015:
            corrected=fresh.copy()
            for idx,f in DISEASE_NAMES.items():
                cfg=PREDICTOR_CONFIG[wave]
                mapped=derive_heart_disease(raw[cfg['disease_prior_prefix'].format(index=idx)],raw[cfg['disease_current_prefix'].format(index=idx)])['heart_disease']
                corrected[f]=mapped
                unresolved=mapped.isna()
                missingrows.append({'variable':f,'wave':wave,'raw_n':len(raw),'unresolved_n':int(unresolved.sum()),'eligible_2015_affected_n':int(raw.loc[unresolved,'ID'].isin(original.loc[original.baseline_wave.eq(2015),'participant_id']).sum()),'original_rule':'unknown becomes 0','alternative_rule':'unknown remains missing'})
            countcols=[f for f in DISEASE_NAMES.values() if f!='heart_disease']
            corrected['comorbidity_count']=corrected[countcols].sum(axis=1,min_count=len(countcols))
            for f,cols in PREDICTOR_CONFIG[2015]['medication'].items():
                disease={'hypertension_medication':'hypertension','dyslipidemia_medication':'dyslipidemia','heart_medication':'heart_disease'}[f]
                corrected[f]=derive_medication(raw[cols],corrected[disease],{3} if disease=='hypertension' else {4,99})
            c=original.copy(); idx=c.baseline_wave.eq(2015)
            for f in [*countcols,'comorbidity_count','hypertension_medication','dyslipidemia_medication','heart_medication']:
                c.loc[idx,f]=c.loc[idx,'participant_id'].map(corrected.set_index('ID')[f])
            save(c,'analysis_2015_unknown_missing.csv',True)
    save(pd.DataFrame(verification),'raw_rebuild_verification.csv')
    assert sum(x['disagreements'] for x in verification)==0,'New raw modules do not reproduce saved predictors; investigate before modeling.'
    save(pd.DataFrame(distribution),'harmonized_all_respondent_distribution.csv')
    save(pd.DataFrame(missingrows),'2015_unknown_sensitivity_counts.csv')
    dictionary=read(OLD/'reports/generated/variable_dictionary.csv')
    mappings=[];rawcounts=[]
    cache={}
    for _,r in dictionary.iterrows():
        wave=int(r.wave)
        files=str(r.source_file).split('|');fields=str(r.source_fields).split('|')
        for field in fields:
            found=False
            for fn in files:
                path=RAW_WAVE_DIRS[wave]/fn
                if not path.exists(): continue
                key=(wave,fn)
                if key not in cache:
                    with StataReader(path,convert_categoricals=False) as rr:
                        labels=rr.variable_labels();values=rr.value_labels();varlist=list(rr._varlist);lbllist=list(rr._lbllist)
                    data=pd.read_stata(path,convert_categoricals=False,convert_missing=True,preserve_dtypes=False)
                    cache[key]=(labels,values,varlist,lbllist,data)
                labels,values,varlist,lbllist,data=cache[key]
                if field not in labels: continue
                found=True
                vlabels=values.get(lbllist[varlist.index(field)],{})
                rule=str(r.transformation)
                if wave==2015 and (r.unified_variable in DISEASE_NAMES.values() or r.unified_variable=='comorbidity_count'):
                    rule+='; submitted analysis sets unresolved prior/current disease responses to absence; reviewer sensitivity retains unknown'
                mappings.append({'variable':r.unified_variable,'wave':wave,'file':fn,'field':field,'label':labels[field],'value_labels':json.dumps({str(k):v for k,v in vlabels.items()},ensure_ascii=False),'transformation':rule,'status':'verified raw field'})
                for value,count in data[field].astype(str).value_counts(dropna=False).items():
                    rawcounts.append({'wave':wave,'file':fn,'field':field,'raw_value':value,'count':int(count)})
                break
            if not found: mappings.append({'variable':r.unified_variable,'wave':wave,'field':field,'file':str(r.source_file),'status':'not an individual raw field; inspect derivation','transformation':str(r.transformation)})
    save(pd.DataFrame(mappings),'complete_field_mapping.csv')
    save(pd.DataFrame(rawcounts).drop_duplicates(),'raw_field_value_counts.csv')
    # Within-person comparisons reduce, but do not eliminate, case-mix explanations.
    shifts=[]
    for w1,w2 in [(2013,2015),(2015,2018)]:
        pair=allpred[w1].merge(allpred[w2],on='ID',suffixes=('_a','_b'),validate='one_to_one')
        for f in ['hypertension','dyslipidemia','diabetes','stroke','pain','pain_site_count','comorbidity_count','adl_score']:
            a=pd.to_numeric(pair[f+'_a'],errors='coerce');b=pd.to_numeric(pair[f+'_b'],errors='coerce');ok=a.notna()&b.notna()
            shifts.append({'from_wave':w1,'to_wave':w2,'variable':f,'paired_complete_n':int(ok.sum()),'mean_from':a[ok].mean(),'mean_to':b[ok].mean(),'mean_change':(b[ok]-a[ok]).mean(),'decreased_n':int((b[ok]<a[ok]).sum()),'increased_n':int((b[ok]>a[ok]).sum())})
    save(pd.DataFrame(shifts),'matched_person_wave_shifts.csv')
    summary=[];frames=[];base_profiles=[];selection=[]
    testids=set(original.loc[original.baseline_wave.eq(2018),'participant_id'])
    for wave,nextwave in [(2013,2015),(2015,2018),(2018,2020)]:
        core=read(OLD/f'data_interim/core_wave_{wave}.csv')
        demo=read(OLD/f'data_interim/demographics_wave_{wave}.csv')
        outcome=read(OLD/f'data_interim/core_wave_{nextwave}.csv')
        f=core.merge(demo.drop(columns=['wave']),on='ID',validate='one_to_one')
        f=f.loc[f.age.ge(45)&f.heart_disease.eq(1)&f.cesd_adjusted_score.lt(10)].copy()
        f=f[['ID','age','cesd_adjusted_score','sex','education','partner_cohabiting']].rename(columns={'age':'baseline_age','cesd_adjusted_score':'baseline_cesd10'})
        out=outcome[['ID','cesd_adjusted_score','cesd_module_present']].rename(columns={'cesd_adjusted_score':'followup_cesd'})
        f=f.merge(out,on='ID',how='left',validate='one_to_one')
        pred=allpred[wave].drop(columns=['wave','heart_disease'],errors='ignore')
        f=f.merge(pred,on='ID',how='left',validate='one_to_one')
        samplepath=RAW_WAVE_DIRS[nextwave]/'Sample_Infor.dta'
        status=pd.read_stata(samplepath,columns=['ID','died'],convert_categoricals=False);status.ID=status.ID.astype(str).str.strip()
        status=status.drop_duplicates('ID');f=f.merge(status,on='ID',how='left',validate='one_to_one')
        f['observed']=f.followup_cesd.notna().astype(int)
        f['disposition']=np.where(f.observed.eq(1),'valid_followup',np.where(f.cesd_module_present.eq(True),'insufficient_items','not_linked'))
        f['vital_status']=f.died.map({0:'documented_alive',1:'documented_dead'}).fillna('unknown')
        f['baseline_wave']=wave;f['outcome_wave']=nextwave
        f['target']=np.where(f.observed.eq(1),f.followup_cesd.ge(10).astype(int),np.nan)
        if (f.observed.eq(1)&f.died.eq(1)).any(): raise AssertionError('Observed depression outcome and death status conflict')
        for (disp,vital),sub in f.groupby(['disposition','vital_status']):
            summary.append({'baseline_wave':wave,'outcome_wave':nextwave,'disposition':disp,'vital_status':vital,'n':len(sub),'events':int(sub.target.fillna(0).sum()) if disp=='valid_followup' else np.nan})
        base_profiles.append(profiles(f,'disposition',f'{wave}-{nextwave}'))
        if wave<2018:
            f['removed_for_test_id']=f.ID.isin(testids)
            for (removed,vital,obs),sub in f.groupby(['removed_for_test_id','vital_status','observed']):
                selection.append({'baseline_wave':wave,'removed_for_test_id':removed,'followup_vital_status':vital,'followup_observed':obs,'n':len(sub),'events':int(sub.target.fillna(0).sum())})
        f=f.rename(columns={'ID':'participant_id'});frames.append(f)
    risk=pd.concat(frames,ignore_index=True)
    save(risk,'baseline_eligible_response_risksets.csv',True)
    save(pd.DataFrame(summary),'followup_disposition_by_wave.csv')
    save(pd.concat(base_profiles),'included_excluded_baseline_profiles.csv')
    save(pd.DataFrame(selection),'retention_vs_test_id_selection.csv')
    bounds=[]
    for wave,sub in risk.groupby('baseline_wave'):
        for population,s in [('documented_alive',sub[sub.vital_status.eq('documented_alive')])]:
            n=len(s);obs=s[s.observed.eq(1)];miss=n-len(obs);events=int(obs.target.sum());rate=obs.target.mean()
            for odds_ratio in [0,0.5,1,2,np.inf]:
                q=1.0 if np.isinf(odds_ratio) else (rate*odds_ratio/(1-rate+rate*odds_ratio))
                bounds.append({'baseline_wave':wave,'population':population,'n':n,'observed_n':len(obs),'observed_events':events,'unobserved_n':miss,'assumed_missing_vs_observed_odds_ratio':odds_ratio,'hypothetical_event_proportion':(events+miss*q)/n,'note':'Hypothetical scenarios among documented survivors only; no depressive outcomes are assigned to deaths or unknown vital status.'})
    save(pd.DataFrame(bounds),'missing_outcome_scenarios.csv')
    print('AUDIT COMPLETE',flush=True)

if __name__=='__main__': run()
