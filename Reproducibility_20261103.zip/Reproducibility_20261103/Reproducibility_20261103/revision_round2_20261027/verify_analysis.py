"""Verify cohort separation, model predictions and analytical consistency"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from run_models import hashed_development,OLD
from evaluate_results import stats,calibration
from src.train_logistic_models import calibration_parameters
from src.model_config import BASIC_MODEL_FEATURES,FULL_MODEL_FEATURES
from src.tpot_fold_safe import encode_tpot_features
import joblib

def main():
    checks=[]
    assert all(hashed_development(str(x))==hashed_development(str(x)) for x in range(100));checks.append('ID allocation deterministic')
    for folder in (ROOT/'analyses').glob('*'):
        if not (folder/'COMPLETE.json').exists():continue
        d=pd.read_csv(ROOT/f'private_data/{folder.name}_development.csv',dtype={'participant_id':str})
        t=pd.read_csv(ROOT/f'private_data/{folder.name}_test.csv',dtype={'participant_id':str})
        assert not set(d.participant_id)&set(t.participant_id)
        p=pd.read_csv(folder/'private_test_predictions.csv',dtype={'participant_id':str})
        assert p.groupby('model').participant_id.nunique().eq(len(t)).all()
        assert p.probability.between(0,1).all()
        for model,g in p.groupby('model',sort=False):
            estimator=joblib.load(folder/'models'/f'{model}.joblib')
            x=encode_tpot_features(t).to_numpy() if model=='tpot' else t[BASIC_MODEL_FEATURES if model=='basic_logistic' else FULL_MODEL_FEATURES]
            assert g.participant_id.tolist()==t.participant_id.tolist()
            assert np.allclose(estimator.predict_proba(x)[:,1],g.probability,rtol=0,atol=1e-12)
        if folder.name=='outcome_independent_id_allocation':
            assert not d.participant_id.duplicated().any()
            assert d.participant_id.map(hashed_development).all()
            assert not t.participant_id.map(hashed_development).any()
        checks.append(folder.name+': zero ID overlap; complete finite predictions')
    p=pd.read_csv(OLD/'reports/generated/logistic_temporal_test_predictions.csv')
    for model,g in p.groupby('model'):
        a=calibration(g.target.to_numpy(),g.probability.to_numpy(),np.ones(len(g)))
        b=calibration_parameters(g.target.to_numpy(),g.probability.to_numpy())
        assert np.max(np.abs(a-b))<1e-7
    checks.append('Bootstrap calibration implementation agrees with original statsmodels GLM')
    raw=pd.read_csv(ROOT/'results/raw_rebuild_verification.csv');assert raw.disagreements.sum()==0
    checks.append('All three raw baseline-wave reconstructions match saved predictor values')
    flow=pd.read_csv(ROOT/'results/followup_disposition_by_wave.csv')
    assert flow.loc[flow.disposition.eq('not_linked'),'n'].sum()==504
    assert flow.loc[flow.disposition.eq('insufficient_items'),'n'].sum()==202
    checks.append('Follow-up exclusions reconcile to 504 unlinked and 202 insufficient CESD records')
    result={'passed':True,'checks':checks}
    (ROOT/'results/verification.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
