from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
f=pd.read_csv(ROOT/'results/model_metrics_with_intervals.csv')
colors=['#0072B2','#D55E00','#009E73'];models=['basic_logistic','full_penalized_logistic','tpot'];names=['Basic logistic','Full penalized logistic','TPOT']
scenarios=['submitted_primary','two_year_2013','outcome_independent_id_allocation']
labels=['Submitted design\n(n = 1464)','Two-year development\n(n = 1464)','ID allocation\n(n = 417)']
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans'})
fig,axes=plt.subplots(1,2,figsize=(11,4.5),constrained_layout=True)
for ax,key,title in zip(axes,['roc_auc','brier_score'],['A. Temporal discrimination','B. Probability error']):
 for j,model in enumerate(models):
  sub=f.set_index(['scenario','model']).loc[[(s,model) for s in scenarios]].reset_index()
  y=np.arange(3)+(j-1)*.18
  ax.errorbar(sub[key],y,xerr=np.vstack([sub[key]-sub[key+'_low'],sub[key+'_high']-sub[key]]),fmt='o',capsize=3,color=colors[j],label=names[j],markersize=5)
 ax.set_yticks(range(3),labels);ax.invert_yaxis();ax.set_title(title,loc='left');ax.set_xlabel('ROC-AUC (95% CI)' if key=='roc_auc' else 'Brier score (95% CI)');ax.grid(axis='x',alpha=.15)
axes[0].legend(loc='lower left',fontsize=8,frameon=False)
(ROOT/'figures').mkdir(exist_ok=True)
fig.savefig(ROOT/'figures/Figure_S3_design_comparisons.png',dpi=300);fig.savefig(ROOT/'figures/Figure_S3_design_comparisons.pdf');plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5),constrained_layout=True)
pairs=[('submitted_primary','unweighted_original'),('two_year_2013','two_year_2013_unweighted'),('outcome_independent_id_allocation','outcome_independent_id_allocation_unweighted')]
for j,model in enumerate(models):
 weighted=[f.loc[f.scenario.eq(a)&f.model.eq(model),'brier_score'].iloc[0] for a,b in pairs]
 unweighted=[f.loc[f.scenario.eq(b)&f.model.eq(model),'brier_score'].iloc[0] for a,b in pairs]
 x=np.arange(3)+(j-1)*.22
 ax.plot(x,weighted,'o',color=colors[j],label=names[j]+', weighted');ax.plot(x,unweighted,'s',color=colors[j],mfc='white',label=names[j]+', unweighted')
 for xx,w,u in zip(x,weighted,unweighted):ax.plot([xx,xx],[w,u],color=colors[j],alpha=.5)
ax.set_xticks(range(3),['Submitted design','Two-year development','ID allocation']);ax.set_ylabel('Brier score (lower is better)');ax.grid(axis='y',alpha=.15);ax.legend(fontsize=8,frameon=False,ncol=2)
fig.savefig(ROOT/'figures/Figure_S4_weighting_probability_error.png',dpi=300);fig.savefig(ROOT/'figures/Figure_S4_weighting_probability_error.pdf');plt.close(fig)
print('FIGURES COMPLETE')
