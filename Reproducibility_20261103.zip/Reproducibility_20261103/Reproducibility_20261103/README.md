# CHARLS heart disease and depressive symptoms reproducibility archive

Analysis version: 20261103. This archive accompanies the revised manuscript on
development and temporal evaluation of models for next-wave clinically relevant
depressive symptoms in adults with physician-diagnosed heart disease.

## Contents

- reanalysis/: primary cohort derivation, modeling, saved pipelines and outputs.
- revision_round2_20261027/: weighting and cohort-design comparisons, source-field
  audits, follow-up analyses, saved models, and aggregate results.
- 20261103/: supplementary probability intervals, locked-model replay scripts,
  and aggregate supporting data.
- environment-lock.txt: pinned package versions used with Python 3.10.
- result_to_script_manifest.csv: reported results, scripts and expected outputs.
- SHA256_MANIFEST.json: hashes of the files in this archive, excluding itself.

## Environment

Extract the archive, open a terminal in its root, and create a Python 3.10 virtual
environment. Activate it using the command appropriate to your operating system,
then install the pinned dependencies:

    python -m pip install -r environment-lock.txt

## Execution check without participant data

From the archive root:

    python revision_round2_20261027/reproduce_round2.py smoke

This constructs artificial four-wave input modules and exercises linkage,
CESD-10 scoring, harmonization, model fitting and prediction, including a small
bounded TPOT search. It writes
revision_round2_20261027/results/synthetic_smoke_result.json. Artificial-data
performance only checks execution and is not an estimate of empirical accuracy.

## Full empirical reconstruction

Authorized CHARLS downloads are required. The configured folders, relative to
the extracted archive root, are CHARLS2013_Dataset, CHARLS2015r, CHARLS2018r and
CHARLS2020r. Place the authorized wave modules in those folders, or edit
reanalysis/src/paths.py to point to their local locations. Preserve original
module filenames; the source-field mappings document the required fields.

Run the stages below from the archive root in this order:

    python revision_round2_20261027/reproduce_round2.py data
    python revision_round2_20261027/reproduce_round2.py submitted
    python revision_round2_20261027/reproduce_round2.py round2
    python 20261103/analysis/replay_locked_predictions.py
    python 20261103/analysis/complete_probability_intervals.py
    python revision_round2_20261027/reproduce_round2.py verify

The 'submitted' stage repeats primary model development. The 'round2' stage
repeats the additional analyses, including five TPOT searches in each alternative
development design. These stages are computationally intensive. The saved model
objects and aggregate expected results are provided to support inspection.
After the data stage, replay_locked_predictions.py can instead reproduce primary
and full-logistic sensitivity predictions from the saved pipelines without a
new search. This shortcut does not refit all additional models or replace the
complete reconstruction stages above.

The data and modeling stages write local intermediate datasets and individual
predictions. Those outputs contain participant information and are excluded from
this distributed archive. Do not redistribute them. The aggregate audit files
and result-to-script manifest identify the expected manuscript-level outputs.
TPOT time limits and numerical environment differences can affect a new search;
five recorded seeds characterize search variation rather than independent
development samples. Use saved models when comparing the locked-model results.

## Integrity

SHA256_MANIFEST.json records hashes of the exact distributed files. The archive
contains no participant-level CHARLS records, individual predictions or ID
ledgers. Public repository:
https://github.com/duanfaxi/charls-heart-disease-depression-reanalysis
