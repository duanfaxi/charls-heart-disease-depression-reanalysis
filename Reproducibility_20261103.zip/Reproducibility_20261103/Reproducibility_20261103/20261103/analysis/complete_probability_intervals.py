"""Add probability-metric intervals to S6/S7 using existing locked predictions.

No fitting, tuning, or test-dependent selection is performed. Outputs are aggregate.
Run from the extracted archive with reanalysis and revision_round2_20261027 siblings.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
sys.path.insert(0,str(BASE/'revision_round2_20261027'))
from evaluate_results import calibration

def metrics(y,p):
    return np.array([np.mean((p-y)**2),*calibration(y,p,np.ones(len(y)))])

def evaluate(frame,scope):
    wide=frame.pivot(index='participant_id',columns='model',values='probability').sort_index()
    assert not wide.isna().any().any()
    meta=frame.drop_duplicates('participant_id').set_index('participant_id').loc[wide.index]
    y=meta.target.to_numpy(int);probs=wide.to_numpy(float);models=list(wide.columns)
    assert len(set(wide.index))==len(y) and np.all((probs>=0)&(probs<=1))
    points=np.array([metrics(y,probs[:,j]) for j in range(len(models))])
    rng=np.random.default_rng(20261103);boots=np.full((2000,len(models),3),np.nan)
    for i in range(2000):
        ix=rng.integers(0,len(y),len(y))
        if len(np.unique(y[ix]))!=2:continue
        for j in range(len(models)):boots[i,j]=metrics(y[ix],probs[ix,j])
    rows=[]
    for j,model in enumerate(models):
        r={'scope':scope,'model':model,'n':len(y),'events':int(y.sum()),'bootstrap_seed':20261103,'bootstrap_iterations':2000}
        for k,key in enumerate(['brier_score','calibration_intercept','calibration_slope']):
            valid=np.isfinite(boots[:,j,k]);r[key]=points[j,k]
            r[key+'_low'],r[key+'_high']=np.quantile(boots[valid,j,k],[.025,.975])
            r[key+'_valid_bootstrap']=int(valid.sum())
        rows.append(r)
    return pd.DataFrame(rows)

def main():
    src=BASE/'reanalysis/reports/generated';out=ROOT/'results';out.mkdir(parents=True,exist_ok=True)
    read=lambda p:pd.read_csv(p,dtype={'participant_id':str})
    sens=read(src/'sensitivity_temporal_test_predictions.csv')
    results=[evaluate(sens,'S6_full_logistic_sensitivity')]
    primary=pd.concat([read(src/'logistic_temporal_test_predictions.csv'),read(src/'tpot_temporal_test_predictions.csv').assign(model='tpot')])
    for sex in ['female','male']:
        results.append(evaluate(primary.loc[primary.sex.eq(sex)].copy(),'S7_'+sex))
    allmetrics=pd.concat(results,ignore_index=True)
    # Verify new calculations reproduce the original point estimates.
    old_sens=pd.read_csv(src/'sensitivity_temporal_test_metrics.csv').drop_duplicates('model').set_index('model')
    old_sex=pd.read_csv(src/'sex_stratified_temporal_performance.csv')
    old_sex['model']=old_sex.model.replace({'tpot_final':'tpot'})
    old_sex=old_sex.set_index(['sex','model'])
    for _,row in allmetrics.iterrows():
        old=old_sens.loc[row.model] if row.scope.startswith('S6') else old_sex.loc[(row.scope[3:],row.model)]
        for key in ['brier_score','calibration_intercept','calibration_slope']:
            assert abs(row[key]-old[key])<1e-7,(row.scope,row.model,key)
    allmetrics.to_csv(out/'S6_S7_probability_metrics_95CI.csv',index=False,encoding='utf-8-sig')
    summary={'method':'2000 participant-bootstrap percentile intervals; same draws across models in each sample; calibration intercept/slope jointly re-estimated in each draw; conditional on locked fitted models','seed':20261103,'model_subgroup_rows':len(allmetrics),'point_estimates_match_original':True,'minimum_valid_bootstrap':int(allmetrics.filter(like='_valid_bootstrap').min().min()),'model_training_performed':False,'discrimination_intervals':'Existing AUC/AP intervals retained unchanged; new intervals supplement Brier and calibration only.'}
    (out/'interval_verification.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
