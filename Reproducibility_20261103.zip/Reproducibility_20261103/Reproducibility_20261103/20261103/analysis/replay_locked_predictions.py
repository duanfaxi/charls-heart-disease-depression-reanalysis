"""Replay included primary and sensitivity models after authorized cohort reconstruction."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;OLD=BASE/'reanalysis'
sys.path.insert(0,str(OLD))
import joblib
import pandas as pd
from src.model_config import BASIC_MODEL_FEATURES,FULL_MODEL_FEATURES
from src.tpot_fold_safe import encode_tpot_features
from src.run_sensitivity_analyses import FEATURE_REMOVALS

if __name__=='__main__':
    data=pd.read_csv(OLD/'data_processed/temporal_test.csv',dtype={'participant_id':str})
    assert data.participant_id.is_unique
    out=OLD/'reports/generated';out.mkdir(parents=True,exist_ok=True)
    meta=['participant_id','baseline_wave','outcome_wave','sex','target']
    rows=[]
    for model,filename,features in [('basic_logistic','basic_logistic',BASIC_MODEL_FEATURES),('full_penalized_logistic','full_penalized_logistic',FULL_MODEL_FEATURES)]:
        est=joblib.load(OLD/'models'/(filename+'.joblib'))
        r=data[meta].copy();r['model']=model;r['probability']=est.predict_proba(data[features])[:,1];rows.append(r)
    pd.concat(rows).to_csv(out/'logistic_temporal_test_predictions.csv',index=False)
    est=joblib.load(OLD/'models/tpot_final_pipeline.joblib')
    r=data[meta].copy();r['model']='tpot';r['probability']=est.predict_proba(encode_tpot_features(data).to_numpy())[:,1]
    r.to_csv(out/'tpot_temporal_test_predictions.csv',index=False)
    rows=[]
    for p in sorted((OLD/'models/sensitivity').glob('*.joblib')):
        removals=FEATURE_REMOVALS.get(p.stem,[]);features=[f for f in FULL_MODEL_FEATURES if f not in removals]
        est=joblib.load(p);r=data[meta].copy();r['model']=p.stem;r['probability']=est.predict_proba(data[features])[:,1];rows.append(r)
    assert len(rows)==5
    pd.concat(rows).to_csv(out/'sensitivity_temporal_test_predictions.csv',index=False)
    print('Replayed locked models; participant-level outputs remain local and must not be redistributed.')
