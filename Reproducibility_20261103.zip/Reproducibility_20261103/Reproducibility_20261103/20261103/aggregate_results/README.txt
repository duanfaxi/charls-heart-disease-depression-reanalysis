Supplementary Data 20261103

This attachment contains aggregate CSV outputs supporting the manuscript and Supplementary Tables S1-S17. It contains no participant-level CHARLS data or predictions.

S6_full_logistic_sensitivity_metrics.csv and S7_sex_subgroup_metrics.csv retain the original ROC-AUC/AP intervals and add Brier/calibration intervals. New intervals use seed 20261103, 2,000 participant-bootstrap samples, and joint calibration fitting in each draw. S6_S7_probability_metrics_95CI.csv records valid replicate counts. Models were not refitted.

model_metrics_with_intervals.csv and paired_model_differences.csv contain the primary and alternative-design results. Rows prefixed submitted_ are primary-model predictions evaluated on the matching alternative test sample; they are not newly searched models. Code-label names retain the original analysis identifiers.

complete_field_mapping.csv, raw_field_value_counts.csv and variable_level_harmonization_audit.csv document source fields, raw codes and transformations. The 2015 missing-retained analysis retains class weights, propagates any unresolved component to the comorbidity count, and rebuilds related medication indicators; see Supplementary Material.

followup_disposition_by_wave.csv distinguishes death, known survival and unknown status. Missing-outcome scenarios apply only to documented survivors. FILE_INVENTORY.csv gives file sizes by rows/columns and content hashes.
