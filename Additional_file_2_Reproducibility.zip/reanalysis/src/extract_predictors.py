"""Extract and harmonize common baseline predictors from CHARLS health modules."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from pandas.io.stata import StataReader

from src.derive_disease import derive_heart_disease
from src.paths import INTERIM_DATA_DIR, RAW_WAVE_DIRS, ensure_output_directories
from src.wave_config import (
    COMMON_HEALTH_FIELDS,
    DISEASE_NAMES,
    HEALTH_FILE,
    PREDICTOR_CONFIG,
)


def valid_numeric(series: pd.Series, allowed: set[int] | None = None) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    if allowed is not None:
        numeric = numeric.where(numeric.isin(allowed))
    return numeric


def yes_no_or(
    prior: pd.Series, current: pd.Series, structural_missing_as_no: bool = False
) -> pd.Series:
    """Return 1 for either yes, 0 for any observed no, otherwise missing."""

    result = derive_heart_disease(prior, current)["heart_disease"]
    if structural_missing_as_no:
        result = result.fillna(0)
    return result


def any_yes(fields: pd.DataFrame) -> pd.Series:
    """Combine a set of 1=yes, 2=no fields while retaining complete unknowns."""

    numeric = fields.apply(lambda column: valid_numeric(column, {1, 2}))
    result = pd.Series(pd.NA, index=fields.index, dtype="Int64")
    result.loc[numeric.eq(2).any(axis=1)] = 0
    result.loc[numeric.eq(1).any(axis=1)] = 1
    return result


def derive_smoking_status(frame: pd.DataFrame, wave: int) -> pd.Series:
    """Harmonize smoking as current, former, never, or missing."""

    status = pd.Series(pd.NA, index=frame.index, dtype="string")
    if wave == 2013:
        prior_ever = valid_numeric(frame["zda059"], {1, 2})
        current_ever = valid_numeric(frame["da059"], {1, 2})
        current_status = valid_numeric(frame["da061"], {1, 2})
        status.loc[current_status.eq(1)] = "current"
        status.loc[current_status.eq(2)] = "former"
        never = prior_ever.eq(2) | current_ever.eq(2)
        status.loc[status.isna() & never] = "never"
    elif wave == 2015:
        current_status = valid_numeric(frame["da061"], {1, 2, 3}).combine_first(
            valid_numeric(frame["da061_w3"], {1, 2, 3})
        )
        status.loc[current_status.eq(1)] = "current"
        status.loc[current_status.eq(2)] = "former"
        status.loc[current_status.eq(3)] = "never"
        never = valid_numeric(frame["zda059"], {1, 2}).eq(2) | valid_numeric(
            frame["da059"], {1, 2}
        ).eq(2)
        status.loc[status.isna() & never] = "never"
    else:
        current_status = valid_numeric(frame["da061_w4"], {1, 2, 3})
        fallback = valid_numeric(frame["da061"], {1, 2})
        current_status = current_status.combine_first(fallback)
        status.loc[current_status.eq(1)] = "current"
        status.loc[current_status.eq(2)] = "former"
        status.loc[current_status.eq(3)] = "never"
        never = valid_numeric(frame["da059"], {1, 2}).eq(2)
        status.loc[status.isna() & never] = "never"
    return status


def derive_medication(
    fields: pd.DataFrame, disease: pd.Series, none_codes: set[int]
) -> pd.Series:
    """Derive medication use from multi-select treatment fields and disease status."""

    numeric = fields.apply(pd.to_numeric, errors="coerce")
    result = pd.Series(pd.NA, index=fields.index, dtype="Int64")
    result.loc[disease.eq(0)] = 0
    result.loc[numeric.isin([1, 2]).any(axis=1)] = 1
    explicit_none = numeric.isin(none_codes).any(axis=1)
    result.loc[result.isna() & disease.eq(1) & explicit_none] = 0
    return result


def derive_function_score(fields: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """Return complete-item 0-3 sum and any-limitation indicator."""

    valid = fields.apply(lambda column: valid_numeric(column, {1, 2, 3, 4}))
    score = (valid - 1).sum(axis=1, min_count=valid.shape[1])
    limited = pd.Series(pd.NA, index=fields.index, dtype="Int64")
    complete = valid.notna().all(axis=1)
    limited.loc[complete] = valid.loc[complete].ge(2).any(axis=1).astype(int)
    return score, limited


def derive_self_rated_health(frame: pd.DataFrame) -> pd.Series:
    """Align the randomized five-point health forms to the 2018 scale."""

    form_b = valid_numeric(frame["da002"], {1, 2, 3, 4, 5})
    form_a_source = frame.get("da001", pd.Series(np.nan, index=frame.index))
    form_a = valid_numeric(form_a_source, {1, 2, 3, 4, 5})
    aligned_a = form_a.map({1: 1, 2: 1, 3: 2, 4: 3, 5: 4})
    return form_b.combine_first(aligned_a)


def derive_social_activity(
    items: pd.DataFrame, frequency: pd.DataFrame
) -> tuple[pd.Series, pd.Series]:
    item_numeric = items.apply(pd.to_numeric, errors="coerce")
    selected = item_numeric.isin(range(1, 12))
    count = selected.sum(axis=1).astype("int64")
    answered = selected.any(axis=1) | item_numeric.eq(12).any(axis=1) | item_numeric.eq(0).any(axis=1)
    count = count.where(answered)

    freq_numeric = frequency.apply(lambda column: valid_numeric(column, {1, 2, 3}))
    intensity = freq_numeric.replace({1: 3, 2: 2, 3: 1}).max(axis=1)
    intensity.loc[count.eq(0)] = 0
    intensity = intensity.where(count.notna())
    return count, intensity


def _all_required_fields(wave: int) -> list[str]:
    config = PREDICTOR_CONFIG[wave]
    fields = ["ID", *COMMON_HEALTH_FIELDS.values()]
    flattened: list[str] = []
    for item in fields:
        flattened.extend(item if isinstance(item, list) else [item])
    if wave == 2018:
        flattened.remove("da001")
    else:
        flattened.append("dc028")
    for index in DISEASE_NAMES:
        flattened.append(config["disease_prior_prefix"].format(index=index))
        flattened.append(config["disease_current_prefix"].format(index=index))
    flattened.extend(config["disability_prior"])
    flattened.extend(config["disability_current"])
    if config["pain_indicator"]:
        flattened.append(config["pain_indicator"])
    flattened.extend(config["pain_sites"])
    flattened.extend(config["social_items"])
    flattened.extend(config["social_frequency"])
    flattened.extend(config["smoking"])
    for medication_fields in config["medication"].values():
        flattened.extend(medication_fields)
    return list(dict.fromkeys(flattened))


def extract_wave_predictors(wave: int) -> pd.DataFrame:
    config = PREDICTOR_CONFIG[wave]
    path = RAW_WAVE_DIRS[wave] / HEALTH_FILE
    required = _all_required_fields(wave)
    with StataReader(path, convert_categoricals=False) as reader:
        available = reader.variable_labels()
    missing = sorted(set(required).difference(available))
    if missing:
        raise KeyError(f"Wave {wave} predictor fields missing: {missing}")
    raw = pd.read_stata(
        path,
        columns=required,
        convert_categoricals=False,
        preserve_dtypes=False,
    )
    raw["ID"] = raw["ID"].astype("string").str.strip()
    if raw["ID"].isna().any() or raw["ID"].duplicated().any():
        raise ValueError(f"Wave {wave} health module has invalid or duplicate IDs")

    output = pd.DataFrame({"ID": raw["ID"], "wave": wave})
    disease_columns: list[str] = []
    for index, disease_name in DISEASE_NAMES.items():
        prior = raw[config["disease_prior_prefix"].format(index=index)]
        current = raw[config["disease_current_prefix"].format(index=index)]
        output[disease_name] = yes_no_or(
            prior, current, structural_missing_as_no=(wave == 2015)
        )
        disease_columns.append(disease_name)

    count_columns = [name for name in disease_columns if name != "heart_disease"]
    output["comorbidity_count"] = output[count_columns].sum(
        axis=1, min_count=len(count_columns)
    )
    output["comorbidity_missing_items"] = output[count_columns].isna().sum(axis=1)
    output["disability"] = any_yes(
        raw[[*config["disability_prior"], *config["disability_current"]]]
    )

    pain_sites = raw[config["pain_sites"]].apply(pd.to_numeric, errors="coerce")
    output["pain_site_count"] = pain_sites.where(pain_sites.gt(0)).notna().sum(axis=1)
    if config["pain_indicator"] is None:
        output["pain"] = output["pain_site_count"].gt(0).astype("Int64")
    elif wave == 2018:
        pain_raw = valid_numeric(raw[config["pain_indicator"]], {1, 2, 3, 4, 5})
        output["pain"] = pain_raw.ge(2).where(pain_raw.notna()).astype("Int64")
    else:
        pain_raw = valid_numeric(raw[config["pain_indicator"]], {1, 2})
        output["pain"] = pain_raw.eq(1).where(pain_raw.notna()).astype("Int64")

    adl_score, adl_limited = derive_function_score(raw[COMMON_HEALTH_FIELDS["adl"]])
    iadl_score, iadl_limited = derive_function_score(raw[COMMON_HEALTH_FIELDS["iadl"]])
    output["adl_score"] = adl_score
    output["adl_limited"] = adl_limited
    output["iadl_score"] = iadl_score
    output["iadl_limited"] = iadl_limited

    output["sleep_hours"] = valid_numeric(raw["da049"]).where(lambda x: x.between(0, 24))
    output["nap_minutes"] = valid_numeric(raw["da050"]).where(lambda x: x.between(0, 1440))
    activity = raw[COMMON_HEALTH_FIELDS["physical_activity"]].apply(
        lambda column: valid_numeric(column, {1, 2})
    )
    activity_level = pd.Series(pd.NA, index=raw.index, dtype="string")
    complete_activity = activity.notna().all(axis=1)
    activity_level.loc[complete_activity & activity.eq(2).all(axis=1)] = "none"
    activity_level.loc[activity.iloc[:, 2].eq(1)] = "light"
    activity_level.loc[activity.iloc[:, 1].eq(1)] = "moderate"
    activity_level.loc[activity.iloc[:, 0].eq(1)] = "vigorous"
    output["physical_activity_level"] = activity_level

    output["smoking_status"] = derive_smoking_status(raw, wave)
    alcohol = valid_numeric(raw["da067"], {1, 2, 3})
    output["alcohol_frequency"] = alcohol.map(
        {1: "more_than_monthly", 2: "monthly_or_less", 3: "none"}
    ).astype("string")
    output["self_rated_health"] = derive_self_rated_health(raw)
    if wave in (2013, 2015):
        output["life_satisfaction"] = valid_numeric(raw["dc028"], {1, 2, 3, 4, 5})
    else:
        cognition_path = RAW_WAVE_DIRS[wave] / "Cognition.dta"
        cognition = pd.read_stata(
            cognition_path,
            columns=["ID", "dc028"],
            convert_categoricals=False,
            preserve_dtypes=False,
        )
        cognition["ID"] = cognition["ID"].astype("string").str.strip()
        if cognition["ID"].duplicated().any():
            raise ValueError("Wave 2018 cognition file has duplicate IDs")
        life = valid_numeric(cognition["dc028"], {1, 2, 3, 4, 5})
        life_by_id = pd.Series(life.values, index=cognition["ID"])
        output["life_satisfaction"] = output["ID"].map(life_by_id)

    social_count, social_frequency = derive_social_activity(
        raw[config["social_items"]], raw[config["social_frequency"]]
    )
    output["social_activity_count"] = social_count
    output["social_activity_frequency"] = social_frequency

    for medication_name, fields in config["medication"].items():
        disease_name = {
            "hypertension_medication": "hypertension",
            "dyslipidemia_medication": "dyslipidemia",
            "heart_medication": "heart_disease",
        }[medication_name]
        none_codes = {4, 99} if wave == 2018 or disease_name != "hypertension" else {3}
        if wave < 2018 and disease_name == "hypertension":
            none_codes = {3}
        output[medication_name] = derive_medication(
            raw[fields], output[disease_name], none_codes
        )

    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interim-dir", type=Path, default=INTERIM_DATA_DIR)
    args = parser.parse_args()
    ensure_output_directories()
    args.interim_dir.mkdir(parents=True, exist_ok=True)
    for wave in (2013, 2015, 2018):
        predictors = extract_wave_predictors(wave)
        predictors.to_csv(
            args.interim_dir / f"predictors_wave_{wave}.csv",
            index=False,
            encoding="utf-8-sig",
        )
        print(f"Wave {wave}: extracted {len(predictors)} rows and {len(predictors.columns)-2} predictors.")


if __name__ == "__main__":
    main()
