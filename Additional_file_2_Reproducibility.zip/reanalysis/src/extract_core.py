"""Extract participant ID, CESD-10, and heart-disease status by wave."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd
from pandas.io.stata import StataMissingValue, StataReader

from src.derive_disease import derive_heart_disease
from src.paths import (
    GENERATED_REPORT_DIR,
    INTERIM_DATA_DIR,
    RAW_WAVE_DIRS,
    ensure_output_directories,
    validate_raw_directories,
)
from src.score_cesd import score_cesd10
from src.wave_config import CESD_CONFIG, HEART_CONFIG


def _read_columns(path: Path, columns: list[str]) -> pd.DataFrame:
    with StataReader(path, convert_categoricals=False) as reader:
        available = set(reader.variable_labels())
    missing = sorted(set(columns).difference(available))
    if missing:
        raise KeyError(f"{path} is missing required columns: {missing}")
    frame = pd.read_stata(
        path,
        columns=columns,
        convert_categoricals=False,
        convert_missing=True,
        preserve_dtypes=False,
    )
    frame["ID"] = frame["ID"].astype("string").str.strip()
    if frame["ID"].isna().any() or frame["ID"].eq("").any():
        raise ValueError(f"{path} contains missing participant IDs")
    if frame["ID"].duplicated().any():
        raise ValueError(f"{path} contains duplicate participant IDs")
    return frame


def _field_metadata(path: Path, fields: list[str]) -> dict[str, dict[str, Any]]:
    with StataReader(path, convert_categoricals=False) as reader:
        variable_labels = reader.variable_labels()
        value_labels = reader.value_labels()
        variables = list(reader._varlist)
        label_sets = list(reader._lbllist)
    output: dict[str, dict[str, Any]] = {}
    for field in fields:
        position = variables.index(field)
        label_set = label_sets[position]
        output[field] = {
            "variable_label": variable_labels[field],
            "value_labels": value_labels.get(label_set, {}),
        }
    return output


def _display_raw_value(value: Any) -> str:
    if isinstance(value, StataMissingValue):
        return str(value)
    if pd.isna(value):
        return "system_missing"
    return str(value)


def extract_wave_core(
    wave: int,
) -> tuple[pd.DataFrame, list[dict[str, Any]], list[dict[str, Any]]]:
    """Extract one wave and return participant data plus CESD and heart audits."""

    cesd_config = CESD_CONFIG[wave]
    heart_config = HEART_CONFIG[wave]
    cesd_path = RAW_WAVE_DIRS[wave] / cesd_config["file"]
    heart_path = RAW_WAVE_DIRS[wave] / heart_config["file"]

    cesd_fields = list(cesd_config["items"])
    cesd_raw = _read_columns(cesd_path, ["ID", *cesd_fields])
    scored = score_cesd10(
        cesd_raw,
        items=cesd_fields,
        reverse_items=cesd_config["reverse"],
    )
    core = pd.concat([cesd_raw[["ID"]], scored], axis=1)
    core["cesd_module_present"] = True

    heart_fields = [heart_config["prior"], heart_config["current"]]
    if "status" in heart_config:
        heart_fields.append(heart_config["status"])
    heart_raw = _read_columns(heart_path, ["ID", *heart_fields])
    heart_derived = derive_heart_disease(
        heart_raw[heart_config["prior"]], heart_raw[heart_config["current"]]
    )
    heart_output = pd.concat([heart_raw[["ID"]], heart_derived], axis=1)
    heart_output["heart_module_present"] = True

    before = len(core)
    core = core.merge(heart_output, on="ID", how="outer", validate="one_to_one")
    if len(core) < max(before, len(heart_output)):
        raise AssertionError("Outer merge unexpectedly reduced participant count")
    core.insert(1, "wave", wave)

    cesd_audit: list[dict[str, Any]] = []
    cesd_metadata = _field_metadata(cesd_path, cesd_fields)
    for field in cesd_fields:
        raw_counts = cesd_raw[field].map(_display_raw_value).value_counts(dropna=False)
        for raw_value, count in raw_counts.items():
            cesd_audit.append(
                {
                    "wave": wave,
                    "file_name": cesd_path.name,
                    "field": field,
                    "field_label": cesd_metadata[field]["variable_label"],
                    "raw_value": raw_value,
                    "count": int(count),
                    "valid_response": raw_value in {"1.0", "2.0", "3.0", "4.0"},
                    "reverse_scored": field in cesd_config["reverse"],
                }
            )
    for answered, count in core["cesd_answered_items"].value_counts().sort_index().items():
        cesd_audit.append(
            {
                "wave": wave,
                "file_name": cesd_path.name,
                "field": "CESD_SUMMARY",
                "field_label": "Number of valid CESD-10 responses",
                "raw_value": str(answered),
                "count": int(count),
                "valid_response": int(answered) >= 8,
                "reverse_scored": False,
            }
        )

    heart_audit: list[dict[str, Any]] = []
    heart_metadata = _field_metadata(heart_path, heart_fields)
    for field in heart_fields:
        raw_counts = heart_raw[field].map(_display_raw_value).value_counts(dropna=False)
        labels = {
            str(key.item() if hasattr(key, "item") else key): value
            for key, value in heart_metadata[field]["value_labels"].items()
        }
        for raw_value, count in raw_counts.items():
            heart_audit.append(
                {
                    "record_type": "raw_value",
                    "wave": wave,
                    "file_name": heart_path.name,
                    "field": field,
                    "field_label": heart_metadata[field]["variable_label"],
                    "raw_value": raw_value,
                    "raw_value_label": labels.get(raw_value, ""),
                    "count": int(count),
                    "positive_code": "1",
                    "combination_rule": "prior==1 OR current==1",
                }
            )
    summary_counts = {
        "heart_positive": int(core["heart_disease"].eq(1).sum()),
        "heart_negative": int(core["heart_disease"].eq(0).sum()),
        "heart_unknown": int(core["heart_disease"].isna().sum()),
        "prior_positive": int(core["heart_prior_yes"].fillna(0).sum()),
        "current_positive": int(core["heart_current_yes"].fillna(0).sum()),
        "field_conflict": int(core["heart_field_conflict"].eq(True).sum()),
        "both_fields_missing": int(core["heart_both_fields_missing"].eq(True).sum()),
    }
    heart_audit.append(
        {
            "record_type": "combined_summary",
            "wave": wave,
            "file_name": heart_path.name,
            "field": f"{heart_config['prior']}|{heart_config['current']}",
            "field_label": "Unified physician-diagnosed heart disease",
            "raw_value": "summary",
            "raw_value_label": json.dumps(summary_counts, ensure_ascii=False),
            "count": summary_counts["heart_positive"],
            "positive_code": "1",
            "combination_rule": "prior==1 OR current==1",
        }
    )
    return core, cesd_audit, heart_audit


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--interim-dir", type=Path, default=INTERIM_DATA_DIR
    )
    parser.add_argument(
        "--report-dir", type=Path, default=GENERATED_REPORT_DIR
    )
    args = parser.parse_args()

    validate_raw_directories()
    ensure_output_directories()
    args.interim_dir.mkdir(parents=True, exist_ok=True)
    args.report_dir.mkdir(parents=True, exist_ok=True)

    cesd_audits: list[dict[str, Any]] = []
    heart_audits: list[dict[str, Any]] = []
    for wave in CESD_CONFIG:
        core, cesd_audit, heart_audit = extract_wave_core(wave)
        core.to_csv(
            args.interim_dir / f"core_wave_{wave}.csv",
            index=False,
            encoding="utf-8-sig",
        )
        cesd_audits.extend(cesd_audit)
        heart_audits.extend(heart_audit)

    pd.DataFrame(cesd_audits).to_csv(
        args.report_dir / "cesd_scoring_audit.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(heart_audits).to_csv(
        args.report_dir / "heart_disease_field_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("Extracted core CESD-10 and heart-disease fields for four waves.")


if __name__ == "__main__":
    main()
