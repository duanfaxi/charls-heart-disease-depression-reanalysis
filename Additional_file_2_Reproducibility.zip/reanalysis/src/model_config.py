"""Locked feature sets for the pre-specified prediction models."""

from __future__ import annotations


BASIC_MODEL_FEATURES = [
    "baseline_age",
    "sex",
    "education",
    "partner_cohabiting",
    "baseline_cesd10",
    "disability",
    "comorbidity_count",
    "stroke",
    "hypertension_medication",
    "heart_medication",
]

FULL_MODEL_FEATURES = [
    "baseline_age",
    "sex",
    "education",
    "partner_cohabiting",
    "baseline_cesd10",
    "disability",
    "comorbidity_count",
    "hypertension",
    "dyslipidemia",
    "diabetes",
    "cancer",
    "chronic_lung_disease",
    "liver_disease",
    "stroke",
    "kidney_disease",
    "digestive_disease",
    "emotional_or_psychiatric_disease",
    "memory_related_disease",
    "arthritis",
    "asthma",
    "hypertension_medication",
    "dyslipidemia_medication",
    "heart_medication",
    "pain",
    "pain_site_count",
    "adl_score",
    "iadl_score",
    "sleep_hours",
    "nap_minutes",
    "smoking_status",
    "alcohol_frequency",
    "self_rated_health",
    "life_satisfaction",
    "social_activity_count",
    "social_activity_frequency",
]

# The variable is retained in audit outputs but excluded because early-wave
# structural missingness exceeds 50% and would encode survey wave.
AUDIT_ONLY_FEATURES = ["physical_activity_level"]

CATEGORICAL_FEATURES = [
    "sex",
    "education",
    "smoking_status",
    "alcohol_frequency",
]

CONTINUOUS_FEATURES = [
    feature for feature in FULL_MODEL_FEATURES if feature not in CATEGORICAL_FEATURES
]

