"""Locked source-field mappings for core longitudinal variables."""

from __future__ import annotations


HEALTH_FILE = "Health_Status_and_Functioning.dta"

CESD_CONFIG = {
    2013: {
        "file": HEALTH_FILE,
        "items": [f"dc{number:03d}" for number in range(9, 19)],
        "reverse": ["dc013", "dc016"],
    },
    2015: {
        "file": HEALTH_FILE,
        "items": [f"dc{number:03d}" for number in range(9, 19)],
        "reverse": ["dc013", "dc016"],
    },
    2018: {
        "file": "Cognition.dta",
        "items": [f"dc{number:03d}" for number in range(9, 19)],
        "reverse": ["dc013", "dc016"],
    },
    2020: {
        "file": HEALTH_FILE,
        "items": [f"dc{number:03d}" for number in range(16, 26)],
        "reverse": ["dc020", "dc023"],
    },
}

HEART_CONFIG = {
    2013: {
        "file": HEALTH_FILE,
        "prior": "zda007_7_",
        "current": "da007_7_",
    },
    2015: {
        "file": HEALTH_FILE,
        "prior": "zda007_7_",
        "current": "da007_7_",
    },
    2018: {
        "file": HEALTH_FILE,
        "prior": "zdiagnosed_7_",
        "current": "da007_7_",
    },
    2020: {
        "file": HEALTH_FILE,
        "prior": "zdisease_7_",
        "current": "da003_7_",
        "status": "da002_7_",
    },
}

DISEASE_NAMES = {
    1: "hypertension",
    2: "dyslipidemia",
    3: "diabetes",
    4: "cancer",
    5: "chronic_lung_disease",
    6: "liver_disease",
    7: "heart_disease",
    8: "stroke",
    9: "kidney_disease",
    10: "digestive_disease",
    11: "emotional_or_psychiatric_disease",
    12: "memory_related_disease",
    13: "arthritis",
    14: "asthma",
}

PREDICTOR_CONFIG = {
    2013: {
        "disease_prior_prefix": "zda007_{index}_",
        "disease_current_prefix": "da007_{index}_",
        "disability_prior": [f"zda005_{index}_" for index in range(1, 7)],
        "disability_current": [f"da005_{index}_" for index in range(1, 6)],
        "pain_indicator": None,
        "pain_sites": [f"da042s{index}" for index in range(1, 16)],
        "social_items": [f"da056s{index}" for index in range(1, 13)],
        "social_frequency": [f"da057_{index}_" for index in range(1, 12)],
        "smoking": ["zda059", "da059", "da061"],
        "medication": {
            "hypertension_medication": [f"da011s{index}" for index in range(1, 4)],
            "dyslipidemia_medication": [f"da010_2_s{index}" for index in range(1, 5)],
            "heart_medication": [f"da010_7_s{index}" for index in range(1, 5)],
        },
    },
    2015: {
        "disease_prior_prefix": "zda007_{index}_",
        "disease_current_prefix": "da007_{index}_",
        "disability_prior": [f"zda005_{index}_" for index in range(1, 6)],
        "disability_current": [f"da005_{index}_" for index in range(1, 6)],
        "pain_indicator": "da041",
        "pain_sites": [f"da042s{index}" for index in range(1, 17)],
        "social_items": [f"da056s{index}" for index in range(1, 13)],
        "social_frequency": [f"da057_{index}_" for index in range(1, 12)],
        "smoking": ["zda059", "da059", "da061_w3", "da061"],
        "medication": {
            "hypertension_medication": [f"da011s{index}" for index in range(1, 4)],
            "dyslipidemia_medication": [f"da010_2_s{index}" for index in range(1, 5)],
            "heart_medication": [f"da010_7_s{index}" for index in range(1, 5)],
        },
    },
    2018: {
        "disease_prior_prefix": "zdiagnosed_{index}_",
        "disease_current_prefix": "da007_{index}_",
        "disability_prior": [f"zdisability_{index}_" for index in range(1, 6)],
        "disability_current": [f"da005_{index}_" for index in range(1, 6)],
        "pain_indicator": "da041_w4",
        "pain_sites": [f"da042_s{index}" for index in range(1, 17)],
        "social_items": [f"da056_s{index}" for index in range(1, 13)],
        "social_frequency": [f"da057_{index}_" for index in range(1, 12)],
        "smoking": ["zsmoke", "da059", "da061", "da061_w4"],
        "medication": {
            "hypertension_medication": [f"da011_w4_s{index}" for index in range(1, 5)],
            "dyslipidemia_medication": [f"da010_w4_2__s{index}" for index in range(1, 5)],
            "heart_medication": [f"da010_w4_7__s{index}" for index in range(1, 5)],
        },
    },
}

COMMON_HEALTH_FIELDS = {
    "self_health_form_a": "da001",
    "self_health_form_b": "da002",
    "sleep_hours": "da049",
    "nap_minutes": "da050",
    "alcohol_frequency": "da067",
    "physical_activity": [f"da051_{index}_" for index in range(1, 4)],
    "adl": [f"db0{index}" for index in range(10, 16)],
    "iadl": [f"db0{index}" for index in range(16, 21)],
}
