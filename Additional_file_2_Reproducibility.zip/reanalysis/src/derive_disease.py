"""Derive physician-diagnosed disease indicators from CHARLS skip patterns."""

from __future__ import annotations

import pandas as pd


def derive_heart_disease(prior: pd.Series, current: pd.Series) -> pd.DataFrame:
    """Combine prior and current physician diagnosis using an inclusive OR rule."""

    prior_numeric = pd.to_numeric(prior, errors="coerce").where(lambda x: x.isin([1, 2]))
    current_numeric = pd.to_numeric(current, errors="coerce").where(
        lambda x: x.isin([1, 2])
    )

    prior_yes = prior_numeric.eq(1)
    current_yes = current_numeric.eq(1)
    any_yes = prior_yes | current_yes
    any_no = prior_numeric.eq(2) | current_numeric.eq(2)

    heart = pd.Series(pd.NA, index=prior.index, dtype="Int64")
    heart.loc[any_no] = 0
    heart.loc[any_yes] = 1

    return pd.DataFrame(
        {
            "heart_disease": heart,
            "heart_prior_yes": prior_yes.astype("int8"),
            "heart_current_yes": current_yes.astype("int8"),
            "heart_field_conflict": (prior_yes & current_numeric.eq(2))
            | (current_yes & prior_numeric.eq(2)),
            "heart_both_fields_missing": prior_numeric.isna() & current_numeric.isna(),
        },
        index=prior.index,
    )

