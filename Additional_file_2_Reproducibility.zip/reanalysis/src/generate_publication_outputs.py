"""Generate publication tables and figures directly from frozen analysis outputs."""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import auc, precision_recall_curve, roc_auc_score, roc_curve

from src.model_config import FULL_MODEL_FEATURES
from src.paths import GENERATED_REPORT_DIR, PROCESSED_DATA_DIR, PROJECT_ROOT
from src.tpot_fold_safe import encode_tpot_features


FIGURE_DPI = 300
MODEL_LABELS = {
    "basic_logistic": "Basic logistic",
    "full_penalized_logistic": "Full penalized logistic",
    "tpot_final": "TPOT",
}
MODEL_COLORS = {
    "basic_logistic": "#2878B5",
    "full_penalized_logistic": "#D95F02",
    "tpot_final": "#2E8B57",
}

CONTINUOUS_TABLE_FEATURES = [
    "baseline_age",
    "baseline_cesd10",
    "comorbidity_count",
    "pain_site_count",
    "adl_score",
    "iadl_score",
    "sleep_hours",
    "nap_minutes",
    "self_rated_health",
    "life_satisfaction",
    "social_activity_count",
    "social_activity_frequency",
]
CATEGORICAL_TABLE_FEATURES = [
    "sex",
    "education",
    "smoking_status",
    "alcohol_frequency",
]
VARIABLE_LABELS = {
    "baseline_age": "Age, years",
    "sex": "Sex",
    "education": "Education",
    "partner_cohabiting": "Living with a partner",
    "baseline_cesd10": "Baseline CESD-10 score",
    "disability": "Disability",
    "comorbidity_count": "Comorbidity count",
    "hypertension": "Hypertension",
    "dyslipidemia": "Dyslipidemia",
    "diabetes": "Diabetes",
    "cancer": "Cancer",
    "chronic_lung_disease": "Chronic lung disease",
    "liver_disease": "Liver disease",
    "stroke": "Stroke",
    "kidney_disease": "Kidney disease",
    "digestive_disease": "Digestive disease",
    "emotional_or_psychiatric_disease": "Emotional or psychiatric disease",
    "memory_related_disease": "Memory-related disease",
    "arthritis": "Arthritis",
    "asthma": "Asthma",
    "hypertension_medication": "Hypertension medication",
    "dyslipidemia_medication": "Dyslipidemia medication",
    "heart_medication": "Heart disease medication",
    "pain": "Pain",
    "pain_site_count": "Pain site count",
    "adl_score": "ADL score",
    "iadl_score": "IADL score",
    "sleep_hours": "Night-time sleep, hours",
    "nap_minutes": "Daytime nap, minutes",
    "smoking_status": "Smoking status",
    "alcohol_frequency": "Alcohol frequency",
    "self_rated_health": "Self-rated health",
    "life_satisfaction": "Life satisfaction",
    "social_activity_count": "Social activity count",
    "social_activity_frequency": "Social activity frequency",
}


def _continuous_display(series: pd.Series) -> str:
    values = pd.to_numeric(series, errors="coerce").dropna()
    if values.empty:
        return "NA"
    return f"{values.mean():.2f} ({values.std(ddof=1):.2f})"


def _binary_display(series: pd.Series) -> str:
    values = pd.to_numeric(series, errors="coerce").dropna()
    if values.empty:
        return "NA"
    positives = int(values.eq(1).sum())
    return f"{positives} ({positives / len(values) * 100:.1f}%)"


def build_table1(data: pd.DataFrame) -> pd.DataFrame:
    """Build a descriptive person-window table by incident outcome status."""

    groups = {
        f"Overall (N={len(data):,})": data,
        f"No incident depressive symptoms (N={data['target'].eq(0).sum():,})": data.loc[
            data["target"].eq(0)
        ],
        f"Incident depressive symptoms (N={data['target'].eq(1).sum():,})": data.loc[
            data["target"].eq(1)
        ],
    }
    rows: list[dict[str, object]] = []
    for feature in FULL_MODEL_FEATURES:
        label = VARIABLE_LABELS[feature]
        if feature in CATEGORICAL_TABLE_FEATURES:
            rows.append(
                {
                    "variable": label,
                    "level": "",
                    "summary_type": "categorical",
                    **{column: "" for column in groups},
                    "missing_n": int(data[feature].isna().sum()),
                }
            )
            levels = sorted(data[feature].dropna().astype(str).unique())
            for level in levels:
                row: dict[str, object] = {
                    "variable": "",
                    "level": level,
                    "summary_type": "n (%)",
                    "missing_n": "",
                }
                for column, group in groups.items():
                    valid = group[feature].dropna().astype(str)
                    count = int(valid.eq(level).sum())
                    row[column] = (
                        f"{count} ({count / len(valid) * 100:.1f}%)" if len(valid) else "NA"
                    )
                rows.append(row)
            continue
        formatter = (
            _continuous_display if feature in CONTINUOUS_TABLE_FEATURES else _binary_display
        )
        rows.append(
            {
                "variable": label,
                "level": "",
                "summary_type": "mean (SD)"
                if feature in CONTINUOUS_TABLE_FEATURES
                else "n (%)",
                **{column: formatter(group[feature]) for column, group in groups.items()},
                "missing_n": int(data[feature].isna().sum()),
            }
        )
    return pd.DataFrame(rows)


def plot_cohort_flow(flow: pd.DataFrame, output_path: Path) -> None:
    labels = {
        "baseline_health_module_with_valid_id": "Baseline health module\nwith valid ID",
        "baseline_age_available": "Age available",
        "baseline_age_ge_45": "Age >=45 years",
        "baseline_physician_diagnosed_heart_disease": "Physician-diagnosed\nheart disease",
        "baseline_cesd_at_least_8_items": "Baseline CESD-10\n>=8 items answered",
        "baseline_cesd_below_10": "Baseline CESD-10 <10",
        "outcome_cesd_module_matched": "Matched to outcome\nCESD module",
        "outcome_cesd_at_least_8_items": "Outcome CESD-10\n>=8 items answered",
        "final_eligible_window": "Eligible person-window",
    }
    waves = [(2013, 2015), (2015, 2018), (2018, 2020)]
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 8.5), sharey=True)
    for axis, (baseline, outcome) in zip(axes, waves):
        section = flow.loc[
            flow["baseline_wave"].eq(baseline) & flow["outcome_wave"].eq(outcome)
        ].sort_values("step_order")
        axis.set_xlim(0, 1)
        axis.set_ylim(-0.5, len(section) - 0.5)
        axis.axis("off")
        axis.set_title(f"{baseline} to {outcome}", fontsize=12, fontweight="bold", pad=12)
        for position, row in enumerate(section.itertuples(index=False)):
            y = len(section) - position - 1
            face = "#DCEAF5" if row.step != "final_eligible_window" else "#DDEFE2"
            text = f"{labels[row.step]}\nN = {row.n_remaining:,}"
            if row.n_excluded and row.step != "final_eligible_window":
                text += f"\nExcluded = {row.n_excluded:,}"
            axis.text(
                0.5,
                y,
                text,
                ha="center",
                va="center",
                fontsize=8.5,
                bbox={"boxstyle": "round,pad=0.35", "fc": face, "ec": "#4A4A4A"},
            )
            if position < len(section) - 1:
                axis.annotate(
                    "",
                    xy=(0.5, y - 0.63),
                    xytext=(0.5, y - 0.37),
                    arrowprops={"arrowstyle": "->", "color": "#555555", "lw": 1},
                )
    fig.suptitle("Construction of the three longitudinal prediction windows", fontsize=14)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(output_path, dpi=FIGURE_DPI, bbox_inches="tight")
    plt.close(fig)


def load_main_predictions(report_dir: Path) -> pd.DataFrame:
    paths = [report_dir / "logistic_temporal_test_predictions.csv"]
    tpot = report_dir / "tpot_temporal_test_predictions.csv"
    if tpot.exists():
        paths.append(tpot)
    return pd.concat([pd.read_csv(path) for path in paths], ignore_index=True)


def plot_model_curves(predictions: pd.DataFrame, figure_dir: Path) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    fig, axis = plt.subplots(figsize=(6.4, 5.4))
    for model, data in predictions.groupby("model"):
        fpr, tpr, _ = roc_curve(data["target"], data["probability"])
        score = roc_auc_score(data["target"], data["probability"])
        axis.plot(fpr, tpr, lw=2, color=MODEL_COLORS[model], label=f"{MODEL_LABELS[model]} ({score:.3f})")
    axis.plot([0, 1], [0, 1], ls="--", color="#777777", lw=1)
    axis.set(xlabel="1 - Specificity", ylabel="Sensitivity", xlim=(0, 1), ylim=(0, 1))
    axis.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(figure_dir / "figure_roc_temporal_test.png", dpi=FIGURE_DPI)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(6.4, 5.4))
    event_rate = predictions.drop_duplicates("participant_id")["target"].mean()
    for model, data in predictions.groupby("model"):
        precision, recall, _ = precision_recall_curve(data["target"], data["probability"])
        score = auc(recall, precision)
        axis.plot(recall, precision, lw=2, color=MODEL_COLORS[model], label=f"{MODEL_LABELS[model]} ({score:.3f})")
    axis.axhline(event_rate, ls="--", color="#777777", lw=1, label=f"Event rate ({event_rate:.3f})")
    axis.set(xlabel="Recall", ylabel="Precision", xlim=(0, 1), ylim=(0, 1))
    axis.legend(frameon=False, loc="upper right")
    fig.tight_layout()
    fig.savefig(figure_dir / "figure_pr_temporal_test.png", dpi=FIGURE_DPI)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(6.4, 5.4))
    for model, data in predictions.groupby("model"):
        observed, predicted = calibration_curve(
            data["target"], data["probability"], n_bins=10, strategy="quantile"
        )
        axis.plot(predicted, observed, marker="o", lw=2, color=MODEL_COLORS[model], label=MODEL_LABELS[model])
    axis.plot([0, 1], [0, 1], ls="--", color="#777777", lw=1)
    axis.set(xlabel="Mean predicted probability", ylabel="Observed event proportion", xlim=(0, 1), ylim=(0, 1))
    axis.legend(frameon=False, loc="upper left")
    fig.tight_layout()
    fig.savefig(figure_dir / "figure_calibration_temporal_test.png", dpi=FIGURE_DPI)
    plt.close(fig)


def plot_sensitivity(report_dir: Path, figure_dir: Path) -> None:
    path = report_dir / "sensitivity_temporal_test_metrics.csv"
    if not path.exists():
        return
    metrics = pd.read_csv(path)
    metrics = metrics.loc[metrics["threshold_name"].eq("fixed_0.5")].copy()
    metrics = metrics.sort_values("roc_auc")
    y = np.arange(len(metrics))
    fig, axis = plt.subplots(figsize=(7.2, 4.8))
    axis.errorbar(
        metrics["roc_auc"],
        y,
        xerr=np.vstack(
            [
                metrics["roc_auc"] - metrics["roc_auc_ci_low"],
                metrics["roc_auc_ci_high"] - metrics["roc_auc"],
            ]
        ),
        fmt="o",
        color="#2E6F9E",
        capsize=3,
    )
    axis.set_yticks(y, [name.replace("_", " ") for name in metrics["model"]])
    axis.set_xlabel("Temporal test ROC-AUC (95% CI)")
    axis.grid(axis="x", color="#DDDDDD", lw=0.7)
    fig.tight_layout()
    fig.savefig(figure_dir / "figure_sensitivity_auc.png", dpi=FIGURE_DPI)
    plt.close(fig)


def tpot_grouped_permutation_importance(
    test_data: pd.DataFrame,
    pipeline,
    repeats: int = 30,
    seed: int = 99,
) -> pd.DataFrame:
    """Measure original-feature AUC loss after post hoc test-set permutation."""

    y = test_data["target"].to_numpy()
    baseline = roc_auc_score(
        y,
        pipeline.predict_proba(encode_tpot_features(test_data).to_numpy())[:, 1],
    )
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    for feature in FULL_MODEL_FEATURES:
        losses: list[float] = []
        for _ in range(repeats):
            permuted = test_data.copy()
            permuted[feature] = rng.permutation(permuted[feature].to_numpy())
            score = roc_auc_score(
                y,
                pipeline.predict_proba(encode_tpot_features(permuted).to_numpy())[:, 1],
            )
            losses.append(baseline - score)
        rows.append(
            {
                "feature": feature,
                "label": VARIABLE_LABELS[feature],
                "mean_auc_loss": np.mean(losses),
                "sd_auc_loss": np.std(losses, ddof=1),
                "repeats": repeats,
                "baseline_auc": baseline,
            }
        )
    return pd.DataFrame(rows).sort_values("mean_auc_loss", ascending=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument("--table-dir", type=Path, default=PROJECT_ROOT / "tables")
    parser.add_argument("--figure-dir", type=Path, default=PROJECT_ROOT / "figures")
    parser.add_argument("--model-dir", type=Path, default=PROJECT_ROOT / "models")
    args = parser.parse_args()
    args.table_dir.mkdir(parents=True, exist_ok=True)
    args.figure_dir.mkdir(parents=True, exist_ok=True)

    analysis = pd.read_csv(args.processed_dir / "analysis_longitudinal.csv")
    table1 = build_table1(analysis)
    table1.to_csv(args.table_dir / "table1_baseline_characteristics.csv", index=False, encoding="utf-8-sig")
    main_metrics = [pd.read_csv(args.report_dir / "logistic_temporal_test_metrics.csv")]
    tpot_metrics = args.report_dir / "tpot_temporal_test_metrics.csv"
    if tpot_metrics.exists():
        main_metrics.append(pd.read_csv(tpot_metrics))
    pd.concat(main_metrics, ignore_index=True).to_csv(
        args.table_dir / "table2_main_model_performance.csv",
        index=False,
        encoding="utf-8-sig",
    )
    supplementary_outputs = {
        "sensitivity_temporal_test_metrics.csv": "table_s1_sensitivity_analyses.csv",
        "sex_stratified_temporal_performance.csv": "table_s2_sex_stratified_performance.csv",
        "sex_performance_bootstrap_differences.csv": "table_s3_sex_performance_contrasts.csv",
        "tpot_seed_summary.csv": "table_s4_tpot_seed_stability.csv",
    }
    for source_name, table_name in supplementary_outputs.items():
        source = args.report_dir / source_name
        if source.exists():
            pd.read_csv(source).to_csv(
                args.table_dir / table_name, index=False, encoding="utf-8-sig"
            )
    plot_cohort_flow(
        pd.read_csv(args.report_dir / "cohort_flow.csv"),
        args.figure_dir / "figure1_cohort_flow.png",
    )
    predictions = load_main_predictions(args.report_dir)
    plot_model_curves(predictions, args.figure_dir)
    plot_sensitivity(args.report_dir, args.figure_dir)

    tpot_model = args.model_dir / "tpot_final_pipeline.joblib"
    if tpot_model.exists():
        test = pd.read_csv(args.processed_dir / "temporal_test.csv")
        importance = tpot_grouped_permutation_importance(test, joblib.load(tpot_model))
        importance.to_csv(
            args.report_dir / "tpot_permutation_importance.csv",
            index=False,
            encoding="utf-8-sig",
        )
        shown = importance.head(15).sort_values("mean_auc_loss")
        fig, axis = plt.subplots(figsize=(7.2, 6.2))
        axis.barh(shown["label"], shown["mean_auc_loss"], color="#3B7EA1")
        axis.set_xlabel("Decrease in temporal test ROC-AUC after permutation")
        axis.grid(axis="x", color="#DDDDDD", lw=0.7)
        fig.tight_layout()
        fig.savefig(args.figure_dir / "figure_tpot_permutation_importance.png", dpi=FIGURE_DPI)
        plt.close(fig)
    print("Generated Table 1 and publication figures from frozen outputs.")


if __name__ == "__main__":
    main()
