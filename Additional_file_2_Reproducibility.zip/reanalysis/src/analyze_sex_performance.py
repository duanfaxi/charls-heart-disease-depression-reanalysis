"""Report sex-stratified performance and bootstrap performance differences."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

from src.paths import GENERATED_REPORT_DIR
from src.train_logistic_models import bootstrap_discrimination, calibration_parameters


def bootstrap_sex_difference(
    predictions: pd.DataFrame,
    metric: str,
    iterations: int,
    seed: int,
) -> dict[str, float | int | str]:
    """Bootstrap male minus female performance; test rows are one per person."""

    metric_function = {
        "roc_auc": roc_auc_score,
        "average_precision": average_precision_score,
    }[metric]
    male = predictions.loc[predictions["sex"].eq("male")].reset_index(drop=True)
    female = predictions.loc[predictions["sex"].eq("female")].reset_index(drop=True)
    observed = metric_function(male["target"], male["probability"]) - metric_function(
        female["target"], female["probability"]
    )
    rng = np.random.default_rng(seed)
    differences: list[float] = []
    for _ in range(iterations):
        male_sample = male.iloc[rng.integers(0, len(male), len(male))]
        female_sample = female.iloc[rng.integers(0, len(female), len(female))]
        if male_sample["target"].nunique() < 2 or female_sample["target"].nunique() < 2:
            continue
        differences.append(
            metric_function(male_sample["target"], male_sample["probability"])
            - metric_function(female_sample["target"], female_sample["probability"])
        )
    values = np.asarray(differences)
    p_value = 2 * min(np.mean(values <= 0), np.mean(values >= 0))
    return {
        "metric": metric,
        "contrast": "male_minus_female",
        "difference": float(observed),
        "ci_low": float(np.quantile(values, 0.025)),
        "ci_high": float(np.quantile(values, 0.975)),
        "bootstrap_two_sided_p": float(min(p_value, 1.0)),
        "bootstrap_valid_iterations": len(values),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument("--bootstrap-iterations", type=int, default=2000)
    args = parser.parse_args()

    prediction_paths = [args.report_dir / "logistic_temporal_test_predictions.csv"]
    tpot_path = args.report_dir / "tpot_temporal_test_predictions.csv"
    if tpot_path.exists():
        prediction_paths.append(tpot_path)
    predictions = pd.concat(
        [pd.read_csv(path, dtype={"participant_id": "string"}) for path in prediction_paths],
        ignore_index=True,
    )

    strata_rows: list[dict[str, float | int | str]] = []
    difference_rows: list[dict[str, float | int | str]] = []
    for model_index, (model, model_data) in enumerate(predictions.groupby("model")):
        for sex, stratum in model_data.groupby("sex"):
            intercept, slope = calibration_parameters(
                stratum["target"].to_numpy(), stratum["probability"].to_numpy()
            )
            intervals = bootstrap_discrimination(
                stratum["target"].to_numpy(),
                stratum["probability"].to_numpy(),
                iterations=args.bootstrap_iterations,
                seed=6100 + model_index * 10 + (0 if sex == "female" else 1),
            )
            strata_rows.append(
                {
                    "model": model,
                    "sex": sex,
                    "n": len(stratum),
                    "events": int(stratum["target"].sum()),
                    "event_rate": stratum["target"].mean(),
                    "roc_auc": roc_auc_score(stratum["target"], stratum["probability"]),
                    "average_precision": average_precision_score(
                        stratum["target"], stratum["probability"]
                    ),
                    "brier_score": brier_score_loss(
                        stratum["target"], stratum["probability"]
                    ),
                    "calibration_intercept": intercept,
                    "calibration_slope": slope,
                    **intervals,
                }
            )
        for metric_index, metric in enumerate(("roc_auc", "average_precision")):
            difference_rows.append(
                {
                    "model": model,
                    **bootstrap_sex_difference(
                        model_data,
                        metric,
                        iterations=args.bootstrap_iterations,
                        seed=5100 + model_index * 10 + metric_index,
                    ),
                }
            )

    pd.DataFrame(strata_rows).to_csv(
        args.report_dir / "sex_stratified_temporal_performance.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(difference_rows).to_csv(
        args.report_dir / "sex_performance_bootstrap_differences.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("Generated sex-stratified performance and bootstrap contrasts.")


if __name__ == "__main__":
    main()
