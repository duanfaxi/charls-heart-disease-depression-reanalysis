"""Fold-safe TPOT wrapper that prevents its default global median imputation."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_consistent_length
from tpot import TPOTClassifier
from tpot.config.classifier_sparse import classifier_config_sparse

from src.model_config import CATEGORICAL_FEATURES, FULL_MODEL_FEATURES


CATEGORY_LEVELS = {
    "sex": ["male", "female"],
    "education": [
        "no_formal",
        "below_primary",
        "primary",
        "middle_school",
        "high_or_vocational",
        "college_or_above",
    ],
    "smoking_status": ["current", "former", "never"],
    "alcohol_frequency": ["more_than_monthly", "monthly_or_less", "none"],
}


def encode_tpot_features(data: pd.DataFrame) -> pd.DataFrame:
    """Apply deterministic one-hot encoding without learning from test data."""

    output: dict[str, pd.Series] = {}
    for feature in FULL_MODEL_FEATURES:
        if feature not in CATEGORICAL_FEATURES:
            output[feature] = pd.to_numeric(data[feature], errors="coerce")
            continue
        values = data[feature].astype("string")
        for level in CATEGORY_LEVELS[feature]:
            output[f"{feature}__{level}"] = values.eq(level).fillna(False).astype(float)
        output[f"{feature}__missing"] = values.isna().astype(float)
    return pd.DataFrame(output, index=data.index, dtype=float)


def probability_sparse_config(negative_to_positive_ratio: float) -> dict[str, Any]:
    """Lock TPOT sparse to probability-capable classifiers and balanced options."""

    config = deepcopy(classifier_config_sparse)
    config.pop("sklearn.svm.LinearSVC", None)
    config["sklearn.ensemble.RandomForestClassifier"]["class_weight"] = ["balanced"]
    config["sklearn.linear_model.LogisticRegression"]["class_weight"] = ["balanced"]
    config["sklearn.linear_model.LogisticRegression"]["max_iter"] = [5000]
    config["xgboost.XGBClassifier"]["scale_pos_weight"] = [
        float(negative_to_positive_ratio)
    ]
    return config


class FoldSafeTPOTClassifier(TPOTClassifier):
    """Place median imputation inside every candidate's cross-validation fold."""

    def _check_dataset(self, features, target, sample_weight=None):
        feature_array = np.asarray(features, dtype=float)
        if feature_array.ndim != 2:
            raise ValueError("TPOT features must be a two-dimensional numeric matrix")
        if target is None:
            return feature_array
        target_array = np.asarray(target)
        check_consistent_length(feature_array, target_array)
        if sample_weight is not None:
            check_consistent_length(feature_array, sample_weight)
        return feature_array, target_array

    def _compile_to_sklearn(self, expr):
        candidate = super()._compile_to_sklearn(expr)
        return Pipeline(
            [
                (
                    "fold_imputer",
                    SimpleImputer(
                        strategy="median", add_indicator=True, keep_empty_features=True
                    ),
                ),
                ("tpot_candidate", candidate),
            ]
        )

