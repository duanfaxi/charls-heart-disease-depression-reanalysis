"""Join harmonized predictors to eligible windows and freeze temporal splits."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import pandas as pd

from src.model_config import AUDIT_ONLY_FEATURES, FULL_MODEL_FEATURES
from src.paths import GENERATED_REPORT_DIR, INTERIM_DATA_DIR, PROCESSED_DATA_DIR


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assemble(
    skeleton: pd.DataFrame, predictor_frames: dict[int, pd.DataFrame]
) -> pd.DataFrame:
    """Attach same-wave predictors to each eligible person-window."""

    pieces: list[pd.DataFrame] = []
    for wave, predictors in predictor_frames.items():
        subset = skeleton.loc[skeleton["baseline_wave"].eq(wave)].copy()
        predictors = predictors.drop(columns=["wave", "heart_disease"], errors="ignore")
        before = len(subset)
        subset = subset.merge(
            predictors,
            left_on="participant_id",
            right_on="ID",
            how="left",
            validate="many_to_one",
        ).drop(columns="ID")
        if len(subset) != before:
            raise AssertionError(f"Predictor merge changed wave {wave} row count")
        pieces.append(subset)
    analysis = pd.concat(pieces, ignore_index=True, sort=False).sort_values(
        ["baseline_wave", "participant_id"]
    )
    missing_features = sorted(set(FULL_MODEL_FEATURES).difference(analysis.columns))
    if missing_features:
        raise KeyError(f"Analysis data missing model features: {missing_features}")
    return analysis


def build_missingness_report(analysis: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, int | float | str]] = []
    for scope, frame in [("overall", analysis)]:
        for variable in [*FULL_MODEL_FEATURES, *AUDIT_ONLY_FEATURES]:
            rows.append(
                {
                    "scope": scope,
                    "baseline_wave": "all",
                    "variable": variable,
                    "n": len(frame),
                    "missing_n": int(frame[variable].isna().sum()),
                    "missing_percent": frame[variable].isna().mean() * 100,
                    "unique_nonmissing": int(frame[variable].nunique(dropna=True)),
                }
            )
    for wave, frame in analysis.groupby("baseline_wave"):
        for variable in [*FULL_MODEL_FEATURES, *AUDIT_ONLY_FEATURES]:
            rows.append(
                {
                    "scope": "wave",
                    "baseline_wave": wave,
                    "variable": variable,
                    "n": len(frame),
                    "missing_n": int(frame[variable].isna().sum()),
                    "missing_percent": frame[variable].isna().mean() * 100,
                    "unique_nonmissing": int(frame[variable].nunique(dropna=True)),
                }
            )
    return pd.DataFrame(rows)


def split_temporally(
    analysis: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Reserve 2018-2020 and remove its participant IDs from all development rows."""

    test = analysis.loc[analysis["baseline_wave"].eq(2018)].copy()
    test_ids = set(test["participant_id"])
    early = analysis.loc[analysis["baseline_wave"].isin([2013, 2015])].copy()
    excluded_overlap = early["participant_id"].isin(test_ids)
    removed = early.loc[excluded_overlap].copy()
    development = early.loc[~excluded_overlap].copy()

    overlap = set(development["participant_id"]).intersection(test_ids)
    if overlap:
        raise AssertionError("Development and temporal test participants overlap")
    report = pd.DataFrame(
        [
            {
                "development_records_before_id_exclusion": len(early),
                "development_records_removed_for_test_id_overlap": len(removed),
                "development_participants_removed": removed["participant_id"].nunique(),
                "development_records_final": len(development),
                "development_participants_final": development["participant_id"].nunique(),
                "test_records": len(test),
                "test_participants": test["participant_id"].nunique(),
                "final_id_overlap": len(overlap),
            }
        ]
    )
    return development, test, report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interim-dir", type=Path, default=INTERIM_DATA_DIR)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    args = parser.parse_args()
    args.processed_dir.mkdir(parents=True, exist_ok=True)
    args.report_dir.mkdir(parents=True, exist_ok=True)

    skeleton = pd.read_csv(
        args.processed_dir / "longitudinal_window_skeleton.csv",
        dtype={"participant_id": "string"},
    )
    predictor_frames = {
        wave: pd.read_csv(
            args.interim_dir / f"predictors_wave_{wave}.csv", dtype={"ID": "string"}
        )
        for wave in (2013, 2015, 2018)
    }
    analysis = assemble(skeleton, predictor_frames)
    development, test, overlap_report = split_temporally(analysis)

    outputs = {
        "analysis_longitudinal.csv": analysis,
        "development.csv": development,
        "temporal_test.csv": test,
    }
    manifest_rows: list[dict[str, int | str]] = []
    for name, frame in outputs.items():
        path = args.processed_dir / name
        frame.to_csv(path, index=False, encoding="utf-8-sig")
        manifest_rows.append(
            {
                "file_name": name,
                "rows": len(frame),
                "columns": len(frame.columns),
                "participants": frame["participant_id"].nunique(),
                "events": int(frame["target"].sum()),
                "sha256": sha256_file(path),
            }
        )

    build_missingness_report(analysis).to_csv(
        args.report_dir / "missingness_report.csv", index=False, encoding="utf-8-sig"
    )
    overlap_report.to_csv(
        args.report_dir / "development_test_overlap_report.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(manifest_rows).to_csv(
        args.report_dir / "analysis_data_manifest.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(
        f"Frozen {len(development)} development records and {len(test)} temporal "
        "test records with zero participant overlap."
    )


if __name__ == "__main__":
    main()

