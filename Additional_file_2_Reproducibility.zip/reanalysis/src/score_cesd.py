"""CESD-10 scoring shared by all CHARLS waves."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd


def score_cesd10(
    data: pd.DataFrame,
    items: Sequence[str],
    reverse_items: Sequence[str],
    minimum_answered: int = 8,
    threshold: float = 10.0,
) -> pd.DataFrame:
    """Score CESD-10, prorating only records with 8 or 9 valid responses."""

    items = list(items)
    reverse_items = list(reverse_items)
    missing_columns = sorted(set(items).difference(data.columns))
    if missing_columns:
        raise KeyError(f"Missing CESD source columns: {missing_columns}")
    if len(items) != 10 or not set(reverse_items).issubset(items):
        raise ValueError("CESD mapping must contain 10 items and valid reverse items")
    if not 1 <= minimum_answered <= len(items):
        raise ValueError("minimum_answered is outside the valid item count")

    numeric = data.loc[:, items].apply(pd.to_numeric, errors="coerce")
    valid = numeric.where(numeric.isin([1, 2, 3, 4]))
    scored = valid - 1
    scored.loc[:, reverse_items] = 3 - scored.loc[:, reverse_items]

    answered = valid.notna().sum(axis=1).astype("int64")
    raw_sum = scored.sum(axis=1, min_count=1)
    adjusted = raw_sum.div(answered).mul(10).where(answered.ge(minimum_answered))
    case = pd.Series(pd.NA, index=data.index, dtype="Int64")
    case.loc[adjusted.notna()] = adjusted.loc[adjusted.notna()].ge(threshold).astype(int)

    return pd.DataFrame(
        {
            "cesd_answered_items": answered,
            "cesd_missing_items": len(items) - answered,
            "cesd_raw_sum": raw_sum,
            "cesd_adjusted_score": adjusted,
            "cesd_case": case,
        },
        index=data.index,
    )

