"""Add Wilson confidence intervals to previously generated metric tables."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from statsmodels.stats.proportion import proportion_confint

from src.paths import GENERATED_REPORT_DIR


METRIC_FILES = [
    "logistic_temporal_test_metrics.csv",
    "tpot_temporal_test_metrics.csv",
    "sensitivity_temporal_test_metrics.csv",
]


def add_intervals(metrics: pd.DataFrame) -> pd.DataFrame:
    result = metrics.copy()
    definitions = {
        "sensitivity": ("true_positive", "false_negative"),
        "specificity": ("true_negative", "false_positive"),
        "ppv": ("true_positive", "false_positive"),
        "npv": ("true_negative", "false_negative"),
    }
    for metric, (success_column, failure_column) in definitions.items():
        intervals = result.apply(
            lambda row: proportion_confint(
                row[success_column],
                row[success_column] + row[failure_column],
                method="wilson",
            ),
            axis=1,
        )
        result[f"{metric}_ci_low"] = [float(value[0]) for value in intervals]
        result[f"{metric}_ci_high"] = [float(value[1]) for value in intervals]
    return result


def main(report_dir: Path = GENERATED_REPORT_DIR) -> None:
    for file_name in METRIC_FILES:
        path = report_dir / file_name
        if not path.exists():
            continue
        add_intervals(pd.read_csv(path)).to_csv(path, index=False, encoding="utf-8-sig")
        print(f"Updated {file_name}")


if __name__ == "__main__":
    main()
