"""Generate the exact cross-wave source-field dictionary used by the analysis."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.model_config import AUDIT_ONLY_FEATURES, BASIC_MODEL_FEATURES, FULL_MODEL_FEATURES
from src.paths import GENERATED_REPORT_DIR, PROJECT_ROOT
from src.wave_config import (
    CESD_CONFIG,
    COMMON_HEALTH_FIELDS,
    DISEASE_NAMES,
    HEART_CONFIG,
    PREDICTOR_CONFIG,
)


DEMOGRAPHIC_SOURCES = {
    2013: {
        "baseline_age": (
            "Demographic_Background.dta|Weights.dta",
            ["ba002_1", "zba002_1", "ba002_2", "zba002_2", "ba004", "iyear", "imonth"],
            "attained age from interview and birth dates; direct age fallback",
        ),
        "sex": ("Demographic_Background.dta", ["ba000_w2_3"], "1=male; 2=female"),
        "education": (
            "Demographic_Background.dta",
            ["zbd001", "bd001", "bd001_w2_4"],
            "current update, prior record, and new-report cascade; six categories",
        ),
        "partner_cohabiting": (
            "Demographic_Background.dta",
            ["be001"],
            "marital status 1 or 7=cohabiting",
        ),
    },
    2015: {
        "baseline_age": (
            "Demographic_Background.dta|Sample_Infor.dta",
            ["ba002_1", "ba004_w3_1", "ba002_2", "ba004_w3_2", "iyear", "imonth"],
            "attained age; actual birth date preferred over ID-card date",
        ),
        "sex": ("Demographic_Background.dta", ["ba000_w2_3"], "1=male; 2=female"),
        "education": (
            "Demographic_Background.dta|2013 carry-forward",
            ["bd001_w2_4"],
            "changed level if 1-11; code 12 carries 2013 level; six categories",
        ),
        "partner_cohabiting": (
            "Demographic_Background.dta",
            ["be001"],
            "marital status 1 or 7=cohabiting",
        ),
    },
    2018: {
        "baseline_age": (
            "Demographic_Background.dta|Sample_Infor.dta",
            ["ba002_1", "ba004_w3_1", "ba002_2", "ba004_w3_2", "iyear", "imonth"],
            "attained age; actual birth date preferred over ID-card date",
        ),
        "sex": ("Demographic_Background.dta", ["xrgender"], "1=male; 2=female"),
        "education": (
            "Demographic_Background.dta",
            ["bd001_w2_4"],
            "source levels 1-11 mapped to six categories",
        ),
        "partner_cohabiting": (
            "Demographic_Background.dta",
            ["be001"],
            "marital status 1=cohabiting",
        ),
    },
}


def _predictor_source_rows(wave: int) -> list[dict[str, str | int]]:
    config = PREDICTOR_CONFIG[wave]
    rows: list[dict[str, str | int]] = []

    def add(
        variable: str,
        file_name: str,
        fields: list[str],
        transformation: str,
        role: str = "candidate_predictor",
    ) -> None:
        rows.append(
            {
                "unified_variable": variable,
                "wave": wave,
                "source_file": file_name,
                "source_fields": "|".join(fields),
                "transformation": transformation,
                "analysis_role": role,
            }
        )

    for variable, (file_name, fields, transformation) in DEMOGRAPHIC_SOURCES[wave].items():
        add(variable, file_name, fields, transformation)

    add(
        "baseline_cesd10",
        CESD_CONFIG[wave]["file"],
        CESD_CONFIG[wave]["items"],
        f"1-4 to 0-3; reverse {CESD_CONFIG[wave]['reverse']}; prorate if 8-9 answered",
    )
    heart_fields = [HEART_CONFIG[wave]["prior"], HEART_CONFIG[wave]["current"]]
    add(
        "heart_disease",
        HEART_CONFIG[wave]["file"],
        heart_fields,
        "prior physician diagnosis==1 OR current/new diagnosis==1",
        "eligibility",
    )

    all_disease_fields: list[str] = []
    for index, disease_name in DISEASE_NAMES.items():
        fields = [
            config["disease_prior_prefix"].format(index=index),
            config["disease_current_prefix"].format(index=index),
        ]
        all_disease_fields.extend(fields)
        if disease_name != "heart_disease":
            note = "prior OR current physician diagnosis"
            if wave == 2015:
                note += "; structural skip blanks classified as no diagnosis"
            add(disease_name, "Health_Status_and_Functioning.dta", fields, note)
    add(
        "comorbidity_count",
        "Health_Status_and_Functioning.dta",
        all_disease_fields,
        "sum of 13 disease indicators; excludes heart disease; psychiatric item counted once",
    )
    add(
        "disability",
        "Health_Status_and_Functioning.dta",
        [*config["disability_prior"], *config["disability_current"]],
        "any prior or current disability field==1",
    )
    for medication, fields in config["medication"].items():
        add(
            medication,
            "Health_Status_and_Functioning.dta",
            fields,
            "Chinese or Western medication selected; disease absence=0; unresolved treated as missing",
        )
    pain_fields = list(config["pain_sites"])
    if config["pain_indicator"]:
        pain_fields.insert(0, config["pain_indicator"])
    add("pain", "Health_Status_and_Functioning.dta", pain_fields, "wave-specific pain indicator")
    add(
        "pain_site_count",
        "Health_Status_and_Functioning.dta",
        config["pain_sites"],
        "count selected pain sites",
    )
    add(
        "adl_score",
        "Health_Status_and_Functioning.dta",
        COMMON_HEALTH_FIELDS["adl"],
        "six complete items, each 1-4 recoded 0-3 and summed",
    )
    add(
        "iadl_score",
        "Health_Status_and_Functioning.dta",
        COMMON_HEALTH_FIELDS["iadl"],
        "five complete items, each 1-4 recoded 0-3 and summed",
    )
    add("sleep_hours", "Health_Status_and_Functioning.dta", ["da049"], "continuous 0-24 hours")
    add("nap_minutes", "Health_Status_and_Functioning.dta", ["da050"], "continuous 0-1440 minutes")
    add(
        "physical_activity_level",
        "Health_Status_and_Functioning.dta",
        COMMON_HEALTH_FIELDS["physical_activity"],
        "highest of vigorous, moderate, light, none; excluded from main model for structural missingness",
        "audit_only",
    )
    add(
        "smoking_status",
        "Health_Status_and_Functioning.dta",
        config["smoking"],
        "current, former, never; unresolved skip patterns remain missing",
    )
    add(
        "alcohol_frequency",
        "Health_Status_and_Functioning.dta",
        ["da067"],
        "more than monthly, monthly or less, none",
    )
    self_health_fields = ["da002"] if wave == 2018 else ["da001", "da002"]
    add(
        "self_rated_health",
        "Health_Status_and_Functioning.dta",
        self_health_fields,
        "randomized forms aligned to very good through very poor scale",
    )
    life_file = "Cognition.dta" if wave == 2018 else "Health_Status_and_Functioning.dta"
    add("life_satisfaction", life_file, ["dc028"], "ordinal 1-5, lower is more satisfied")
    add(
        "social_activity_count",
        "Health_Status_and_Functioning.dta",
        config["social_items"],
        "count selected activity types 1-11; none option gives zero",
    )
    add(
        "social_activity_frequency",
        "Health_Status_and_Functioning.dta",
        config["social_frequency"],
        "highest frequency: 3 daily, 2 weekly, 1 irregular, 0 no activity",
    )
    return rows


def build_dictionary(metadata: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, str | int]] = []
    for wave in (2013, 2015, 2018):
        rows.extend(_predictor_source_rows(wave))
    for outcome_wave in (2015, 2018, 2020):
        config = CESD_CONFIG[outcome_wave]
        rows.append(
            {
                "unified_variable": "target",
                "wave": outcome_wave,
                "source_file": config["file"],
                "source_fields": "|".join(config["items"]),
                "transformation": f"CESD-10 adjusted score >=10; reverse {config['reverse']}",
                "analysis_role": "outcome",
            }
        )
    dictionary = pd.DataFrame(rows)
    dictionary["in_basic_model"] = dictionary["unified_variable"].isin(BASIC_MODEL_FEATURES)
    dictionary["in_full_model"] = dictionary["unified_variable"].isin(FULL_MODEL_FEATURES)

    labels: list[str] = []
    value_labels: list[str] = []
    for row in dictionary.itertuples(index=False):
        row_labels: list[str] = []
        row_value_labels: list[str] = []
        file_names = row.source_file.split("|")
        for field in row.source_fields.split("|"):
            matches = metadata.loc[
                metadata["wave"].eq(row.wave)
                & metadata["variable"].eq(field)
                & metadata["file_name"].isin(file_names)
            ]
            if matches.empty:
                row_labels.append("")
                row_value_labels.append("")
            else:
                row_labels.append(str(matches.iloc[0]["variable_label"]))
                row_value_labels.append(str(matches.iloc[0]["value_labels_json"]))
        labels.append(" | ".join(row_labels))
        value_labels.append(" | ".join(row_value_labels))
    dictionary["source_labels"] = labels
    dictionary["source_value_labels_json"] = value_labels
    return dictionary


def build_harmonization_report(dictionary: pd.DataFrame) -> pd.DataFrame:
    """Summarize wave coverage and source changes for each unified variable."""

    rows: list[dict[str, object]] = []
    for variable, group in dictionary.groupby("unified_variable", sort=True):
        predictor_group = group.loc[group["analysis_role"].ne("outcome")]
        expected_waves = {2013, 2015, 2018} if not predictor_group.empty else {2015, 2018, 2020}
        observed_waves = set(group["wave"].astype(int))
        rows.append(
            {
                "unified_variable": variable,
                "analysis_role": "|".join(sorted(group["analysis_role"].unique())),
                "waves": "|".join(str(wave) for wave in sorted(observed_waves)),
                "expected_waves": "|".join(str(wave) for wave in sorted(expected_waves)),
                "complete_expected_wave_coverage": observed_waves == expected_waves,
                "source_files_by_wave": " || ".join(
                    f"{row.wave}:{row.source_file}" for row in group.itertuples(index=False)
                ),
                "source_fields_by_wave": " || ".join(
                    f"{row.wave}:{row.source_fields}" for row in group.itertuples(index=False)
                ),
                "transformation_by_wave": " || ".join(
                    f"{row.wave}:{row.transformation}" for row in group.itertuples(index=False)
                ),
                "in_basic_model": bool(group["in_basic_model"].any()),
                "in_full_model": bool(group["in_full_model"].any()),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument("--config-dir", type=Path, default=PROJECT_ROOT / "config")
    args = parser.parse_args()
    metadata = pd.read_csv(args.report_dir / "raw_variable_metadata.csv")
    dictionary = build_dictionary(metadata)
    args.config_dir.mkdir(parents=True, exist_ok=True)
    dictionary.to_csv(
        args.config_dir / "variable_map.csv", index=False, encoding="utf-8-sig"
    )
    dictionary.to_csv(
        args.report_dir / "variable_dictionary.csv", index=False, encoding="utf-8-sig"
    )
    build_harmonization_report(dictionary).to_csv(
        args.report_dir / "wave_harmonization_report.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(f"Documented {len(dictionary)} wave-specific variable mappings.")


if __name__ == "__main__":
    main()
