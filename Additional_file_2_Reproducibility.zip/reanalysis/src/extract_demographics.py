"""Extract and harmonize age, sex, education, and partner cohabitation."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from src.paths import INTERIM_DATA_DIR, RAW_WAVE_DIRS, ensure_output_directories


DEMOGRAPHIC_FILE = "Demographic_Background.dta"
INTERVIEW_FILE = {2013: "Weights.dta", 2015: "Sample_Infor.dta", 2018: "Sample_Infor.dta"}


def _numeric_valid(series: pd.Series, allowed: set[int] | None = None) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    if allowed is not None:
        numeric = numeric.where(numeric.isin(allowed))
    return numeric


def calculate_age(
    interview_year: pd.Series,
    interview_month: pd.Series,
    birth_year: pd.Series,
    birth_month: pd.Series,
) -> pd.Series:
    """Calculate attained age at interview, using months when both are valid."""

    interview_year = _numeric_valid(interview_year)
    birth_year = _numeric_valid(birth_year)
    interview_month = _numeric_valid(interview_month).where(lambda x: x.between(1, 12))
    birth_month = _numeric_valid(birth_month).where(lambda x: x.between(1, 12))
    valid_months = interview_month.notna() & birth_month.notna()
    before_birthday = pd.Series(0, index=interview_year.index, dtype="int64")
    before_birthday.loc[valid_months] = interview_month.loc[valid_months].lt(
        birth_month.loc[valid_months]
    ).astype(int)
    age = interview_year - birth_year - before_birthday
    return age.where(age.between(0, 120))


def harmonize_education(raw: pd.Series) -> pd.Series:
    """Map CHARLS education levels to six ordered, interpretable categories."""

    numeric = _numeric_valid(raw, set(range(1, 12)))
    category = pd.Series(pd.NA, index=raw.index, dtype="string")
    category.loc[numeric.eq(1)] = "no_formal"
    category.loc[numeric.isin([2, 3])] = "below_primary"
    category.loc[numeric.eq(4)] = "primary"
    category.loc[numeric.eq(5)] = "middle_school"
    category.loc[numeric.isin([6, 7])] = "high_or_vocational"
    category.loc[numeric.isin([8, 9, 10, 11])] = "college_or_above"
    return category


def _read_interview_date(wave: int) -> pd.DataFrame:
    path = RAW_WAVE_DIRS[wave] / INTERVIEW_FILE[wave]
    frame = pd.read_stata(
        path,
        columns=["ID", "iyear", "imonth"],
        convert_categoricals=False,
        preserve_dtypes=False,
    )
    frame["ID"] = frame["ID"].astype("string").str.strip()
    frame = frame.loc[frame["ID"].notna() & frame["ID"].ne("")].copy()
    conflicts = frame.groupby("ID")[["iyear", "imonth"]].nunique(dropna=False).gt(1).any(axis=1)
    if conflicts.any():
        raise ValueError(f"Wave {wave} has conflicting interview dates for duplicate IDs")
    return frame.drop_duplicates("ID")


def _derive_2013_education(frame: pd.DataFrame) -> pd.Series:
    prior = _numeric_valid(frame["zbd001"], set(range(1, 12)))
    newly_reported = _numeric_valid(frame["bd001"], set(range(1, 12)))
    update = _numeric_valid(frame["bd001_w2_4"], set(range(1, 13)))
    current = prior.copy()
    current.loc[update.between(1, 11)] = update.loc[update.between(1, 11)]
    current = current.combine_first(newly_reported)
    return current


def extract_demographics_by_wave() -> dict[int, pd.DataFrame]:
    """Build harmonized demographic records for all three baseline waves."""

    outputs: dict[int, pd.DataFrame] = {}
    education_2013: pd.Series | None = None

    for wave in (2013, 2015, 2018):
        path = RAW_WAVE_DIRS[wave] / DEMOGRAPHIC_FILE
        if wave == 2013:
            columns = [
                "ID",
                "zba002_1",
                "zba002_2",
                "ba002_1",
                "ba002_2",
                "ba004",
                "ba000_w2_3",
                "zbd001",
                "bd001",
                "bd001_w2_4",
                "be001",
            ]
        elif wave == 2015:
            columns = [
                "ID",
                "ba004_w3_1",
                "ba004_w3_2",
                "ba002_1",
                "ba002_2",
                "ba000_w2_3",
                "bd001_w2_4",
                "be001",
            ]
        else:
            columns = [
                "ID",
                "ba004_w3_1",
                "ba004_w3_2",
                "ba002_1",
                "ba002_2",
                "xrgender",
                "bd001_w2_4",
                "be001",
            ]

        raw = pd.read_stata(
            path,
            columns=columns,
            convert_categoricals=False,
            preserve_dtypes=False,
        )
        raw["ID"] = raw["ID"].astype("string").str.strip()
        if raw["ID"].isna().any() or raw["ID"].eq("").any() or raw["ID"].duplicated().any():
            raise ValueError(f"Wave {wave} demographic file has invalid or duplicate IDs")

        interview = _read_interview_date(wave)
        frame = raw.merge(interview, on="ID", how="left", validate="one_to_one")

        if wave == 2013:
            birth_year = _numeric_valid(frame["ba002_1"]).combine_first(
                _numeric_valid(frame["zba002_1"])
            )
            birth_month = _numeric_valid(frame["ba002_2"]).combine_first(
                _numeric_valid(frame["zba002_2"])
            )
            age = calculate_age(frame["iyear"], frame["imonth"], birth_year, birth_month)
            direct_age = _numeric_valid(frame["ba004"]).where(lambda x: x.between(0, 120))
            age = age.combine_first(direct_age)
            education_raw = _derive_2013_education(frame)
            sex_raw = frame["ba000_w2_3"]
            education_2013 = pd.Series(education_raw.values, index=frame["ID"])
        elif wave == 2015:
            birth_year = _numeric_valid(frame["ba002_1"]).combine_first(
                _numeric_valid(frame["ba004_w3_1"])
            )
            birth_month = _numeric_valid(frame["ba002_2"]).combine_first(
                _numeric_valid(frame["ba004_w3_2"])
            )
            age = calculate_age(frame["iyear"], frame["imonth"], birth_year, birth_month)
            update = _numeric_valid(frame["bd001_w2_4"], set(range(1, 13)))
            carried = frame["ID"].map(education_2013)
            education_raw = update.where(update.between(1, 11)).combine_first(carried)
            sex_raw = frame["ba000_w2_3"]
        else:
            birth_year = _numeric_valid(frame["ba002_1"]).combine_first(
                _numeric_valid(frame["ba004_w3_1"])
            )
            birth_month = _numeric_valid(frame["ba002_2"]).combine_first(
                _numeric_valid(frame["ba004_w3_2"])
            )
            age = calculate_age(frame["iyear"], frame["imonth"], birth_year, birth_month)
            education_raw = _numeric_valid(frame["bd001_w2_4"], set(range(1, 12)))
            sex_raw = frame["xrgender"]

        sex_numeric = _numeric_valid(sex_raw, {1, 2})
        sex = pd.Series(pd.NA, index=frame.index, dtype="string")
        sex.loc[sex_numeric.eq(1)] = "male"
        sex.loc[sex_numeric.eq(2)] = "female"
        marital = _numeric_valid(frame["be001"], set(range(1, 8)))
        partner_cohabiting = pd.Series(pd.NA, index=frame.index, dtype="Int64")
        partner_cohabiting.loc[marital.notna()] = marital.loc[marital.notna()].isin([1, 7]).astype(int)

        output = pd.DataFrame(
            {
                "ID": frame["ID"],
                "wave": wave,
                "interview_year": _numeric_valid(frame["iyear"]),
                "interview_month": _numeric_valid(frame["imonth"]),
                "birth_year": birth_year,
                "birth_month": birth_month,
                "age": age,
                "sex": sex,
                "education_raw": education_raw,
                "education": harmonize_education(education_raw),
                "marital_status_raw": marital,
                "partner_cohabiting": partner_cohabiting,
            }
        )
        outputs[wave] = output
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interim-dir", type=Path, default=INTERIM_DATA_DIR)
    args = parser.parse_args()
    ensure_output_directories()
    args.interim_dir.mkdir(parents=True, exist_ok=True)
    outputs = extract_demographics_by_wave()
    for wave, frame in outputs.items():
        frame.to_csv(
            args.interim_dir / f"demographics_wave_{wave}.csv",
            index=False,
            encoding="utf-8-sig",
        )
    print("Extracted harmonized demographics for 2013, 2015, and 2018.")


if __name__ == "__main__":
    main()
