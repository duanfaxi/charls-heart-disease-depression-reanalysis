"""Inventory raw CHARLS Stata files without modifying source data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd
from pandas.io.stata import StataReader

from src.paths import (
    GENERATED_REPORT_DIR,
    RAW_WAVE_DIRS,
    ensure_output_directories,
    validate_raw_directories,
)


ID_CANDIDATES = ("ID", "id", "individual_ID", "individual_id", "mergeid")


def _normalise_scalar(value: Any) -> Any:
    """Convert numpy scalar keys to values that JSON can serialize."""

    if hasattr(value, "item"):
        return value.item()
    return value


def inspect_dta(path: Path, wave: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Read Stata metadata and return file- and variable-level inventory rows."""

    with StataReader(path, convert_categoricals=False) as reader:
        variable_labels = reader.variable_labels()
        value_labels = reader.value_labels()
        variables = list(reader._varlist)
        label_sets = list(reader._lbllist)
        n_rows = int(reader._nobs)
        n_columns = int(reader._nvar)
        data_label = reader.data_label

    id_column = next((name for name in ID_CANDIDATES if name in variables), None)
    id_missing = None
    id_unique = None
    duplicate_rows = None
    duplicate_ids = None
    if id_column is not None:
        ids = pd.read_stata(
            path,
            columns=[id_column],
            convert_categoricals=False,
            preserve_dtypes=False,
        )[id_column]
        id_missing = int(ids.isna().sum())
        id_unique = int(ids.nunique(dropna=True))
        duplicate_mask = ids.notna() & ids.duplicated(keep=False)
        duplicate_rows = int(duplicate_mask.sum())
        duplicate_ids = int(ids.loc[duplicate_mask].nunique())

    stat = path.stat()
    file_row = {
        "wave": wave,
        "raw_directory": path.parent.name,
        "file_name": path.name,
        "relative_path": str(path.relative_to(path.parent.parent)),
        "file_size_bytes": stat.st_size,
        "modified_time": pd.Timestamp(stat.st_mtime, unit="s").isoformat(),
        "data_label": data_label,
        "n_rows": n_rows,
        "n_columns": n_columns,
        "id_column": id_column,
        "id_missing": id_missing,
        "id_unique": id_unique,
        "duplicate_rows": duplicate_rows,
        "duplicate_ids": duplicate_ids,
    }

    variable_rows: list[dict[str, Any]] = []
    for position, variable in enumerate(variables):
        label_set = label_sets[position]
        labels = value_labels.get(label_set, {}) if label_set else {}
        serializable_labels = {
            str(_normalise_scalar(key)): value for key, value in labels.items()
        }
        variable_rows.append(
            {
                "wave": wave,
                "raw_directory": path.parent.name,
                "file_name": path.name,
                "position": position + 1,
                "variable": variable,
                "variable_label": variable_labels.get(variable, ""),
                "value_label_set": label_set,
                "value_labels_json": json.dumps(
                    serializable_labels, ensure_ascii=False, sort_keys=True
                ),
            }
        )
    return file_row, variable_rows


def build_inventory() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Scan every raw DTA and return inventory, metadata, and duplicate reports."""

    validate_raw_directories()
    file_rows: list[dict[str, Any]] = []
    variable_rows: list[dict[str, Any]] = []

    for wave, directory in RAW_WAVE_DIRS.items():
        for path in sorted(directory.glob("*.dta"), key=lambda item: item.name.lower()):
            file_row, rows = inspect_dta(path, wave)
            file_rows.append(file_row)
            variable_rows.extend(rows)

    inventory = pd.DataFrame(file_rows).sort_values(["wave", "file_name"])
    metadata = pd.DataFrame(variable_rows).sort_values(
        ["wave", "file_name", "position"]
    )
    duplicate_report = inventory.loc[
        inventory["duplicate_rows"].fillna(0).gt(0),
        [
            "wave",
            "file_name",
            "n_rows",
            "id_column",
            "id_missing",
            "id_unique",
            "duplicate_rows",
            "duplicate_ids",
        ],
    ].copy()
    return inventory, metadata, duplicate_report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=GENERATED_REPORT_DIR,
        help="Directory for generated CSV audit files.",
    )
    args = parser.parse_args()

    ensure_output_directories()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    inventory, metadata, duplicate_report = build_inventory()

    inventory.to_csv(
        args.output_dir / "raw_file_inventory.csv", index=False, encoding="utf-8-sig"
    )
    metadata.to_csv(
        args.output_dir / "raw_variable_metadata.csv", index=False, encoding="utf-8-sig"
    )
    duplicate_report.to_csv(
        args.output_dir / "duplicate_id_report.csv", index=False, encoding="utf-8-sig"
    )

    print(
        f"Inventoried {len(inventory)} files and {len(metadata)} variables; "
        f"{len(duplicate_report)} files contain duplicate non-missing IDs."
    )


if __name__ == "__main__":
    main()

