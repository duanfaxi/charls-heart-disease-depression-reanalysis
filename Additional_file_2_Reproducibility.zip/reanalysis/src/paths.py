"""Project paths and raw-wave locations."""

from __future__ import annotations

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = PROJECT_ROOT.parent

RAW_WAVE_DIRS = {
    2013: WORKSPACE_ROOT / "CHARLS2013_Dataset",
    2015: WORKSPACE_ROOT / "CHARLS2015r",
    2018: WORKSPACE_ROOT / "CHARLS2018r",
    2020: WORKSPACE_ROOT / "CHARLS2020r",
}

GENERATED_REPORT_DIR = PROJECT_ROOT / "reports" / "generated"
INTERIM_DATA_DIR = PROJECT_ROOT / "data_interim"
PROCESSED_DATA_DIR = PROJECT_ROOT / "data_processed"


def ensure_output_directories() -> None:
    """Create only project-owned output directories."""

    for path in (GENERATED_REPORT_DIR, INTERIM_DATA_DIR, PROCESSED_DATA_DIR):
        path.mkdir(parents=True, exist_ok=True)


def validate_raw_directories() -> None:
    """Fail early if a configured raw wave directory is unavailable."""

    missing = [str(path) for path in RAW_WAVE_DIRS.values() if not path.is_dir()]
    if missing:
        raise FileNotFoundError(f"Missing raw CHARLS directories: {missing}")

