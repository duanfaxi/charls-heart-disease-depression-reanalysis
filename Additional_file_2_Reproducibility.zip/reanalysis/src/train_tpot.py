"""Run five fold-safe TPOT searches and evaluate one selected temporal model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import GroupKFold, cross_val_predict

from src.paths import GENERATED_REPORT_DIR, PROCESSED_DATA_DIR, PROJECT_ROOT
from src.tpot_fold_safe import (
    FoldSafeTPOTClassifier,
    encode_tpot_features,
    probability_sparse_config,
)
from src.train_logistic_models import (
    bootstrap_discrimination,
    evaluate_predictions,
    youden_threshold,
)


DEFAULT_SEEDS = [11, 29, 47, 71, 99]


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, range):
        return list(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


def pipeline_signature(pipeline_text: str) -> str:
    """Create a compact operator signature for stability comparison."""

    operators: list[str] = []
    token = ""
    for character in pipeline_text:
        if character.isalnum() or character == "_":
            token += character
        elif character == "(" and token:
            if token not in {"input_matrix"}:
                operators.append(token)
            token = ""
        elif character in ",)":
            token = ""
    return ">".join(operators)


def run_searches(
    development: pd.DataFrame,
    seeds: list[int],
    generations: int,
    population_size: int,
    max_time_mins: int,
    max_eval_time_mins: int,
    model_dir: Path,
    log_dir: Path,
) -> tuple[list[dict[str, Any]], dict[int, FoldSafeTPOTClassifier], pd.DataFrame]:
    x = encode_tpot_features(development)
    y = development["target"].astype(int).to_numpy()
    groups = development["participant_id"].astype(str).to_numpy()
    class_ratio = float((y == 0).sum() / (y == 1).sum())
    config = probability_sparse_config(class_ratio)
    (model_dir / "tpot_checkpoints").mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    with (model_dir / "tpot_search_config.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "generations": generations,
                "population_size": population_size,
                "max_time_mins": max_time_mins,
                "max_eval_time_mins": max_eval_time_mins,
                "seeds": seeds,
                "scoring": "roc_auc",
                "cv": "GroupKFold(n_splits=5)",
                "class_ratio": class_ratio,
                "config_dict": _jsonable(config),
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )

    summaries: list[dict[str, Any]] = []
    fitted: dict[int, FoldSafeTPOTClassifier] = {}
    oof_frames: list[pd.DataFrame] = []
    for seed in seeds:
        checkpoint = model_dir / "tpot_checkpoints" / f"seed_{seed}"
        checkpoint.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"tpot_seed_{seed}.log"
        with log_path.open("w", encoding="utf-8") as log_handle:
            optimizer = FoldSafeTPOTClassifier(
                generations=generations,
                population_size=population_size,
                scoring="roc_auc",
                cv=GroupKFold(n_splits=5),
                n_jobs=-1,
                max_time_mins=max_time_mins,
                max_eval_time_mins=max_eval_time_mins,
                random_state=seed,
                config_dict=config,
                periodic_checkpoint_folder=str(checkpoint),
                verbosity=2,
                disable_update_check=True,
                log_file=log_handle,
            )
            optimizer.fit(x, y, groups=groups)
        pipeline_text = str(optimizer._optimized_pipeline)
        oof_probability = cross_val_predict(
            clone(optimizer.fitted_pipeline_),
            x,
            y,
            groups=groups,
            cv=GroupKFold(n_splits=5),
            method="predict_proba",
            n_jobs=-1,
        )[:, 1]
        summary = {
            "seed": seed,
            "internal_tpot_roc_auc": float(optimizer._optimized_pipeline_score),
            "fresh_grouped_oof_roc_auc": roc_auc_score(y, oof_probability),
            "fresh_grouped_oof_average_precision": average_precision_score(
                y, oof_probability
            ),
            "pipeline_signature": pipeline_signature(pipeline_text),
            "pipeline_text": pipeline_text,
        }
        summaries.append(summary)
        fitted[seed] = optimizer
        joblib.dump(
            optimizer.fitted_pipeline_,
            model_dir / f"tpot_seed_{seed}_pipeline.joblib",
        )
        (model_dir / f"tpot_seed_{seed}_metadata.json").write_text(
            json.dumps(_jsonable(summary), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (model_dir / f"tpot_seed_{seed}_pipeline.txt").write_text(
            pipeline_text, encoding="utf-8"
        )
        oof_frames.append(
            development[
                ["participant_id", "baseline_wave", "outcome_wave", "sex", "target"]
            ].assign(seed=seed, oof_probability=oof_probability)
        )
    return summaries, fitted, pd.concat(oof_frames, ignore_index=True)


def select_seed(summary: pd.DataFrame) -> int:
    """Select highest fresh grouped OOF AUC, then AP, then lower seed."""

    ranked = summary.sort_values(
        ["fresh_grouped_oof_roc_auc", "fresh_grouped_oof_average_precision", "seed"],
        ascending=[False, False, True],
    )
    return int(ranked.iloc[0]["seed"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument("--model-dir", type=Path, default=PROJECT_ROOT / "models")
    parser.add_argument("--log-dir", type=Path, default=PROJECT_ROOT / "logs")
    parser.add_argument("--seeds", nargs="+", type=int, default=DEFAULT_SEEDS)
    parser.add_argument("--generations", type=int, default=5)
    parser.add_argument("--population-size", type=int, default=50)
    parser.add_argument("--max-time-mins", type=int, default=120)
    parser.add_argument("--max-eval-time-mins", type=int, default=10)
    parser.add_argument("--bootstrap-iterations", type=int, default=2000)
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    args.model_dir.mkdir(parents=True, exist_ok=True)

    development = pd.read_csv(
        args.processed_dir / "development.csv", dtype={"participant_id": "string"}
    )
    temporal_test = pd.read_csv(
        args.processed_dir / "temporal_test.csv", dtype={"participant_id": "string"}
    )
    if set(development["participant_id"]).intersection(temporal_test["participant_id"]):
        raise AssertionError("Development and temporal test IDs overlap")

    summaries, fitted, oof = run_searches(
        development,
        seeds=args.seeds,
        generations=args.generations,
        population_size=args.population_size,
        max_time_mins=args.max_time_mins,
        max_eval_time_mins=args.max_eval_time_mins,
        model_dir=args.model_dir,
        log_dir=args.log_dir,
    )
    summary = pd.DataFrame(summaries)
    selected_seed = select_seed(summary)
    summary["selected"] = summary["seed"].eq(selected_seed)
    summary.to_csv(
        args.report_dir / "tpot_seed_summary.csv", index=False, encoding="utf-8-sig"
    )
    oof.to_csv(
        args.report_dir / "tpot_all_seed_oof_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    selected_oof = oof.loc[oof["seed"].eq(selected_seed), "oof_probability"].to_numpy()
    threshold = youden_threshold(development["target"].to_numpy(), selected_oof)
    selected_optimizer = fitted[selected_seed]
    selected_pipeline = selected_optimizer.fitted_pipeline_
    joblib.dump(selected_pipeline, args.model_dir / "tpot_final_pipeline.joblib")

    test_x = encode_tpot_features(temporal_test)
    test_probability = selected_pipeline.predict_proba(test_x.to_numpy())[:, 1]
    y_test = temporal_test["target"].astype(int).to_numpy()
    intervals = bootstrap_discrimination(
        y_test,
        test_probability,
        iterations=args.bootstrap_iterations,
        seed=selected_seed,
    )
    metrics = [
        evaluate_predictions(
            "tpot_final",
            y_test,
            test_probability,
            threshold_value,
            threshold_name,
            intervals,
        )
        for threshold_name, threshold_value in (
            ("fixed_0.5", 0.5),
            ("development_oof_youden", threshold),
        )
    ]
    pd.DataFrame(metrics).assign(selected_seed=selected_seed).to_csv(
        args.report_dir / "tpot_temporal_test_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    temporal_test[
        ["participant_id", "baseline_wave", "outcome_wave", "sex", "target"]
    ].assign(
        model="tpot_final",
        selected_seed=selected_seed,
        probability=test_probability,
    ).to_csv(
        args.report_dir / "tpot_temporal_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(f"Selected TPOT seed {selected_seed} and evaluated the temporal test once.")


if __name__ == "__main__":
    main()
