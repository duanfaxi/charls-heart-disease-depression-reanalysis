"""Train the basic and full logistic models with grouped internal validation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.proportion import proportion_confint
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.model_config import BASIC_MODEL_FEATURES, CATEGORICAL_FEATURES, FULL_MODEL_FEATURES
from src.paths import GENERATED_REPORT_DIR, PROCESSED_DATA_DIR, PROJECT_ROOT


RANDOM_STATE = 99
C_GRID = [0.01, 0.1, 1.0, 10.0]


def build_pipeline(features: list[str], c_value: float = 1.0) -> Pipeline:
    categorical = [feature for feature in features if feature in CATEGORICAL_FEATURES]
    continuous = [feature for feature in features if feature not in categorical]

    continuous_pipe = Pipeline(
        [
            (
                "imputer",
                SimpleImputer(
                    strategy="median", add_indicator=True, keep_empty_features=True
                ),
            ),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        [
            (
                "imputer",
                SimpleImputer(
                    strategy="most_frequent", add_indicator=True, keep_empty_features=True
                ),
            ),
            (
                "onehot",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
            ),
        ]
    )
    preprocess = ColumnTransformer(
        [
            ("continuous", continuous_pipe, continuous),
            ("categorical", categorical_pipe, categorical),
        ],
        remainder="drop",
        verbose_feature_names_out=True,
    )
    model = LogisticRegression(
        C=c_value,
        penalty="l2",
        solver="liblinear",
        class_weight="balanced",
        max_iter=5000,
        random_state=RANDOM_STATE,
    )
    return Pipeline([("preprocess", preprocess), ("model", model)])


def grouped_oof_predictions(
    estimator: Pipeline,
    data: pd.DataFrame,
    features: list[str],
    tune_c: bool,
) -> tuple[np.ndarray, list[dict[str, float | int]]]:
    """Generate leakage-free OOF predictions, with nested tuning when requested."""

    x = data[features]
    y = data["target"].astype(int).to_numpy()
    groups = data["participant_id"].astype(str).to_numpy()
    outer = GroupKFold(n_splits=5)
    predictions = np.full(len(data), np.nan)
    tuning_rows: list[dict[str, float | int]] = []

    for fold, (train_index, valid_index) in enumerate(
        outer.split(x, y, groups), start=1
    ):
        train_groups = groups[train_index]
        valid_groups = groups[valid_index]
        if set(train_groups).intersection(valid_groups):
            raise AssertionError("Participant leakage within grouped CV")
        fold_estimator = clone(estimator)
        if tune_c:
            inner = GroupKFold(n_splits=5)
            search = GridSearchCV(
                fold_estimator,
                param_grid={"model__C": C_GRID},
                scoring="roc_auc",
                cv=inner,
                n_jobs=-1,
                refit=True,
            )
            search.fit(
                x.iloc[train_index],
                y[train_index],
                groups=train_groups,
            )
            fold_estimator = search.best_estimator_
            tuning_rows.append(
                {
                    "outer_fold": fold,
                    "best_c": float(search.best_params_["model__C"]),
                    "inner_best_roc_auc": float(search.best_score_),
                }
            )
        else:
            fold_estimator.fit(x.iloc[train_index], y[train_index])
            tuning_rows.append(
                {"outer_fold": fold, "best_c": 1.0, "inner_best_roc_auc": np.nan}
            )
        predictions[valid_index] = fold_estimator.predict_proba(x.iloc[valid_index])[:, 1]

    if np.isnan(predictions).any():
        raise AssertionError("OOF prediction vector is incomplete")
    return predictions, tuning_rows


def youden_threshold(y_true: np.ndarray, probability: np.ndarray) -> float:
    false_positive_rate, true_positive_rate, thresholds = roc_curve(y_true, probability)
    finite = np.isfinite(thresholds)
    index = np.argmax((true_positive_rate - false_positive_rate)[finite])
    return float(thresholds[finite][index])


def calibration_parameters(
    y_true: np.ndarray, probability: np.ndarray
) -> tuple[float, float]:
    clipped = np.clip(probability, 1e-6, 1 - 1e-6)
    logit = np.log(clipped / (1 - clipped))
    design = sm.add_constant(logit)
    fitted = sm.GLM(y_true, design, family=sm.families.Binomial()).fit()
    return float(fitted.params[0]), float(fitted.params[1])


def bootstrap_discrimination(
    y_true: np.ndarray,
    probability: np.ndarray,
    iterations: int = 2000,
    seed: int = RANDOM_STATE,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    auc_values: list[float] = []
    ap_values: list[float] = []
    for _ in range(iterations):
        index = rng.integers(0, len(y_true), len(y_true))
        sampled_y = y_true[index]
        if np.unique(sampled_y).size < 2:
            continue
        sampled_p = probability[index]
        auc_values.append(roc_auc_score(sampled_y, sampled_p))
        ap_values.append(average_precision_score(sampled_y, sampled_p))
    if len(auc_values) < iterations * 0.95:
        raise RuntimeError("Too many invalid bootstrap samples")
    return {
        "roc_auc_ci_low": float(np.quantile(auc_values, 0.025)),
        "roc_auc_ci_high": float(np.quantile(auc_values, 0.975)),
        "average_precision_ci_low": float(np.quantile(ap_values, 0.025)),
        "average_precision_ci_high": float(np.quantile(ap_values, 0.975)),
        "bootstrap_valid_iterations": len(auc_values),
    }


def evaluate_predictions(
    model_name: str,
    y_true: np.ndarray,
    probability: np.ndarray,
    threshold: float,
    threshold_name: str,
    confidence_intervals: dict[str, float],
) -> dict[str, float | int | str]:
    predicted = probability >= threshold
    tn, fp, fn, tp = confusion_matrix(y_true, predicted, labels=[0, 1]).ravel()
    intercept, slope = calibration_parameters(y_true, probability)
    sensitivity_ci = proportion_confint(tp, tp + fn, method="wilson")
    specificity_ci = proportion_confint(tn, tn + fp, method="wilson")
    ppv_ci = proportion_confint(tp, tp + fp, method="wilson")
    npv_ci = proportion_confint(tn, tn + fn, method="wilson")
    return {
        "model": model_name,
        "threshold_name": threshold_name,
        "threshold": threshold,
        "n": len(y_true),
        "events": int(y_true.sum()),
        "event_rate": float(y_true.mean()),
        "roc_auc": roc_auc_score(y_true, probability),
        "average_precision": average_precision_score(y_true, probability),
        "brier_score": brier_score_loss(y_true, probability),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "sensitivity": recall_score(y_true, predicted, zero_division=0),
        "specificity": tn / (tn + fp) if tn + fp else np.nan,
        "ppv": precision_score(y_true, predicted, zero_division=0),
        "npv": tn / (tn + fn) if tn + fn else np.nan,
        "f1": f1_score(y_true, predicted, zero_division=0),
        "true_positive": int(tp),
        "false_positive": int(fp),
        "true_negative": int(tn),
        "false_negative": int(fn),
        "sensitivity_ci_low": float(sensitivity_ci[0]),
        "sensitivity_ci_high": float(sensitivity_ci[1]),
        "specificity_ci_low": float(specificity_ci[0]),
        "specificity_ci_high": float(specificity_ci[1]),
        "ppv_ci_low": float(ppv_ci[0]),
        "ppv_ci_high": float(ppv_ci[1]),
        "npv_ci_low": float(npv_ci[0]),
        "npv_ci_high": float(npv_ci[1]),
        **confidence_intervals,
    }


def fit_final_model(
    estimator: Pipeline,
    development: pd.DataFrame,
    features: list[str],
    tune_c: bool,
) -> tuple[Pipeline, dict[str, float]]:
    x = development[features]
    y = development["target"].astype(int)
    groups = development["participant_id"].astype(str)
    if not tune_c:
        estimator.fit(x, y)
        return estimator, {"model__C": 1.0}
    search = GridSearchCV(
        estimator,
        param_grid={"model__C": C_GRID},
        scoring="roc_auc",
        cv=GroupKFold(n_splits=5),
        n_jobs=-1,
        refit=True,
    )
    search.fit(x, y, groups=groups)
    return search.best_estimator_, {
        "model__C": float(search.best_params_["model__C"]),
        "development_cv_roc_auc": float(search.best_score_),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument("--model-dir", type=Path, default=PROJECT_ROOT / "models")
    parser.add_argument("--bootstrap-iterations", type=int, default=2000)
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    args.model_dir.mkdir(parents=True, exist_ok=True)

    development = pd.read_csv(
        args.processed_dir / "development.csv", dtype={"participant_id": "string"}
    )
    temporal_test = pd.read_csv(
        args.processed_dir / "temporal_test.csv", dtype={"participant_id": "string"}
    )
    overlap = set(development["participant_id"]).intersection(temporal_test["participant_id"])
    if overlap:
        raise AssertionError("Development and test participant IDs overlap")

    specifications = {
        "basic_logistic": (BASIC_MODEL_FEATURES, False),
        "full_penalized_logistic": (FULL_MODEL_FEATURES, True),
    }
    result_rows: list[dict[str, float | int | str]] = []
    prediction_frames: list[pd.DataFrame] = []
    tuning_frames: list[pd.DataFrame] = []

    for model_index, (model_name, (features, tune_c)) in enumerate(specifications.items()):
        estimator = build_pipeline(features)
        oof, tuning_rows = grouped_oof_predictions(
            estimator, development, features, tune_c=tune_c
        )
        threshold = youden_threshold(development["target"].to_numpy(), oof)
        final_model, final_params = fit_final_model(
            estimator, development, features, tune_c=tune_c
        )
        probability = final_model.predict_proba(temporal_test[features])[:, 1]
        y_test = temporal_test["target"].astype(int).to_numpy()
        intervals = bootstrap_discrimination(
            y_test,
            probability,
            iterations=args.bootstrap_iterations,
            seed=RANDOM_STATE + model_index,
        )
        for threshold_name, threshold_value in (
            ("fixed_0.5", 0.5),
            ("development_oof_youden", threshold),
        ):
            result_rows.append(
                evaluate_predictions(
                    model_name,
                    y_test,
                    probability,
                    threshold_value,
                    threshold_name,
                    intervals,
                )
            )

        joblib.dump(final_model, args.model_dir / f"{model_name}.joblib")
        pd.DataFrame(tuning_rows).assign(
            model=model_name,
            final_parameters=json.dumps(final_params, sort_keys=True),
        ).to_csv(
            args.report_dir / f"{model_name}_nested_cv.csv",
            index=False,
            encoding="utf-8-sig",
        )
        tuning_frames.append(
            pd.DataFrame(
                [
                    {
                        "model": model_name,
                        "features": "|".join(features),
                        "oof_roc_auc": roc_auc_score(development["target"], oof),
                        "oof_average_precision": average_precision_score(
                            development["target"], oof
                        ),
                        "youden_threshold": threshold,
                        "final_parameters": json.dumps(final_params, sort_keys=True),
                    }
                ]
            )
        )
        prediction_frames.append(
            temporal_test[
                ["participant_id", "baseline_wave", "outcome_wave", "sex", "target"]
            ].assign(model=model_name, probability=probability)
        )
        development[
            ["participant_id", "baseline_wave", "outcome_wave", "sex", "target"]
        ].assign(model=model_name, oof_probability=oof).to_csv(
            args.report_dir / f"{model_name}_development_oof_predictions.csv",
            index=False,
            encoding="utf-8-sig",
        )

    pd.DataFrame(result_rows).to_csv(
        args.report_dir / "logistic_temporal_test_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.concat(prediction_frames, ignore_index=True).to_csv(
        args.report_dir / "logistic_temporal_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.concat(tuning_frames, ignore_index=True).to_csv(
        args.report_dir / "logistic_development_cv_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("Trained and evaluated the two pre-specified logistic models.")


if __name__ == "__main__":
    main()
