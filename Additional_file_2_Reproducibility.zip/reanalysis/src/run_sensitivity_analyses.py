"""Run pre-specified sensitivity analyses with the full logistic model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbalancedPipeline
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score

from src.model_config import FULL_MODEL_FEATURES
from src.paths import GENERATED_REPORT_DIR, PROCESSED_DATA_DIR, PROJECT_ROOT
from src.train_logistic_models import (
    RANDOM_STATE,
    bootstrap_discrimination,
    build_pipeline,
    evaluate_predictions,
    fit_final_model,
    grouped_oof_predictions,
    youden_threshold,
)


FEATURE_REMOVALS = {
    "exclude_baseline_cesd10": ["baseline_cesd10"],
    "exclude_self_rated_health_and_life_satisfaction": [
        "self_rated_health",
        "life_satisfaction",
    ],
    "exclude_psychiatric_disease": ["emotional_or_psychiatric_disease"],
}


def build_smote_pipeline(features: list[str]) -> ImbalancedPipeline:
    """Put SMOTE after fold-fitted preprocessing and before classification."""

    standard = build_pipeline(features)
    return ImbalancedPipeline(
        [
            ("preprocess", clone(standard.named_steps["preprocess"])),
            ("smote", SMOTE(random_state=RANDOM_STATE)),
            (
                "model",
                LogisticRegression(
                    penalty="l2",
                    solver="liblinear",
                    class_weight=None,
                    max_iter=5000,
                    random_state=RANDOM_STATE,
                ),
            ),
        ]
    )


def earliest_window_per_participant(data: pd.DataFrame) -> pd.DataFrame:
    """Retain each participant's earliest eligible development window."""

    return (
        data.sort_values(["participant_id", "baseline_wave"])
        .drop_duplicates("participant_id", keep="first")
        .reset_index(drop=True)
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    parser.add_argument(
        "--model-dir", type=Path, default=PROJECT_ROOT / "models" / "sensitivity"
    )
    parser.add_argument("--bootstrap-iterations", type=int, default=2000)
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    args.model_dir.mkdir(parents=True, exist_ok=True)

    development = pd.read_csv(
        args.processed_dir / "development.csv", dtype={"participant_id": "string"}
    )
    temporal_test = pd.read_csv(
        args.processed_dir / "temporal_test.csv", dtype={"participant_id": "string"}
    )
    if set(development["participant_id"]).intersection(temporal_test["participant_id"]):
        raise AssertionError("Development and temporal test IDs overlap")

    scenarios: list[tuple[str, list[str], pd.DataFrame, bool]] = []
    for name, removals in FEATURE_REMOVALS.items():
        features = [feature for feature in FULL_MODEL_FEATURES if feature not in removals]
        scenarios.append((name, features, development, False))
    scenarios.extend(
        [
            ("training_fold_smote", FULL_MODEL_FEATURES, development, True),
            (
                "earliest_window_per_participant",
                FULL_MODEL_FEATURES,
                earliest_window_per_participant(development),
                False,
            ),
        ]
    )

    metric_rows: list[dict[str, object]] = []
    prediction_frames: list[pd.DataFrame] = []
    cv_rows: list[dict[str, object]] = []
    for scenario_index, (name, features, scenario_data, use_smote) in enumerate(scenarios):
        estimator = build_smote_pipeline(features) if use_smote else build_pipeline(features)
        oof, tuning = grouped_oof_predictions(
            estimator, scenario_data, features, tune_c=True
        )
        threshold = youden_threshold(scenario_data["target"].to_numpy(), oof)
        fitted, parameters = fit_final_model(
            estimator, scenario_data, features, tune_c=True
        )
        probability = fitted.predict_proba(temporal_test[features])[:, 1]
        y_test = temporal_test["target"].astype(int).to_numpy()
        intervals = bootstrap_discrimination(
            y_test,
            probability,
            iterations=args.bootstrap_iterations,
            seed=RANDOM_STATE + 20 + scenario_index,
        )
        for threshold_name, threshold_value in (
            ("fixed_0.5", 0.5),
            ("development_oof_youden", threshold),
        ):
            metric_rows.append(
                {
                    **evaluate_predictions(
                        name,
                        y_test,
                        probability,
                        threshold_value,
                        threshold_name,
                        intervals,
                    ),
                    "development_records": len(scenario_data),
                    "development_participants": scenario_data["participant_id"].nunique(),
                    "feature_count": len(features),
                    "features_removed": "|".join(
                        feature for feature in FULL_MODEL_FEATURES if feature not in features
                    ),
                    "uses_smote": use_smote,
                }
            )
        prediction_frames.append(
            temporal_test[
                ["participant_id", "baseline_wave", "outcome_wave", "sex", "target"]
            ].assign(model=name, probability=probability)
        )
        cv_rows.append(
            {
                "scenario": name,
                "development_records": len(scenario_data),
                "development_participants": scenario_data["participant_id"].nunique(),
                "oof_roc_auc": roc_auc_score(scenario_data["target"], oof),
                "oof_average_precision": average_precision_score(
                    scenario_data["target"], oof
                ),
                "youden_threshold": threshold,
                "final_parameters": json.dumps(parameters, sort_keys=True),
                "nested_fold_parameters": json.dumps(tuning, sort_keys=True),
            }
        )
        joblib.dump(fitted, args.model_dir / f"{name}.joblib")

    pd.DataFrame(metric_rows).to_csv(
        args.report_dir / "sensitivity_temporal_test_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.concat(prediction_frames, ignore_index=True).to_csv(
        args.report_dir / "sensitivity_temporal_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(cv_rows).to_csv(
        args.report_dir / "sensitivity_development_cv_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print("Completed five pre-specified sensitivity analyses.")


if __name__ == "__main__":
    main()
