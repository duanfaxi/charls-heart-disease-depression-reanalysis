"""Build longitudinal person-window skeletons and auditable cohort flows."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.paths import (
    GENERATED_REPORT_DIR,
    INTERIM_DATA_DIR,
    PROCESSED_DATA_DIR,
    ensure_output_directories,
)


WINDOWS = ((2013, 2015), (2015, 2018), (2018, 2020))
OLD_FINAL_COUNTS = {(2013, 2015): 713, (2015, 2018): 958, (2018, 2020): 541}


def _assert_unique_id(frame: pd.DataFrame, label: str) -> None:
    if "ID" not in frame:
        raise KeyError(f"{label} has no ID column")
    if frame["ID"].isna().any() or frame["ID"].astype("string").str.strip().eq("").any():
        raise ValueError(f"{label} contains missing participant IDs")
    if frame["ID"].duplicated().any():
        raise ValueError(f"{label} contains duplicate participant IDs")


def _flow_step(
    frame: pd.DataFrame,
    keep: pd.Series,
    step_order: int,
    step: str,
    baseline_wave: int,
    outcome_wave: int,
) -> tuple[pd.DataFrame, dict[str, int | str]]:
    keep = keep.fillna(False).astype(bool)
    before = len(frame)
    retained = frame.loc[keep].copy()
    row = {
        "baseline_wave": baseline_wave,
        "outcome_wave": outcome_wave,
        "step_order": step_order,
        "step": step,
        "n_before": before,
        "n_excluded": before - len(retained),
        "n_remaining": len(retained),
    }
    return retained, row


def build_one_window(
    baseline_core: pd.DataFrame,
    baseline_demographics: pd.DataFrame,
    outcome_core: pd.DataFrame,
    baseline_wave: int,
    outcome_wave: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Apply the pre-specified inclusion sequence to one adjacent-wave window."""

    _assert_unique_id(baseline_core, f"{baseline_wave} core")
    _assert_unique_id(baseline_demographics, f"{baseline_wave} demographics")
    _assert_unique_id(outcome_core, f"{outcome_wave} core")

    baseline = baseline_core.loc[
        baseline_core["heart_module_present"].eq(True)
    ].copy()
    baseline = baseline.merge(
        baseline_demographics.drop(columns=["wave"], errors="ignore"),
        on="ID",
        how="left",
        validate="one_to_one",
    )
    outcome = outcome_core.loc[:, [
        "ID",
        "cesd_answered_items",
        "cesd_missing_items",
        "cesd_raw_sum",
        "cesd_adjusted_score",
        "cesd_case",
        "cesd_module_present",
    ]].rename(
        columns={
            "cesd_answered_items": "outcome_cesd_answered_items",
            "cesd_missing_items": "outcome_cesd_missing_items",
            "cesd_raw_sum": "outcome_cesd_raw_sum",
            "cesd_adjusted_score": "outcome_cesd10",
            "cesd_case": "outcome_cesd_case",
            "cesd_module_present": "outcome_cesd_module_present",
        }
    )
    frame = baseline.merge(outcome, on="ID", how="left", validate="one_to_one")

    flow: list[dict[str, int | str]] = [
        {
            "baseline_wave": baseline_wave,
            "outcome_wave": outcome_wave,
            "step_order": 0,
            "step": "baseline_health_module_with_valid_id",
            "n_before": len(frame),
            "n_excluded": 0,
            "n_remaining": len(frame),
        }
    ]
    steps = [
        ("baseline_age_available", frame["age"].notna()),
        ("baseline_age_ge_45", frame["age"].ge(45)),
        ("baseline_physician_diagnosed_heart_disease", frame["heart_disease"].eq(1)),
        ("baseline_cesd_at_least_8_items", frame["cesd_adjusted_score"].notna()),
        ("baseline_cesd_below_10", frame["cesd_adjusted_score"].lt(10)),
        ("outcome_cesd_module_matched", frame["outcome_cesd_module_present"].eq(True)),
        ("outcome_cesd_at_least_8_items", frame["outcome_cesd10"].notna()),
    ]
    exclusions: list[pd.DataFrame] = []
    for order, (label, _) in enumerate(steps, start=1):
        if label == "baseline_age_available":
            keep = frame["age"].notna()
        elif label == "baseline_age_ge_45":
            keep = frame["age"].ge(45)
        elif label == "baseline_physician_diagnosed_heart_disease":
            keep = frame["heart_disease"].eq(1)
        elif label == "baseline_cesd_at_least_8_items":
            keep = frame["cesd_adjusted_score"].notna()
        elif label == "baseline_cesd_below_10":
            keep = frame["cesd_adjusted_score"].lt(10)
        elif label == "outcome_cesd_module_matched":
            keep = frame["outcome_cesd_module_present"].eq(True)
        else:
            keep = frame["outcome_cesd10"].notna()
        excluded = frame.loc[~keep.fillna(False), ["ID"]].copy()
        excluded["baseline_wave"] = baseline_wave
        excluded["outcome_wave"] = outcome_wave
        excluded["status"] = "excluded"
        excluded["first_exclusion_reason"] = label
        exclusions.append(excluded)
        frame, row = _flow_step(
            frame, keep, order, label, baseline_wave, outcome_wave
        )
        flow.append(row)

    frame = frame.rename(
        columns={
            "ID": "participant_id",
            "cesd_answered_items": "baseline_cesd_answered_items",
            "cesd_missing_items": "baseline_cesd_missing_items",
            "cesd_raw_sum": "baseline_cesd_raw_sum",
            "cesd_adjusted_score": "baseline_cesd10",
            "cesd_case": "baseline_cesd_case",
            "age": "baseline_age",
        }
    )
    frame.insert(1, "baseline_wave", baseline_wave)
    frame.insert(2, "outcome_wave", outcome_wave)
    frame.insert(
        3,
        "window_id",
        frame["participant_id"].astype(str)
        + "_"
        + str(baseline_wave)
        + "_"
        + str(outcome_wave),
    )
    frame["target"] = frame["outcome_cesd10"].ge(10).astype("int8")

    final_flow = {
        "baseline_wave": baseline_wave,
        "outcome_wave": outcome_wave,
        "step_order": len(flow),
        "step": "final_eligible_window",
        "n_before": len(frame),
        "n_excluded": 0,
        "n_remaining": len(frame),
    }
    flow.append(final_flow)
    eligible_ledger = frame[["participant_id"]].rename(
        columns={"participant_id": "ID"}
    )
    eligible_ledger["baseline_wave"] = baseline_wave
    eligible_ledger["outcome_wave"] = outcome_wave
    eligible_ledger["status"] = "eligible"
    eligible_ledger["first_exclusion_reason"] = "eligible"
    ledger = pd.concat([*exclusions, eligible_ledger], ignore_index=True)
    if ledger["ID"].duplicated().any():
        raise AssertionError("A participant received more than one window disposition")
    return frame, pd.DataFrame(flow), ledger


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interim-dir", type=Path, default=INTERIM_DATA_DIR)
    parser.add_argument("--processed-dir", type=Path, default=PROCESSED_DATA_DIR)
    parser.add_argument("--report-dir", type=Path, default=GENERATED_REPORT_DIR)
    args = parser.parse_args()

    ensure_output_directories()
    args.processed_dir.mkdir(parents=True, exist_ok=True)
    args.report_dir.mkdir(parents=True, exist_ok=True)

    windows: list[pd.DataFrame] = []
    flows: list[pd.DataFrame] = []
    ledgers: list[pd.DataFrame] = []
    comparison_rows: list[dict[str, int]] = []
    for baseline_wave, outcome_wave in WINDOWS:
        baseline_core = pd.read_csv(
            args.interim_dir / f"core_wave_{baseline_wave}.csv",
            dtype={"ID": "string"},
        )
        baseline_demographics = pd.read_csv(
            args.interim_dir / f"demographics_wave_{baseline_wave}.csv",
            dtype={"ID": "string"},
        )
        outcome_core = pd.read_csv(
            args.interim_dir / f"core_wave_{outcome_wave}.csv",
            dtype={"ID": "string"},
        )
        window, flow, ledger = build_one_window(
            baseline_core,
            baseline_demographics,
            outcome_core,
            baseline_wave,
            outcome_wave,
        )
        windows.append(window)
        flows.append(flow)
        ledgers.append(ledger)
        old_count = OLD_FINAL_COUNTS[(baseline_wave, outcome_wave)]
        comparison_rows.append(
            {
                "baseline_wave": baseline_wave,
                "outcome_wave": outcome_wave,
                "old_final_records": old_count,
                "new_final_records": len(window),
                "difference_new_minus_old": len(window) - old_count,
                "new_events": int(window["target"].sum()),
            }
        )

    longitudinal = pd.concat(windows, ignore_index=True, sort=False)
    if longitudinal["window_id"].duplicated().any():
        raise ValueError("Duplicate person-window identifiers were generated")

    contribution = (
        longitudinal.groupby("participant_id")
        .agg(
            windows_contributed=("window_id", "size"),
            first_baseline_wave=("baseline_wave", "min"),
            last_outcome_wave=("outcome_wave", "max"),
        )
        .reset_index()
    )
    longitudinal.to_csv(
        args.processed_dir / "longitudinal_window_skeleton.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.concat(flows, ignore_index=True).to_csv(
        args.report_dir / "cohort_flow.csv", index=False, encoding="utf-8-sig"
    )
    pd.concat(ledgers, ignore_index=True).to_csv(
        args.report_dir / "cohort_exclusion_ledger.csv",
        index=False,
        encoding="utf-8-sig",
    )
    contribution.to_csv(
        args.report_dir / "participant_window_contribution.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(comparison_rows).to_csv(
        args.report_dir / "old_vs_new_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )
    print(
        f"Built {len(longitudinal)} eligible person-windows from "
        f"{longitudinal['participant_id'].nunique()} participants."
    )


if __name__ == "__main__":
    main()
