# CHARLS longitudinal prediction reanalysis

Additional file 2 accompanies the revised manuscript submitted to BMC Cardiovascular Disorders, submission ID 4b258832-7611-46d8-b199-344bdb8e3393.

This archive contains the executable analysis source, three locked primary model pipelines, exact TPOT search configuration and selected-pipeline specifications, cross-wave dictionary, aggregate statistical outputs, and tests. It does not contain CHARLS participant-level records, participant IDs, individual predictions, eligibility ledgers, or raw survey data. The models are research models with modest temporal discrimination and overestimated absolute risks; they are not clinical decision tools.

## Software and installation

The original analysis used Python 3.10. Create an isolated environment and install `requirements-tpot.txt`, which includes `requirements-core.txt`. Versions are pinned. Numerical agreement across operating systems, library implementations, and parallel search schedules is not guaranteed. Rerunning the TPOT searches can be computationally expensive and need not return exactly the same pipeline under a different environment; the archived primary models reproduce the saved predictions in the tested original environment.

Serialized joblib models should only be loaded from a trusted copy of this archive because Python pickle/joblib deserialization can execute code. The integrity manifest records the archived file hashes. No third-party dependency source is bundled; dependency licenses remain with their respective owners. Author code is supplied as article supporting material; no additional standalone open-source license is asserted here.

## Obtain the original data

Register with CHARLS and obtain authorized access through https://charls.charlsdata.com/. Place the four wave folders beside the extracted `reanalysis` folder:

```text
workspace/
  CHARLS2013_Dataset/
  CHARLS2015r/
  CHARLS2018r/
  CHARLS2020r/
  reanalysis/
```

Module filenames and wave-specific fields are listed in `src/wave_config.py`, `src/paths.py`, and `reports/generated/variable_dictionary.csv`. Preserve the released DTA module names. The 2013 Weights and later Sample_Infor modules contribute interview timing; demographic and health modules provide predictor information. The 2020 CESD outcome is in the configured health module. Do not substitute a legacy modeling CSV.

## Reproduction order

Run commands from the extracted `reanalysis` directory:

```text
python run_reproduce.py data
python run_reproduce.py logistic
python run_reproduce.py tpot
python run_reproduce.py sensitivity
python run_reproduce.py sex
python run_reproduce.py outputs
python -m pytest tests
```

The wrapper omits only legacy-comparison and candidate-discovery audits that are not inputs to the primary cohort or models. The analysis source modules otherwise preserve the archived implementation. This packaging change does not alter eligibility, predictors, fitting, or evaluation. Locally generated files containing IDs or individual predictions must not be redistributed without appropriate CHARLS authorization.

`publication/final_figures.py` is the current five-figure plotting source. It regenerates the manuscript's AP-based precision-recall legend and permutation-SD error bars after the original publication-output module. The latter's historical figure formatting is retained for traceability but is not the final submitted figure version. Sensitivity and complete permutation-importance results are supplied as aggregate CSV files.

## Applying the exact archived models

```text
python predict_locked.py --model basic_logistic --input harmonized_baseline.csv --output predictions.csv
```

Use the original harmonized column names, not pre-standardized values. Categorical levels and missing-value handling are documented in the code and dictionary. For TPOT the wrapper applies fixed category encoding before calling the archived fitted pipeline. These probabilities are uncalibrated research outputs in the later-wave population, not established clinical risks.

## Important analytic qualifications

- The population is self-reported physician-diagnosed heart disease, not stroke alone or all cardiovascular disease.
- Participant-separated temporal testing removes all earlier records from test participants. This also enriches events in the development population because eligibility in 2018 requires CESD-10 below 10.
- TPOT post-search OOF performance reuses the search folds; it is not fully nested evaluation of the entire search procedure.
- The psychiatric sensitivity removes only the individual psychiatric indicator. The comorbidity count still includes that history.
- The 2015 disease coding treats unresolved diagnosis responses as absence under a skip-pattern assumption, which is a stated limitation.
- Supplementary S4 and S9 display tables were recomputed descriptively from frozen records for submission; no model was refitted or selected for that step.
