"""Apply a submitted, locked research model to a harmonized baseline CSV."""
import argparse
from pathlib import Path
import joblib
import pandas as pd
from src.model_config import BASIC_MODEL_FEATURES, FULL_MODEL_FEATURES
from src.tpot_fold_safe import encode_tpot_features

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', choices=['basic_logistic','full_penalized_logistic','tpot_final_pipeline'], required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve() == args.input.resolve():
        raise ValueError('Input data must not be overwritten')
    frame = pd.read_csv(args.input)
    features = BASIC_MODEL_FEATURES if args.model == 'basic_logistic' else FULL_MODEL_FEATURES
    missing = sorted(set(features) - set(frame.columns))
    if missing:
        raise ValueError(f'Missing required columns: {missing}')
    x = encode_tpot_features(frame).to_numpy() if args.model == 'tpot_final_pipeline' else frame[features]
    estimator = joblib.load(Path(__file__).resolve().parent / 'models' / f'{args.model}.joblib')
    probability = estimator.predict_proba(x)[:, 1]
    pd.DataFrame({'input_row': range(len(frame)), 'probability': probability}).to_csv(args.output, index=False)
