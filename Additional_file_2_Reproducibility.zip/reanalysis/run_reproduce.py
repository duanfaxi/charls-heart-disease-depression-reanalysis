"""Run the submitted analysis without requiring any legacy manually prepared CSV."""
import argparse
import subprocess
import sys
from pathlib import Path

STAGES = {
    'data': ['src.inventory', 'src.extract_core', 'src.extract_demographics',
             'src.extract_predictors', 'src.build_windows', 'src.assemble_analysis',
             'src.build_dictionary'],
    'logistic': ['src.train_logistic_models'],
    'tpot': ['src.train_tpot'],
    'sensitivity': ['src.run_sensitivity_analyses'],
    'sex': ['src.analyze_sex_performance'],
    'outputs': ['src.refresh_classification_intervals', 'src.generate_publication_outputs',
                'publication.final_figures'],
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=[*STAGES, 'all'])
    args = parser.parse_args()
    modules = [m for s in STAGES.values() for m in s] if args.stage == 'all' else STAGES[args.stage]
    root = Path(__file__).resolve().parent
    for module in modules:
        subprocess.run([sys.executable, '-m', module], cwd=root, check=True)
