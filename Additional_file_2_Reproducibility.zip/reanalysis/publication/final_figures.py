"""Redraw scientific figures from frozen outputs, without refitting models."""
from pathlib import Path
import sys
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score, precision_recall_curve, average_precision_score
from sklearn.calibration import calibration_curve

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.paths import GENERATED_REPORT_DIR
from src.generate_publication_outputs import load_main_predictions

OUT = ROOT / 'figures'
OUT.mkdir(parents=True,exist_ok=True)
LABELS = {'basic_logistic':'Basic logistic model','full_penalized_logistic':'Full L2-penalized logistic model','tpot_final':'TPOT'}
COLORS = {'basic_logistic':'#2567A3','full_penalized_logistic':'#AD4D2E','tpot_final':'#258060'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300,'axes.labelsize':11})

def save(fig,n):
    fig.savefig(OUT/f'figure{n}.png',dpi=300,facecolor='white',bbox_inches='tight')
    plt.close(fig)

pred=load_main_predictions(GENERATED_REPORT_DIR)
for n in (2,3,4):
    fig,ax=plt.subplots(figsize=(6.8,5.1))
    for model,label in LABELS.items():
        d=pred.loc[pred.model.eq(model)]
        if n==2:
            x,y,_=roc_curve(d.target,d.probability)
            label+=f' (AUC {roc_auc_score(d.target,d.probability):.3f})'
        elif n==3:
            y,x,_=precision_recall_curve(d.target,d.probability)
            label+=f' (AP {average_precision_score(d.target,d.probability):.3f})'
        else:
            y,x=calibration_curve(d.target,d.probability,n_bins=10,strategy='quantile')
        ax.plot(x,y,color=COLORS[model],lw=1.8,label=label,marker='o' if n==4 else None,markersize=4)
    if n==3:
        ax.axhline(419/1464,ls='--',color='#666666',lw=1,label='Observed event proportion (0.286)')
    else:
        ax.plot([0,1],[0,1],'--',color='#777777',lw=1)
    ax.set(xlim=(0,1),ylim=(0,1),xlabel={2:'1 - Specificity',3:'Recall (sensitivity)',4:'Mean predicted probability'}[n],ylabel={2:'Sensitivity',3:'Precision (positive predictive value)',4:'Observed event proportion'}[n])
    ax.legend(frameon=False,fontsize=9,loc={2:'lower right',3:'upper right',4:'upper left'}[n])
    fig.tight_layout()
    save(fig,n)

imp=pd.read_csv(GENERATED_REPORT_DIR/'tpot_permutation_importance.csv').head(15).sort_values('mean_auc_loss')
fig,ax=plt.subplots(figsize=(6.8,5.7))
ax.barh(imp.label,imp.mean_auc_loss,xerr=imp.sd_auc_loss,color='#337DA0',error_kw={'elinewidth':1,'ecolor':'#333333','capsize':2})
ax.axvline(0,color='#666666',lw=.8)
ax.set_xlabel('Decrease in temporal test ROC-AUC')
ax.grid(axis='x',lw=.4,alpha=.4)
ax.set_axisbelow(True)
fig.tight_layout()
save(fig,5)

flow=pd.read_csv(GENERATED_REPORT_DIR/'cohort_flow.csv')
step_labels={
 'baseline_health_module_with_valid_id':'Baseline health module\nwith valid ID',
 'baseline_age_available':'Baseline age available',
 'baseline_age_ge_45':'Baseline age >=45 years',
 'baseline_physician_diagnosed_heart_disease':'Physician-diagnosed\nheart disease at baseline',
 'baseline_cesd_at_least_8_items':'At least eight valid\nbaseline CESD-10 items',
 'baseline_cesd_below_10':'Baseline CESD-10 <10',
 'outcome_cesd_module_matched':'Linked to follow-up\nCESD-10 module',
 'outcome_cesd_at_least_8_items':'At least eight valid\nfollow-up CESD-10 items',
}
fig,ax=plt.subplots(figsize=(7.1,8.8))
ax.set(xlim=(0,3),ylim=(-2.8,8.5));ax.axis('off')
for col,(b,o) in enumerate([(2013,2015),(2015,2018),(2018,2020)]):
    ax.text(col+.5,8.3,f'{b}-{o}',ha='center',weight='bold',fontsize=10)
    d=flow.loc[(flow.baseline_wave==b)&(flow.outcome_wave==o)&(flow.step!='final_eligible_window')].sort_values('step_order')
    for i,row in enumerate(d.itertuples()):
        y=7.6-i
        label=step_labels[row.step]+f'\nn = {row.n_remaining:,}'
        if row.n_excluded: label+=f'; excluded {row.n_excluded:,}'
        ax.text(col+.5,y,label,ha='center',va='center',fontsize=7.7,bbox={'boxstyle':'square,pad=.38','facecolor':'#F1F4F6','edgecolor':'#707070','linewidth':.6})
        if i<7:ax.annotate('',xy=(col+.5,y-.67),xytext=(col+.5,y-.32),arrowprops={'arrowstyle':'->','lw':.7,'color':'#555555'})
    ax.text(col+.5,-.73,f'Eligible records: {int(d.iloc[-1].n_remaining):,}',ha='center',va='center',fontsize=8.3,weight='bold')
ax.text(1.5,-1.28,'3,259 eligible person-windows from 2,223 participants',ha='center',fontsize=9.3,weight='bold')
ax.text(1.5,-1.76,'Remove 784 earlier-window records belonging to 501 test participants',ha='center',fontsize=8.2)
ax.text(.76,-2.39,'Development\n1,011 records / 759 participants\n444 events (43.92%)',ha='center',va='center',fontsize=8.2,bbox={'boxstyle':'square,pad=.45','facecolor':'#E4EEF5','edgecolor':'#707070'})
ax.text(2.28,-2.39,'2018-2020 temporal test\n1,464 records / 1,464 participants\n419 events (28.62%)',ha='center',va='center',fontsize=8.2,bbox={'boxstyle':'square,pad=.45','facecolor':'#E7F0EB','edgecolor':'#707070'})
fig.tight_layout(pad=.3)
save(fig,1)
print('Generated five figures from frozen reports:',OUT)
