import numpy as np

from src.train_logistic_models import evaluate_predictions, youden_threshold


def test_youden_threshold_is_finite() -> None:
    threshold = youden_threshold(
        np.array([0, 0, 1, 1]), np.array([0.1, 0.4, 0.6, 0.9])
    )
    assert np.isfinite(threshold)
    assert 0 <= threshold <= 1


def test_classification_metrics_use_requested_threshold() -> None:
    result = evaluate_predictions(
        "test",
        np.array([0, 0, 1, 1]),
        np.array([0.1, 0.6, 0.4, 0.9]),
        0.5,
        "fixed",
        {},
    )
    assert result["true_positive"] == 1
    assert result["false_positive"] == 1
    assert result["true_negative"] == 1
    assert result["false_negative"] == 1
