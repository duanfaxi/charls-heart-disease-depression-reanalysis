import numpy as np
import pandas as pd

from src.tpot_fold_safe import FoldSafeTPOTClassifier, encode_tpot_features


def test_deterministic_encoding_has_fixed_columns_and_missing_flags() -> None:
    from src.model_config import FULL_MODEL_FEATURES

    data = pd.DataFrame({feature: [0, 1] for feature in FULL_MODEL_FEATURES})
    data["sex"] = ["male", pd.NA]
    data["education"] = ["primary", "middle_school"]
    data["smoking_status"] = ["never", "former"]
    data["alcohol_frequency"] = ["none", "monthly_or_less"]
    encoded = encode_tpot_features(data)
    assert encoded.loc[0, "sex__male"] == 1
    assert encoded.loc[1, "sex__missing"] == 1
    assert not encoded.columns.duplicated().any()


def test_fold_safe_dataset_check_does_not_impute_globally() -> None:
    estimator = FoldSafeTPOTClassifier(generations=1, population_size=2)
    x, y = estimator._check_dataset(
        np.array([[1.0, np.nan], [2.0, 3.0]]), np.array([0, 1])
    )
    assert np.isnan(x[0, 1])
    assert y.tolist() == [0, 1]
