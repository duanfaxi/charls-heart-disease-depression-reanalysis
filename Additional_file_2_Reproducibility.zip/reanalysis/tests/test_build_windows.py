import pandas as pd

from src.build_windows import build_one_window


def test_window_filters_baseline_and_scores_outcome() -> None:
    baseline_core = pd.DataFrame(
        {
            "ID": ["a", "b", "c", "d"],
            "cesd_answered_items": [10, 10, 10, 10],
            "cesd_missing_items": [0, 0, 0, 0],
            "cesd_raw_sum": [5, 12, 4, 3],
            "cesd_adjusted_score": [5, 12, 4, 3],
            "cesd_case": [0, 1, 0, 0],
            "cesd_module_present": [True] * 4,
            "heart_disease": [1, 1, 0, 1],
            "heart_module_present": [True] * 4,
        }
    )
    demographics = pd.DataFrame(
        {"ID": ["a", "b", "c", "d"], "wave": 2013, "age": [60, 60, 60, 40]}
    )
    outcome_core = pd.DataFrame(
        {
            "ID": ["a", "b", "c", "d"],
            "cesd_answered_items": [10] * 4,
            "cesd_missing_items": [0] * 4,
            "cesd_raw_sum": [11, 5, 5, 5],
            "cesd_adjusted_score": [11, 5, 5, 5],
            "cesd_case": [1, 0, 0, 0],
            "cesd_module_present": [True] * 4,
        }
    )
    window, flow, ledger = build_one_window(
        baseline_core, demographics, outcome_core, 2013, 2015
    )
    assert window["participant_id"].tolist() == ["a"]
    assert window["target"].tolist() == [1]
    assert flow.iloc[-1]["n_remaining"] == 1
    assert ledger.set_index("ID").loc["b", "first_exclusion_reason"] == "baseline_cesd_below_10"
    assert ledger.set_index("ID").loc["a", "status"] == "eligible"
