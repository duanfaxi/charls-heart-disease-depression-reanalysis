import pandas as pd

from src.assemble_analysis import split_temporally


def test_temporal_split_removes_all_early_records_for_test_ids() -> None:
    data = pd.DataFrame(
        {
            "participant_id": ["a", "a", "b", "c"],
            "baseline_wave": [2013, 2018, 2015, 2018],
            "target": [0, 1, 0, 1],
        }
    )
    development, test, report = split_temporally(data)
    assert development["participant_id"].tolist() == ["b"]
    assert set(test["participant_id"]) == {"a", "c"}
    assert report.loc[0, "final_id_overlap"] == 0
