import pandas as pd

from src.analyze_sex_performance import bootstrap_sex_difference
from src.run_sensitivity_analyses import earliest_window_per_participant


def test_earliest_window_is_one_record_per_participant() -> None:
    data = pd.DataFrame(
        {
            "participant_id": ["1", "1", "2"],
            "baseline_wave": [2015, 2013, 2015],
        }
    )
    result = earliest_window_per_participant(data)
    assert len(result) == 2
    assert result.loc[result["participant_id"].eq("1"), "baseline_wave"].item() == 2013


def test_bootstrap_sex_difference_returns_valid_interval() -> None:
    data = pd.DataFrame(
        {
            "sex": ["male"] * 8 + ["female"] * 8,
            "target": [0, 0, 0, 0, 1, 1, 1, 1] * 2,
            "probability": [0.1, 0.2, 0.3, 0.4, 0.6, 0.7, 0.8, 0.9]
            + [0.1, 0.3, 0.2, 0.4, 0.6, 0.8, 0.7, 0.9],
        }
    )
    result = bootstrap_sex_difference(data, "roc_auc", iterations=100, seed=3)
    assert result["ci_low"] <= result["difference"] <= result["ci_high"]
    assert result["bootstrap_valid_iterations"] > 90
