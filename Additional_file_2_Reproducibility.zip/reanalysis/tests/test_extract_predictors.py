import pandas as pd

from src.extract_predictors import (
    derive_function_score,
    derive_medication,
    derive_smoking_status,
    yes_no_or,
)


def test_2013_unknown_current_smoking_status_stays_missing() -> None:
    frame = pd.DataFrame({"zda059": [1, 2], "da059": [pd.NA, 2], "da061": [pd.NA, pd.NA]})
    result = derive_smoking_status(frame, 2013)
    assert pd.isna(result.iloc[0])
    assert result.iloc[1] == "never"


def test_medication_is_zero_for_disease_absence_and_missing_when_unknown() -> None:
    fields = pd.DataFrame({"a": [pd.NA, pd.NA, 1, 4], "b": [pd.NA] * 4})
    disease = pd.Series([0, 1, 1, 1], dtype="Int64")
    result = derive_medication(fields, disease, {4})
    assert result.tolist() == [0, pd.NA, 1, 0]


def test_function_score_requires_all_items() -> None:
    fields = pd.DataFrame([[1, 2, 3], [1, pd.NA, 1]])
    score, limited = derive_function_score(fields)
    assert score.iloc[0] == 3
    assert limited.iloc[0] == 1
    assert pd.isna(score.iloc[1])
    assert pd.isna(limited.iloc[1])


def test_2015_structural_disease_blanks_can_be_classified_as_no() -> None:
    result = yes_no_or(
        pd.Series([pd.NA, 1]),
        pd.Series([pd.NA, pd.NA]),
        structural_missing_as_no=True,
    )
    assert result.tolist() == [0, 1]
