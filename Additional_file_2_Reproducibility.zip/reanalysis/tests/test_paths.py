from src.paths import RAW_WAVE_DIRS


def test_all_four_raw_wave_directories_exist() -> None:
    assert set(RAW_WAVE_DIRS) == {2013, 2015, 2018, 2020}
    assert all(path.is_dir() for path in RAW_WAVE_DIRS.values())
