import numpy as np
import pandas as pd

from src.score_cesd import score_cesd10


ITEMS = [f"item_{index}" for index in range(10)]
REVERSE = ["item_4", "item_7"]


def test_scores_complete_response_and_reverses_positive_items() -> None:
    data = pd.DataFrame([[1] * 10], columns=ITEMS)
    result = score_cesd10(data, ITEMS, REVERSE)
    assert result.loc[0, "cesd_answered_items"] == 10
    assert result.loc[0, "cesd_raw_sum"] == 6
    assert result.loc[0, "cesd_adjusted_score"] == 6
    assert result.loc[0, "cesd_case"] == 0


def test_prorates_eight_or_nine_items_without_rounding() -> None:
    responses = [2] * 8 + [np.nan, np.nan]
    responses[4] = 3
    responses[7] = 3
    data = pd.DataFrame([responses], columns=ITEMS)
    result = score_cesd10(data, ITEMS, REVERSE)
    assert result.loc[0, "cesd_answered_items"] == 8
    assert result.loc[0, "cesd_adjusted_score"] == 10
    assert result.loc[0, "cesd_case"] == 1


def test_fewer_than_eight_items_is_unscorable() -> None:
    data = pd.DataFrame([[4] * 7 + [np.nan] * 3], columns=ITEMS)
    result = score_cesd10(data, ITEMS, REVERSE)
    assert pd.isna(result.loc[0, "cesd_adjusted_score"])
    assert pd.isna(result.loc[0, "cesd_case"])


def test_explicit_nonresponse_codes_are_missing_not_zero() -> None:
    data = pd.DataFrame([[1] * 7 + [8, 9, 997]], columns=ITEMS)
    result = score_cesd10(data, ITEMS, REVERSE)
    assert result.loc[0, "cesd_answered_items"] == 7
    assert pd.isna(result.loc[0, "cesd_adjusted_score"])
