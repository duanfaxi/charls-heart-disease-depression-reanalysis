import pandas as pd

from src.generate_publication_outputs import build_table1
from src.build_dictionary import build_harmonization_report
from src.model_config import FULL_MODEL_FEATURES


def test_table1_contains_all_model_features() -> None:
    data = pd.DataFrame({feature: [0, 1] for feature in FULL_MODEL_FEATURES})
    data["target"] = [0, 1]
    data["sex"] = ["male", "female"]
    data["education"] = ["primary", "middle_school"]
    data["smoking_status"] = ["never", "current"]
    data["alcohol_frequency"] = ["none", "monthly_or_less"]
    table = build_table1(data)
    assert set(table.loc[table["variable"].ne(""), "variable"])
    assert len(table.loc[table["variable"].ne("")]) == len(FULL_MODEL_FEATURES)


def test_harmonization_report_flags_complete_wave_coverage() -> None:
    dictionary = pd.DataFrame(
        {
            "unified_variable": ["age", "age", "age"],
            "wave": [2013, 2015, 2018],
            "analysis_role": ["candidate_predictor"] * 3,
            "source_file": ["a.dta"] * 3,
            "source_fields": ["age"] * 3,
            "transformation": ["numeric"] * 3,
            "in_basic_model": [True] * 3,
            "in_full_model": [True] * 3,
        }
    )
    report = build_harmonization_report(dictionary)
    assert bool(report.loc[0, "complete_expected_wave_coverage"])
