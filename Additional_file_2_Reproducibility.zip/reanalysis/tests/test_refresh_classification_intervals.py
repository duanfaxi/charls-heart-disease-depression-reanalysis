import pandas as pd

from src.refresh_classification_intervals import add_intervals


def test_add_intervals_contains_observed_proportions() -> None:
    metrics = pd.DataFrame(
        {
            "true_positive": [80],
            "false_negative": [20],
            "true_negative": [70],
            "false_positive": [30],
        }
    )
    result = add_intervals(metrics)
    assert result.loc[0, "sensitivity_ci_low"] < 0.8
    assert result.loc[0, "sensitivity_ci_high"] > 0.8
    assert result.loc[0, "specificity_ci_low"] < 0.7
    assert result.loc[0, "specificity_ci_high"] > 0.7
