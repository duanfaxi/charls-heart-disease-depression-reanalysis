import numpy as np
import pandas as pd

from src.extract_demographics import calculate_age, harmonize_education


def test_calculate_age_accounts_for_interview_before_birthday() -> None:
    age = calculate_age(
        pd.Series([2015, 2015]),
        pd.Series([5, 8]),
        pd.Series([1970, 1970]),
        pd.Series([6, 6]),
    )
    assert age.tolist() == [44, 45]


def test_calculate_age_uses_year_difference_when_month_missing() -> None:
    age = calculate_age(
        pd.Series([2015]),
        pd.Series([np.nan]),
        pd.Series([1970]),
        pd.Series([6]),
    )
    assert age.tolist() == [45]


def test_harmonize_education_levels() -> None:
    raw = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 11, 12, np.nan])
    result = harmonize_education(raw)
    assert result.tolist() == [
        "no_formal",
        "below_primary",
        "below_primary",
        "primary",
        "middle_school",
        "high_or_vocational",
        "high_or_vocational",
        "college_or_above",
        "college_or_above",
        pd.NA,
        pd.NA,
    ]
