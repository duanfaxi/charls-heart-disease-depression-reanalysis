import pandas as pd

from src.derive_disease import derive_heart_disease


def test_prior_or_current_positive_defines_heart_disease() -> None:
    prior = pd.Series([1, 2, pd.NA, 1, pd.NA])
    current = pd.Series([pd.NA, 1, 2, 2, pd.NA])
    result = derive_heart_disease(prior, current)
    assert result["heart_disease"].tolist() == [1, 1, 0, 1, pd.NA]
    assert result["heart_field_conflict"].tolist() == [False, True, False, True, False]


def test_nonstandard_codes_do_not_become_negative() -> None:
    prior = pd.Series([8, 9, 997])
    current = pd.Series([pd.NA, pd.NA, pd.NA])
    result = derive_heart_disease(prior, current)
    assert result["heart_disease"].isna().all()
